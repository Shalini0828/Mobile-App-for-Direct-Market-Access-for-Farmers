<?php require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/db.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT p.*, u.name as farmer_name FROM products p JOIN users u ON p.farmer_id=u.id WHERE p.id=?');
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { echo '<div class="alert alert-warning">Product not found</div>'; require_once __DIR__.'/includes/footer.php'; exit; }
?>
<div class="container">
  <div class="row g-4">
    <div class="col-md-6">
      <?php if($p['image'] && file_exists(__DIR__ . '/uploads/products/' . $p['image'])): ?>
        <img src="<?= BASE_PATH ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" class="img-fluid rounded shadow" alt="<?= htmlspecialchars($p['name']) ?>" style="width: 100%; max-height: 500px; object-fit: cover;">
      <?php else: ?>
        <div class="bg-light rounded shadow d-flex align-items-center justify-content-center" style="height: 500px;">
          <i class="bi bi-image text-secondary" style="font-size: 8rem;"></i>
        </div>
      <?php endif; ?>
    </div>
    
    <div class="col-md-6">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= BASE_PATH ?>/">Home</a></li>
          <li class="breadcrumb-item"><a href="<?= BASE_PATH ?>/shop.php">Shop</a></li>
          <li class="breadcrumb-item active"><?=htmlspecialchars($p['name'])?></li>
        </ol>
      </nav>
      
      <h1 class="display-5 fw-bold mb-3"><?=htmlspecialchars($p['name'])?></h1>
      
      <div class="mb-3">
        <span class="badge bg-success fs-6"><?=htmlspecialchars($p['category'] ?: 'Uncategorized')?></span>
      </div>
      
      <p class="lead text-muted mb-4"><?=nl2br(htmlspecialchars($p['description']))?></p>
      
      <div class="card bg-light mb-4">
        <div class="card-body">
          <p class="mb-2">
            <i class="bi bi-person-badge text-primary"></i> 
            <strong>Farmer:</strong> <?=htmlspecialchars($p['farmer_name'])?>
          </p>
          <p class="mb-2">
            <i class="bi bi-box-seam text-warning"></i> 
            <strong>Available:</strong> <?=$p['quantity']?> units
          </p>
          <p class="mb-0">
            <i class="bi bi-clock text-info"></i> 
            <strong>Posted:</strong> <?=date('M d, Y', strtotime($p['created_at']))?>
          </p>
        </div>
      </div>
      
      <div class="mb-4">
        <h2 class="display-4 text-success mb-0">₹<?=number_format($p['price'],2)?></h2>
        <small class="text-muted">per unit</small>
      </div>
      
      <div class="card shadow-sm mb-3">
        <div class="card-body">
          <div class="row align-items-center">
            <div class="col-md-4">
              <label class="form-label fw-bold">Quantity</label>
              <input id="qty" type="number" value="1" min="1" max="<?=$p['quantity']?>" class="form-control form-control-lg">
            </div>
            <div class="col-md-8">
              <label class="form-label fw-bold d-block">&nbsp;</label>
              <button id="addToCartBtn" class="btn btn-success btn-lg w-100">
                <i class="bi bi-cart-plus"></i> Add to Cart
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <a href="<?= BASE_PATH ?>/cart.php" class="btn btn-outline-secondary btn-lg w-100">
        <i class="bi bi-cart"></i> View Cart
      </a>
    </div>
  </div>
</div>

<script>
document.getElementById('addToCartBtn').addEventListener('click', function() {
  if (!window.app || !window.app.addToCart) {
    if (window.app && window.app.showToast) {
      window.app.showToast('Error: Cart system not loaded. Please refresh the page.', 'error');
    } else {
      alert('Error: Cart system not loaded. Please refresh the page.');
    }
    return;
  }
  
  const qty = parseInt(document.getElementById('qty').value);
  if (qty < 1 || isNaN(qty)) {
    if (window.app && window.app.showToast) {
      window.app.showToast('Please enter a valid quantity', 'warning');
    } else {
      alert('Please enter a valid quantity');
    }
    return;
  }
  
  const product = {
    id: <?=$p['id']?>,
    name: "<?=addslashes($p['name'])?>",
    price: <?=floatval($p['price'])?>,
    qty: qty
  };
  
  console.log('Adding to cart:', product);
  window.app.addToCart(product);
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
