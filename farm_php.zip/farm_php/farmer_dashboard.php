<?php 
require_once __DIR__ . '/includes/header.php'; 
require_once __DIR__ . '/includes/db.php';
require_any_role(['farmer']);
$u = current_user();

// Get statistics
$stmt = $pdo->prepare('SELECT COUNT(*) as total_products, SUM(quantity) as total_stock FROM products WHERE farmer_id=?');
$stmt->execute([$u['id']]);
$stats = $stmt->fetch();

$stmt = $pdo->prepare('SELECT COUNT(*) as total_orders, SUM(total_price) as total_revenue FROM orders o JOIN products p ON o.product_id=p.id WHERE p.farmer_id=?');
$stmt->execute([$u['id']]);
$orderStats = $stmt->fetch();

$stmt = $pdo->prepare('SELECT COUNT(*) as pending FROM orders o JOIN products p ON o.product_id=p.id WHERE p.farmer_id=? AND o.status="pending"');
$stmt->execute([$u['id']]);
$pending = $stmt->fetch();

$stmt = $pdo->prepare('SELECT * FROM products WHERE farmer_id=? ORDER BY created_at DESC'); 
$stmt->execute([$u['id']]); 
$products = $stmt->fetchAll();
?>

<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="display-5 fw-bold mb-2">
                        <i class="bi bi-speedometer2 text-success"></i> Farmer Dashboard
                    </h1>
                    <p class="text-muted mb-0">Welcome back, <?= htmlspecialchars($u['name']) ?>!</p>
                </div>
                <div>
                    <a class="btn btn-success btn-lg shadow" href="<?= BASE_PATH ?>/add_product.php">
                        <i class="bi bi-plus-circle"></i> Add New Product
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-5">
        <!-- Total Products -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Products</h6>
                            <h2 class="fw-bold mb-0"><?= $stats['total_products'] ?? 0 ?></h2>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-box-seam text-primary" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Stock -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Stock</h6>
                            <h2 class="fw-bold mb-0"><?= $stats['total_stock'] ?? 0 ?></h2>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-layers text-warning" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Orders -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Orders</h6>
                            <h2 class="fw-bold mb-0"><?= $orderStats['total_orders'] ?? 0 ?></h2>
                            <small class="text-muted">
                                <?= $pending['pending'] ?? 0 ?> pending
                            </small>
                        </div>
                        <div class="bg-info bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-cart-check text-info" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Revenue -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Revenue</h6>
                            <h2 class="fw-bold mb-0"><?= format_price($orderStats['total_revenue'] ?? 0) ?></h2>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-currency-rupee text-success" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title fw-bold mb-3">
                        <i class="bi bi-lightning-charge-fill text-warning"></i> Quick Actions
                    </h5>
                    <div class="d-flex gap-3">
                        <a href="<?= BASE_PATH ?>/add_product.php" class="btn btn-success">
                            <i class="bi bi-plus-lg"></i> Add Product
                        </a>
                        <a href="<?= BASE_PATH ?>/farmer_orders.php" class="btn btn-primary">
                            <i class="bi bi-bag-check"></i> View Orders
                        </a>
                        <a href="<?= BASE_PATH ?>/shop.php" class="btn btn-outline-secondary">
                            <i class="bi bi-shop"></i> View Shop
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Products List -->
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-grid-3x3-gap-fill text-primary"></i> My Products
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php if(empty($products)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox text-muted" style="font-size: 4rem;"></i>
                            <p class="text-muted mt-3 mb-3">You haven't added any products yet.</p>
                            <a href="<?= BASE_PATH ?>/add_product.php" class="btn btn-success">
                                <i class="bi bi-plus-circle"></i> Add Your First Product
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Image</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Status</th>
                                        <th class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($products as $p): ?>
                                    <tr>
                                        <td>
                                            <?php if($p['image'] && file_exists(__DIR__ . '/uploads/products/' . $p['image'])): ?>
                                                <img src="<?= BASE_PATH ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" 
                                                     alt="<?= htmlspecialchars($p['name']) ?>" 
                                                     class="rounded" 
                                                     style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                                     style="width: 50px; height: 50px;">
                                                    <i class="bi bi-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="fw-semibold"><?= htmlspecialchars($p['name']) ?></td>
                                        <td>
                                            <span class="badge bg-secondary"><?= htmlspecialchars($p['category'] ?? 'Other') ?></span>
                                        </td>
                                        <td class="fw-bold text-success"><?= format_price($p['price']) ?></td>
                                        <td>
                                            <?php if($p['quantity'] <= 0): ?>
                                                <span class="badge bg-danger">Out of Stock</span>
                                            <?php elseif($p['quantity'] < 10): ?>
                                                <span class="badge bg-warning text-dark"><?= $p['quantity'] ?> left</span>
                                            <?php else: ?>
                                                <span class="badge bg-success"><?= $p['quantity'] ?> in stock</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($p['status'] === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <a href="<?= BASE_PATH ?>/product.php?id=<?= $p['id'] ?>" 
                                                   class="btn btn-outline-primary" 
                                                   title="View">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="<?= BASE_PATH ?>/edit_product.php?id=<?= $p['id'] ?>" 
                                                   class="btn btn-outline-secondary" 
                                                   title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hover-card {
    transition: all 0.3s ease;
}
.hover-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
}
.table tbody tr {
    transition: all 0.2s ease;
}
.table tbody tr:hover {
    background-color: rgba(0,0,0,0.02);
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
