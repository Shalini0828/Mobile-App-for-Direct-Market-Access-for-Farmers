<?php
require_once __DIR__ . '/includes/db.php';

$email = 'admin@f.com';
$password = 'admin';
$name = 'Admin';
$role = 'admin';

$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, ?, NOW())');
    $stmt->execute([$name, $email, $hash, $role]);
    echo "Admin created successfully!\n";
    echo "Email: $email\n";
    echo "Password: $password\n";
    echo "User ID: " . $pdo->lastInsertId() . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
