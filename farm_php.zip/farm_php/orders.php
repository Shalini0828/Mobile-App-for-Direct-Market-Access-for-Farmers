<?php require_once __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/db.php';
if (!is_logged_in()) { header('Location:/login.php'); exit; }
$u = current_user();
try {
  $stmt = $pdo->prepare('SELECT o.*, p.name as product_name FROM orders o JOIN products p ON o.product_id=p.id WHERE o.buyer_id=? ORDER BY o.order_date DESC');
  $stmt->execute([$u['id']]);
  $orders = $stmt->fetchAll();
} catch (PDOException $e) {
  // Fallback: orders table may not have product_id column in some DBs.
  // Load orders and fetch product name per-row to avoid JOIN errors.
  $stmt = $pdo->prepare('SELECT * FROM orders WHERE buyer_id=? ORDER BY order_date DESC');
  $stmt->execute([$u['id']]);
  $orders = $stmt->fetchAll();
  foreach ($orders as &$o) {
    $o['product_name'] = null;
    if (!empty($o['product_id'])) {
      $pstmt = $pdo->prepare('SELECT name FROM products WHERE id=?');
      $pstmt->execute([$o['product_id']]);
      $p = $pstmt->fetch();
      if ($p) $o['product_name'] = $p['name'];
    }
  }
  unset($o);
}
?>
<h1>Your Orders</h1>
<table class="table"><thead><tr><th>Product</th><th>Qty</th><th>Total</th><th>Status</th><th>Date</th></tr></thead><tbody>
<?php foreach($orders as $o): ?>
  <tr><td><?=htmlspecialchars($o['product_name'])?></td><td><?=$o['quantity']?></td><td>₹<?=number_format($o['total_price'],2)?></td><td><?=htmlspecialchars($o['status'])?></td><td><?=$o['order_date']?></td></tr>
<?php endforeach; ?>
</tbody></table>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
