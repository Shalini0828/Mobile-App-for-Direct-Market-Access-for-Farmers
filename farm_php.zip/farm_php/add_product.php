<?php require_once __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/db.php';
require_any_role(['farmer']);
$u = current_user();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD']==='POST'){
  $name=$_POST['name']; 
  $desc=$_POST['description']; 
  $price=floatval($_POST['price']); 
  $qty=intval($_POST['quantity']); 
  $cat=$_POST['category'];
  
  // Handle image upload
  $imageName = '';
  if(isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = __DIR__ . '/uploads/products/';
    if(!is_dir($uploadDir)) {
      mkdir($uploadDir, 0755, true);
    }
    
    $fileExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    $allowedExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    if(in_array($fileExt, $allowedExts) && $_FILES['image']['size'] <= 10485760) {
      $imageName = uniqid() . '_' . time() . '.' . $fileExt;
      move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
    }
  }
  
  $stmt=$pdo->prepare('INSERT INTO products (farmer_id,name,description,price,quantity,image,category,created_at) VALUES (?,?,?,?,?,?,?,NOW())');
  $stmt->execute([$u['id'],$name,$desc,$price,$qty,$imageName, $cat]); 
  header('Location: ' . BASE_PATH . '/farmer_dashboard.php'); 
  exit;
}
?>
<div class="container">
  <h1 class="mb-4"><i class="bi bi-plus-circle"></i> Add New Product</h1>
  
  <?php if($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  
  <div class="card shadow-sm">
    <div class="card-body">
      <form method="post" enctype="multipart/form-data">
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">Product Name *</label>
            <input name="name" class="form-control" placeholder="e.g., Fresh Tomatoes" required>
          </div>
          
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">Category</label>
            <select name="category" class="form-control">
              <option value="">Select Category</option>
              <option value="vegetables">Vegetables</option>
              <option value="fruits">Fruits</option>
              <option value="dairy">Dairy</option>
              <option value="grains">Grains</option>
              <option value="others">Others</option>
            </select>
          </div>
        </div>
        
        <div class="mb-3">
          <label class="form-label fw-bold">Description</label>
          <textarea name="description" class="form-control" rows="4" placeholder="Describe your product..."></textarea>
        </div>
        
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">Price (₹) *</label>
            <input type="number" step="0.01" name="price" class="form-control" placeholder="0.00" required>
          </div>
          
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">Quantity *</label>
            <input type="number" name="quantity" class="form-control" placeholder="0" required>
          </div>
        </div>
        
        <div class="mb-3">
          <label class="form-label fw-bold">Product Image</label>
          <input type="file" name="image" class="form-control" accept="image/*" onchange="previewImage(event)">
          <small class="text-muted">Max size: 10MB. Formats: JPG, PNG, GIF, WebP</small>
          <div id="imagePreview" class="mt-3"></div>
        </div>
        
        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-success btn-lg">
            <i class="bi bi-check-circle"></i> Add Product
          </button>
          <a href="<?= BASE_PATH ?>/farmer_dashboard.php" class="btn btn-secondary btn-lg">
            <i class="bi bi-x-circle"></i> Cancel
          </a>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function previewImage(event) {
  const preview = document.getElementById('imagePreview');
  const file = event.target.files[0];
  
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      preview.innerHTML = '<img src="' + e.target.result + '" class="img-thumbnail" style="max-width: 300px;">';
    }
    reader.readAsDataURL(file);
  } else {
    preview.innerHTML = '';
  }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
