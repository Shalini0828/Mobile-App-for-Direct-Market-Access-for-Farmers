<?php
// Run this script from CLI: php setup.php
$DB_HOST = '127.0.0.1'; $DB_NAME='farm_marketplace'; $DB_USER='root'; $DB_PASS='';
try{
  $pdo = new PDO("mysql:host=$DB_HOST;charset=utf8mb4", $DB_USER, $DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS `$DB_NAME` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  echo "Database created/exists\n";
  $pdo->exec("USE `$DB_NAME`");
  // create tables
  $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), email VARCHAR(255) UNIQUE, password VARCHAR(255), role ENUM('farmer','buyer','admin') DEFAULT 'buyer', created_at TIMESTAMP NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY, farmer_id INT, name VARCHAR(255), description TEXT, price FLOAT, quantity INT, image VARCHAR(255), category VARCHAR(255), created_at TIMESTAMP NULL, FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE SET NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS orders (id INT AUTO_INCREMENT PRIMARY KEY, buyer_id INT, product_id INT, quantity INT, total_price FLOAT, status ENUM('pending','confirmed','delivered') DEFAULT 'pending', order_date TIMESTAMP NULL, FOREIGN KEY (buyer_id) REFERENCES users(id), FOREIGN KEY (product_id) REFERENCES products(id))");
  echo "Tables created\n";
  // seed admin and sample users
  $adminPass = password_hash('admin123', PASSWORD_DEFAULT);
  $stmt = $pdo->prepare('INSERT IGNORE INTO users (id,name,email,password,role,created_at) VALUES (?,?,?,?,?,NOW())');
  $stmt->execute([1,'Admin','admin@farm.com',$adminPass,'admin']);
  $stmt->execute([2,'Farmer Joe','farmer1@farm.com',password_hash('farmer123',PASSWORD_DEFAULT),'farmer']);
  $stmt->execute([3,'Buyer Bob','buyer1@farm.com',password_hash('buyer123',PASSWORD_DEFAULT),'buyer']);
  echo "Seeded users\n";
  // seed some products
  $stmt = $pdo->prepare('INSERT IGNORE INTO products (farmer_id,name,description,price,quantity,image,category,created_at) VALUES (?,?,?,?,?,?,?,NOW())');
  $stmt->execute([2,'Fresh Tomatoes','Locally grown red tomatoes',2.5,100,'', 'vegetables']);
  $stmt->execute([2,'Organic Eggs','Free-range eggs, dozen',3.0,50,'','dairy']);
  echo "Seeded products\n";
  echo "Setup completed. Admin: admin@farm.com / admin123\n";
} catch (Exception $e){ echo 'Error: '.$e->getMessage()."\n"; }
