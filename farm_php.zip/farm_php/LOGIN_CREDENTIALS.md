# 🔐 Farm Marketplace - Login Credentials & System Details

**Project Name:** Farm Marketplace  
**Base URL:** http://localhost/farm_php/  
**Created Date:** November 12, 2025  
**Technology Stack:** Core PHP 8.0.30 + MySQL + Bootstrap 5.3.2

---

## 📋 System Access Information

### 🌐 Website URLs

| Page | URL |
|------|-----|
| Home Page | http://localhost/farm_php/ |
| Shop Page | http://localhost/farm_php/shop.php |
| Login Page | http://localhost/farm_php/login.php |
| Register Page | http://localhost/farm_php/register.php |
| Admin Dashboard | http://localhost/farm_php/admin/dashboard.php |
| Farmer Dashboard | http://localhost/farm_php/farmer_dashboard.php |
| Buyer Dashboard | http://localhost/farm_php/buyer_dashboard.php |

---

## 👥 User Account Credentials

### 1️⃣ **ADMIN ACCOUNT**
```
Email:    admin@farm.com
Password: admin123
Role:     Admin
```

**Admin Capabilities:**
- ✅ Manage all users (farmers, buyers, admins)
- ✅ Manage all products across marketplace
- ✅ Manage all orders and transactions
- ✅ View complete marketplace statistics
- ✅ Access admin dashboard with analytics
- ✅ Approve/reject farmer registrations
- ✅ Monitor platform revenue and activity

**Admin Dashboard Features:**
- Total Farmers, Buyers, Products, Orders count
- Total Revenue in ₹ (Indian Rupees)
- Recent Orders (last 5 with status)
- Recent Users (last 5 registrations)
- Quick action buttons for management
- Color-coded status badges

---

### 2️⃣ **FARMER ACCOUNTS**

#### Farmer 1 (Primary Test Account)
```
Email:    farmer1@farm.com
Password: farmer123
Role:     Farmer
Name:     John Farm
```

**Products Listed by Farmer 1:**
- Fresh Tomatoes - ₹166 (20 kg stock)
- Fresh Milk - ₹249 (15 liters stock)
- Farm Eggs - ₹415 (50 dozen stock)
- Organic Carrots - ₹83 (30 kg stock)
- Sweet Corn - ₹124 (25 kg stock)

#### Farmer 2
```
Email:    farmer2@farm.com
Password: farmer123
Role:     Farmer
Name:     Mary Agriculture
```

**Products Listed by Farmer 2:**
- Organic Honey - ₹830 (10 jars stock)
- Fresh Apples - ₹207 (40 kg stock)
- Strawberries - ₹332 (20 kg stock)
- Fresh Lettuce - ₹41 (35 heads stock)
- Potatoes - ₹62 (100 kg stock)

#### Farmer 3
```
Email:    farmer3@farm.com
Password: farmer123
Role:     Farmer
Name:     Bob Green
```

**Products Listed by Farmer 3:**
- Cucumber - ₹83 (30 kg stock)
- Bell Peppers - ₹166 (25 kg stock)
- Fresh Oranges - ₹124 (40 kg stock)
- Cheese - ₹498 (15 kg stock)
- Pumpkin - ₹124 (20 kg stock)

**Farmer Capabilities:**
- ✅ Add new products with images
- ✅ Edit/update own product listings
- ✅ Manage product inventory and pricing
- ✅ View orders for their products
- ✅ Track sales and revenue
- ✅ Update product status (active/inactive)
- ✅ Upload product images (JPG, PNG, GIF - max 10MB)

**Farmer Dashboard Features:**
- Total Products count
- Total Stock quantity
- Total Orders received
- Total Revenue earned in ₹
- Product table with images, prices, stock levels
- Quick actions: Add Product, View Orders, Visit Shop
- Color-coded stock indicators (Red: Out of Stock, Yellow: Low Stock, Green: In Stock)

---

### 3️⃣ **BUYER ACCOUNTS**

#### Buyer 1 (Primary Test Account)
```
Email:    buyer1@farm.com
Password: buyer123
Role:     Buyer
Name:     Alice Buyer
```

#### Buyer 2
```
Email:    buyer2@farm.com
Password: buyer123
Role:     Buyer
Name:     Charlie Customer
```

**Buyer Capabilities:**
- ✅ Browse all products in shop
- ✅ Add products to shopping cart
- ✅ View product details with farmer information
- ✅ Place orders and checkout
- ✅ View order history
- ✅ Track order status (pending/completed/cancelled)
- ✅ Search and filter products by category
- ✅ View product images and descriptions

**Shopping Features:**
- Real-time cart badge (shows item count)
- LocalStorage cart (persists across sessions)
- Quick add to cart from shop page
- INR (₹) pricing throughout
- Product images from Unsplash
- Responsive product cards with hover effects

---

## 🗄️ Database Information

### MySQL Database Details
```
Database Name: farm_marketplace
Host:         localhost
Port:         3306 (default)
Charset:      utf8mb4
```

### Database Tables

#### 1. **users** Table
- id (Primary Key)
- name, email, password (hashed)
- role (admin, farmer, buyer)
- created_at

**Current Users:** 8 total (1 admin, 3 farmers, 4 buyers)

#### 2. **products** Table
- id (Primary Key)
- farmer_id (Foreign Key → users.id)
- name, description, category
- price (in INR), quantity
- image (filename), status
- created_at

**Current Products:** 15 total
**Categories:** Vegetables, Fruits, Dairy, Other

#### 3. **orders** Table
- id (Primary Key)
- user_id (Foreign Key → users.id)
- product_id (Foreign Key → products.id)
- quantity, total_price
- status (pending, completed, cancelled)
- delivery_address
- created_at

**Current Orders:** 8 total

---

## 💰 Currency & Pricing

**Currency:** Indian Rupees (₹)  
**Currency Code:** INR  
**Conversion Rate Used:** 1 USD = ₹83  

**Price Format Function:** `format_price($amount)`  
- Returns: ₹X,XXX.XX format
- Example: `format_price(1500)` → ₹1,500.00

---

## 📁 File Structure & Paths

### Important Directories
```
C:\xampp\htdocs\farm_php\          (Production)
D:\Clones\form connect php\         (Development)
```

### Key Files
```
/includes/
  ├── config.php          (Main configuration)
  ├── db.php             (Database connection)
  ├── auth.php           (Authentication functions)
  ├── header.php         (Navigation bar)
  ├── admin_header.php   (Admin navigation)
  └── footer.php         (Footer)

/uploads/products/       (Product images)
/admin/                  (Admin panel)
/assets/css/            (Custom styles)
/assets/js/             (JavaScript files)

.env                     (Environment variables)
.gitignore              (Git ignore rules)
```

---

## 🎨 Design & UI Features

### Color Scheme
- **Primary:** Bootstrap Blue (#0d6efd)
- **Success:** Bootstrap Green (#198754)
- **Warning:** Bootstrap Yellow (#ffc107)
- **Info:** Bootstrap Cyan (#0dcaf0)
- **Danger:** Bootstrap Red (#dc3545)

### UI Components
- **Login Page:** Purple gradient background (135deg, #667eea → #764ba2)
- **Register Page:** Green gradient background (135deg, #11998e → #38ef7d)
- **Navbar:** White with basket logo, cart badge, user dropdown
- **Cards:** Shadow-sm, hover effects (translateY -5px)
- **Icons:** Bootstrap Icons 1.11.1
- **Badges:** Color-coded by status/role

### Responsive Design
- Mobile-first approach
- Bootstrap 5.3.2 grid system
- Breakpoints: sm (576px), md (768px), lg (992px), xl (1200px)

---

## 🔒 Security Features

### Password Security
- **Hashing Algorithm:** `password_hash()` with PASSWORD_DEFAULT
- **Verification:** `password_verify()`
- All passwords stored as bcrypt hashes

### Session Security
- Session timeout: 24 hours (86400 seconds)
- Session key: `$_SESSION['user']` (stores full user object)
- CSRF protection ready (can be implemented)

### File Upload Security
- Allowed extensions: jpg, jpeg, png, gif
- Max file size: 10MB (10485760 bytes)
- Upload directory: uploads/products/
- File validation before save

---

## 🚀 Quick Start Guide

### Starting the Application

1. **Start XAMPP Services:**
   ```bash
   # Start Apache
   cd C:\xampp
   .\apache_start.bat
   
   # Start MySQL
   .\mysql_start.bat
   ```

2. **Access the Site:**
   - Open browser: http://localhost/farm_php/

3. **Test Login:**
   - Admin: admin@farm.com / admin123
   - Farmer: farmer1@farm.com / farmer123
   - Buyer: buyer1@farm.com / buyer123

---

## 🧪 Testing Scenarios

### Test Case 1: Admin Management
1. Login as admin@farm.com / admin123
2. Navigate to Admin Dashboard
3. View statistics and recent activity
4. Manage Users → See all 8 users
5. Manage Products → See all 15 products
6. Manage Orders → See all 8 orders

### Test Case 2: Farmer Product Management
1. Login as farmer1@farm.com / farmer123
2. View Farmer Dashboard with your statistics
3. Click "Add New Product"
4. Fill form with product details and upload image
5. Submit and verify product appears in table
6. Edit product and update price/stock
7. View in shop page

### Test Case 3: Buyer Shopping Flow
1. Login as buyer1@farm.com / buyer123
2. Browse Shop page
3. Click "Add to Cart" on multiple products
4. See cart badge update (top-right navbar)
5. Click cart icon to view cart
6. Proceed to checkout
7. Fill delivery address
8. Place order
9. View order in "My Orders"

### Test Case 4: Currency Display
1. Browse any page (shop, dashboard, orders)
2. Verify all prices show ₹ symbol
3. Check format: ₹X,XXX.XX
4. Verify calculations are correct

---

## 📊 Current System Statistics

**As of November 12, 2025:**

| Metric | Count |
|--------|-------|
| Total Users | 8 |
| └─ Admins | 1 |
| └─ Farmers | 3 |
| └─ Buyers | 4 |
| Total Products | 15 |
| Total Orders | 8 |
| Product Categories | 4 |
| Product Images | 14/15 downloaded |

---

## 🛠️ Troubleshooting

### Issue: "Invalid credentials"
**Solution:** Use exact credentials from this document. Passwords are case-sensitive.

### Issue: "Page not found"
**Solution:** Ensure Apache is running and base path is /farm_php/

### Issue: "Database connection error"
**Solution:** Check MySQL is running, database name is farm_marketplace

### Issue: "Cart redirect to login despite being logged in"
**Solution:** Already fixed! Session now uses $_SESSION['user'] correctly

### Issue: "Product images not showing"
**Solution:** Images in uploads/products/ - verify file exists and correct filename

### Issue: "Currency showing $ instead of ₹"
**Solution:** Already fixed! Using format_price() function throughout

---

## 📞 Support & Documentation

### Additional Files
- `README.md` - Project overview
- `QUICKSTART.md` - Quick setup guide
- `WORKFLOW.md` - Development workflow
- `LOGIN_CREDENTIALS.md` - This file

### Development Team
- Built with Core PHP (no framework)
- Bootstrap 5.3.2 for UI
- Vanilla JavaScript (no jQuery)
- PDO for database access

---

## ✅ Feature Checklist

### Completed Features
- ✅ User authentication (login/register/logout)
- ✅ Role-based access control (admin/farmer/buyer)
- ✅ Beautiful login page with gradient
- ✅ Enhanced register page with role selector
- ✅ Modern navbar with logo and cart badge
- ✅ Product listing with images
- ✅ Shopping cart (localStorage + database)
- ✅ Checkout and order placement
- ✅ Farmer dashboard with statistics
- ✅ Admin dashboard with analytics
- ✅ Product management (CRUD)
- ✅ Order management
- ✅ INR currency conversion (₹)
- ✅ Product images from Unsplash
- ✅ Responsive design
- ✅ Session management fixed
- ✅ Password reset for all users

### Pending Enhancements
- ⚠️ Checkout page UI polish
- ⚠️ Product edit form image upload
- ⚠️ Add product form drag-drop
- ⚠️ Search and filter in shop
- ⚠️ Rating and review system
- ⚠️ Email notifications
- ⚠️ Payment gateway integration
- ⚠️ Advanced analytics/reports

---

## 🎯 Quick Access Summary

**Most Used Login:**
```
Admin:  admin@farm.com    / admin123
Farmer: farmer1@farm.com  / farmer123  
Buyer:  buyer1@farm.com   / buyer123
```

**Most Used URLs:**
```
Shop:           http://localhost/farm_php/shop.php
Admin Panel:    http://localhost/farm_php/admin/dashboard.php
Farmer Panel:   http://localhost/farm_php/farmer_dashboard.php
```

**Database:**
```
Name: farm_marketplace
Tables: users (8), products (15), orders (8)
```

---

**Last Updated:** November 12, 2025  
**Version:** 1.0  
**Status:** ✅ All systems operational

---

*Keep this file secure and do not commit to public repositories!*
