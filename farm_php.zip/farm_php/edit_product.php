<?php require_once __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/db.php';
require_any_role(['farmer']); $u=current_user();
$id = intval($_GET['id'] ?? 0);
$stmt=$pdo->prepare('SELECT * FROM products WHERE id=? AND farmer_id=?'); $stmt->execute([$id,$u['id']]); $p=$stmt->fetch(); if(!$p){ echo '<div class="alert alert-warning">Not found</div>'; require_once __DIR__.'/includes/footer.php'; exit; }
if ($_SERVER['REQUEST_METHOD']==='POST'){
  $name=$_POST['name']; $desc=$_POST['description']; $price=floatval($_POST['price']); $qty=intval($_POST['quantity']); $cat=$_POST['category'];
  $stmt=$pdo->prepare('UPDATE products SET name=?,description=?,price=?,quantity=?,category=? WHERE id=?');
  $stmt->execute([$name,$desc,$price,$qty,$cat,$id]); header('Location: ' . BASE_PATH . '/farmer_dashboard.php'); exit;
}
?>
<h1>Edit Product</h1>
<form method="post">
  <div class="mb-3"><label>Name</label><input name="name" value="<?=htmlspecialchars($p['name'])?>" class="form-control" required></div>
  <div class="mb-3"><label>Description</label><textarea name="description" class="form-control"><?=htmlspecialchars($p['description'])?></textarea></div>
  <div class="mb-3"><label>Price (₹)</label><input name="price" value="<?=$p['price']?>" class="form-control" required></div>
  <div class="mb-3"><label>Quantity</label><input name="quantity" value="<?=$p['quantity']?>" class="form-control" required></div>
  <div class="mb-3"><label>Category</label><input name="category" value="<?=$p['category']?>" class="form-control"></div>
  <button class="btn btn-primary">Save</button>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
