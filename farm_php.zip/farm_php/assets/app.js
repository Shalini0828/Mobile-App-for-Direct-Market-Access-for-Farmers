// Minimal cart using localStorage
const CART_KEY = 'farm_cart_v1';
function getCart(){ return JSON.parse(localStorage.getItem(CART_KEY) || '[]'); }
function saveCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c)); }

// Toast notification function
function showToast(message, type = 'success') {
  // Remove existing toasts
  const existingToast = document.querySelector('.custom-toast');
  if (existingToast) {
    existingToast.remove();
  }

  // Create toast element
  const toast = document.createElement('div');
  toast.className = `custom-toast custom-toast-${type}`;
  
  // Icon based on type
  const icons = {
    success: 'bi-check-circle-fill',
    error: 'bi-exclamation-circle-fill',
    info: 'bi-info-circle-fill',
    warning: 'bi-exclamation-triangle-fill'
  };
  
  toast.innerHTML = `
    <i class="bi ${icons[type] || icons.success}"></i>
    <span>${message}</span>
  `;
  
  document.body.appendChild(toast);
  
  // Trigger animation
  setTimeout(() => toast.classList.add('show'), 10);
  
  // Auto remove after 3 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function addToCart(product){
  const cart = getCart();
  const found = cart.find(i=>i.id===product.id);
  if(found) {
    found.qty += product.qty||1;
    showToast(`Updated quantity of ${product.name} in cart`, 'success');
  } else {
    cart.push({id:product.id,name:product.name,price:product.price,qty:product.qty||1});
    showToast(`${product.name} added to cart!`, 'success');
  }
  saveCart(cart);
  
  // Update cart badge if exists
  updateCartBadge();
}

function updateCartBadge() {
  const cart = getCart();
  const badge = document.querySelector('.cart-badge');
  if (badge) {
    const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
    badge.textContent = totalItems;
    badge.style.display = totalItems > 0 ? 'inline-block' : 'none';
  }
}

window.app = { getCart, saveCart, addToCart, showToast, updateCartBadge };
