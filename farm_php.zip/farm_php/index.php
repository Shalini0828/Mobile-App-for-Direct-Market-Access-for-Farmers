<?php require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/db.php';
// show a few featured products
try {
  $stmt = $pdo->query('SELECT p.*, u.name as farmer_name FROM products p JOIN users u ON p.farmer_id=u.id ORDER BY p.created_at DESC LIMIT 6');
  $products = $stmt->fetchAll();
} catch (Exception $e) { $products = []; }
?>

<!-- Hero Section -->
<div class="hero-section bg-success text-white py-5 mb-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-6">
        <h1 class="display-3 fw-bold mb-3">Fresh From Farm to Your Table</h1>
        <p class="lead mb-4">Connect directly with local farmers and get fresh, organic produce delivered to your doorstep.</p>
        <div class="d-flex gap-3">
          <a href="<?= BASE_PATH ?>/shop.php" class="btn btn-light btn-lg px-4">Shop Now</a>
          <a href="<?= BASE_PATH ?>/register.php" class="btn btn-outline-light btn-lg px-4">Join Us</a>
        </div>
      </div>
      <div class="col-md-6 text-center">
        <i class="bi bi-basket2-fill" style="font-size: 15rem; opacity: 0.2;"></i>
      </div>
    </div>
  </div>
</div>

<!-- Features Section -->
<div class="container mb-5">
  <div class="row text-center g-4">
    <div class="col-md-4">
      <div class="feature-box p-4">
        <i class="bi bi-truck text-primary" style="font-size: 3rem;"></i>
        <h4 class="mt-3">Fast Delivery</h4>
        <p class="text-muted">Get fresh products delivered quickly to your doorstep</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-box p-4">
        <i class="bi bi-shield-check text-success" style="font-size: 3rem;"></i>
        <h4 class="mt-3">Quality Assured</h4>
        <p class="text-muted">100% organic and fresh from local farms</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-box p-4">
        <i class="bi bi-currency-rupee text-warning" style="font-size: 3rem;"></i>
        <h4 class="mt-3">Best Prices</h4>
        <p class="text-muted">Direct from farmers means better prices for you</p>
      </div>
    </div>
  </div>
</div>

<!-- Featured Products -->
<div class="container">
  <div class="text-center mb-5">
    <h2 class="display-5 fw-bold">Featured Products</h2>
    <p class="lead text-muted">Fresh picks from our local farmers</p>
  </div>
  
  <div class="row g-4">
  <?php foreach($products as $p): ?>
    <div class="col-md-4">
      <div class="card product-card h-100 shadow-sm border-0 hover-lift">
        <?php if($p['image'] && file_exists(__DIR__ . '/uploads/products/' . $p['image'])): ?>
          <img src="<?= BASE_PATH ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($p['name']) ?>" style="height: 250px; object-fit: cover;">
        <?php else: ?>
          <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 250px;">
            <i class="bi bi-image text-secondary" style="font-size: 4rem;"></i>
          </div>
        <?php endif; ?>
        <div class="card-body">
          <h5 class="card-title fw-bold"><?=htmlspecialchars($p['name'])?></h5>
          <p class="text-muted small mb-2">
            <i class="bi bi-person-badge"></i> <?=htmlspecialchars($p['farmer_name'])?>
          </p>
          <p class="card-text text-muted"><?=htmlspecialchars(substr($p['description'],0,80))?>...</p>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <span class="h4 mb-0 text-success fw-bold"><?= format_price($p['price']) ?></span>
            <a href="<?= BASE_PATH ?>/product.php?id=<?=$p['id']?>" class="btn btn-primary">
              <i class="bi bi-eye"></i> View
            </a>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
  
  <div class="text-center mt-5">
    <a href="<?= BASE_PATH ?>/shop.php" class="btn btn-success btn-lg px-5">
      <i class="bi bi-cart"></i> View All Products
    </a>
  </div>
</div>

<style>
.hover-lift {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-lift:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.2) !important;
}
.feature-box {
  transition: all 0.3s ease;
  border-radius: 10px;
}
.feature-box:hover {
  background: #f8f9fa;
  transform: translateY(-5px);
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
