<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin Panel - Farmer Marketplace</title>
    <link rel="stylesheet" href="<?= BASE_PATH ?>/assets/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body { margin: 0; padding: 0; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= BASE_PATH ?>/admin/dashboard.php">
      <i class="bi bi-shield-lock"></i> Admin Panel
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="adminNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/admin/manage_users.php"><i class="bi bi-people"></i> Users</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/admin/manage_products.php"><i class="bi bi-box-seam"></i> Products</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/admin/manage_orders.php"><i class="bi bi-cart-check"></i> Orders</a></li>
      </ul>
      <ul class="navbar-nav">
        <?php if (is_logged_in()): $u = current_user(); ?>
        <li class="nav-item"><span class="nav-link text-light"><i class="bi bi-person-circle"></i> <?=htmlspecialchars($u['name'])?></span></li>
        <li class="nav-item"><a class="nav-link btn btn-outline-light btn-sm ms-2" href="<?= BASE_PATH ?>/logout.php">Logout</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<main class="container-fluid py-4">
