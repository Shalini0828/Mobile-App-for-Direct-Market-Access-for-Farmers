<?php
/**
 * Global Configuration
 * Centralized configuration for the Farmer Marketplace
 */

// Base URL path (change this if you move the project)
define('BASE_PATH', '/farm_php');
define('SITE_NAME', 'Farmer Marketplace');
define('SITE_URL', 'http://localhost' . BASE_PATH);

// Currency Settings
define('CURRENCY_SYMBOL', '₹');
define('CURRENCY_CODE', 'INR');

// Helper function to format price
function format_price($price) {
    return CURRENCY_SYMBOL . number_format($price, 2);
}

// Helper function to get full URL
function base_url($path = '') {
    return BASE_PATH . ($path ? '/' . ltrim($path, '/') : '');
}

// Helper function to get full site URL
function site_url($path = '') {
    return SITE_URL . ($path ? '/' . ltrim($path, '/') : '/');
}

// Asset URL helper
function asset($path) {
    return BASE_PATH . '/assets/' . ltrim($path, '/');
}
?>
