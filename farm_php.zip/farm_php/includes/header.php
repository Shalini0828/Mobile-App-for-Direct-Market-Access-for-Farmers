<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Farmer Marketplace - Fresh from Farm to Table</title>
    <link rel="stylesheet" href="<?= BASE_PATH ?>/assets/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_PATH ?>/assets/app.js" defer></script>
    <style>
        body { margin: 0; padding: 0; }
        .navbar-brand { font-weight: bold; font-size: 1.5rem; }
        .navbar { box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .nav-link { font-weight: 500; }
        
        /* Toast Notification Styles */
        .custom-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 15px;
            font-weight: 500;
            z-index: 9999;
            transform: translateX(400px);
            opacity: 0;
            transition: all 0.3s ease;
            min-width: 280px;
            max-width: 400px;
        }
        
        .custom-toast.show {
            transform: translateX(0);
            opacity: 1;
        }
        
        .custom-toast i {
            font-size: 24px;
            flex-shrink: 0;
        }
        
        .custom-toast-success {
            border-left: 4px solid #198754;
        }
        
        .custom-toast-success i {
            color: #198754;
        }
        
        .custom-toast-error {
            border-left: 4px solid #dc3545;
        }
        
        .custom-toast-error i {
            color: #dc3545;
        }
        
        .custom-toast-info {
            border-left: 4px solid #0dcaf0;
        }
        
        .custom-toast-info i {
            color: #0dcaf0;
        }
        
        .custom-toast-warning {
            border-left: 4px solid #ffc107;
        }
        
        .custom-toast-warning i {
            color: #ffc107;
        }
        
        @media (max-width: 768px) {
            .custom-toast {
                right: 10px;
                left: 10px;
                min-width: auto;
            }
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
  <div class="container">
    <a class="navbar-brand text-success d-flex align-items-center" href="<?= BASE_PATH ?>/">
      <i class="bi bi-basket2-fill me-2" style="font-size: 1.8rem;"></i>
      <span>Farm<span class="text-primary">Connect</span></span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExampleDefault">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/">
          <i class="bi bi-house-door"></i> Home
        </a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/shop.php">
          <i class="bi bi-shop"></i> Shop
        </a></li>
      </ul>
      <ul class="navbar-nav align-items-center">
      <?php if (is_logged_in()): $u = current_user(); ?>
        <li class="nav-item"><a class="nav-link position-relative" href="<?= BASE_PATH ?>/cart.php">
          <i class="bi bi-cart3 fs-5"></i>
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="cartBadge">0</span>
        </a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/orders.php">
          <i class="bi bi-bag-check"></i> Orders
        </a></li>
        <?php if ($u['role'] === 'farmer'): ?>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/farmer_dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a></li>
        <?php endif; ?>
        <?php if ($u['role'] === 'admin'): ?>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/admin/dashboard.php">
            <i class="bi bi-shield-lock"></i> Admin
          </a></li>
        <?php endif; ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center bg-light rounded px-3 py-2" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" style="border: 2px solid #e0e0e0;">
            <i class="bi bi-person-circle fs-4 me-2 text-primary"></i> 
            <span class="fw-bold"><?=htmlspecialchars($u['name'])?></span>
            <small class="text-muted ms-2 d-none d-md-inline">(<?=ucfirst($u['role'])?>)</small>
          </a>
          <ul class="dropdown-menu dropdown-menu-end shadow">
            <li class="px-3 py-2 bg-light border-bottom">
              <div class="d-flex align-items-center">
                <i class="bi bi-person-circle fs-3 text-primary me-2"></i>
                <div>
                  <div class="fw-bold"><?=htmlspecialchars($u['name'])?></div>
                  <small class="text-muted"><?=htmlspecialchars($u['email'])?></small>
                </div>
              </div>
            </li>
            <li><a class="dropdown-item py-2" href="<?= BASE_PATH ?>/orders.php">
              <i class="bi bi-bag-check text-success"></i> My Orders
            </a></li>
            <?php if ($u['role'] === 'farmer'): ?>
            <li><a class="dropdown-item py-2" href="<?= BASE_PATH ?>/farmer_dashboard.php">
              <i class="bi bi-speedometer2 text-info"></i> My Dashboard
            </a></li>
            <?php endif; ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item py-2 text-danger" href="<?= BASE_PATH ?>/logout.php">
              <i class="bi bi-box-arrow-right"></i> Logout
            </a></li>
          </ul>
        </li>
      <?php else: ?>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/cart.php">
          <i class="bi bi-cart3 fs-5"></i>
        </a></li>
        <li class="nav-item"><a class="nav-link btn btn-outline-primary px-3" href="<?= BASE_PATH ?>/login.php">
          <i class="bi bi-box-arrow-in-right"></i> Login
        </a></li>
        <li class="nav-item ms-2"><a class="nav-link btn btn-success text-white px-3" href="<?= BASE_PATH ?>/register.php">
          <i class="bi bi-person-plus"></i> Sign Up
        </a></li>
      <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<script>
// Update cart badge count
function updateCartBadge() {
  const badge = document.getElementById('cartBadge');
  if (badge && window.app && window.app.getCart) {
    const cart = window.app.getCart();
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    badge.textContent = count;
    badge.style.display = count > 0 ? 'inline' : 'none';
  }
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', updateCartBadge);
} else {
  updateCartBadge();
}
setInterval(updateCartBadge, 1000);
</script>

<main class="py-4">
