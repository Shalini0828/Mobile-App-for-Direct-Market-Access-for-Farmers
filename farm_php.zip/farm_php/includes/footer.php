</main>
<footer class="text-center py-4">
  <div class="container">&copy; <?=date('Y')?> Farmer Marketplace</div>
</footer>
</body>
</html>
