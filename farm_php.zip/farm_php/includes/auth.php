<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function is_logged_in() {
    return isset($_SESSION['user']);
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function require_role($role) {
    if (!is_logged_in() || current_user()['role'] !== $role) {
        header('Location: ' . BASE_PATH . '/login.php');
        exit;
    }
}

function require_any_role($roles = []) {
    if (!is_logged_in() || !in_array(current_user()['role'], $roles)) {
        header('Location: ' . BASE_PATH . '/login.php');
        exit;
    }
}
