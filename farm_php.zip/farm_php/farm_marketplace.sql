-- farm_marketplace SQL dump
CREATE DATABASE IF NOT EXISTS `farm_marketplace` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `farm_marketplace`;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('farmer','buyer','admin') DEFAULT 'buyer',
  `created_at` timestamp NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
);

CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `farmer_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `price` float DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `buyer_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `total_price` float DEFAULT NULL,
  `status` enum('pending','confirmed','delivered') DEFAULT 'pending',
  `order_date` timestamp NULL,
  PRIMARY KEY (`id`)
);

-- Seed users (passwords hashed with password_hash)
INSERT IGNORE INTO users (id,name,email,password,role,created_at) VALUES
(1,'Admin','admin@farm.com','$2y$10$aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','admin',NOW()),
(2,'Farmer Joe','farmer1@farm.com','$2y$10$bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb','farmer',NOW()),
(3,'Buyer Bob','buyer1@farm.com','$2y$10$cccccccccccccccccccccccccccccccccccccccccccccccccc','buyer',NOW());

-- Note: Replace the placeholder hashed passwords with real hashes or use the provided setup.php to seed with working hashes.

INSERT INTO products (farmer_id,name,description,price,quantity,image,category,created_at) VALUES
(2,'Fresh Tomatoes','Locally grown red tomatoes',2.5,100,'','vegetables',NOW()),
(2,'Organic Eggs','Free-range eggs, dozen',3.0,50,'','dairy',NOW());
