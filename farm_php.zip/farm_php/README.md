# Farmer Marketplace — PHP E-Commerce (Core PHP)

A minimal multi-role e-commerce scaffold in Core PHP (no framework). Includes DB setup script to create the schema and seed an admin account.

Admin credentials (after running setup):

- email: admin@farm.com
- password: admin123

Quick start (Windows PowerShell):

```powershell
# 1) Edit `includes/db.php` and set your MySQL credentials
# 2) Run the setup script to create DB and seed admin:
php setup.php
# 3) Start PHP built-in server:
php -S localhost:8000 -t "d:\Clones\form connect php"
# 4) Open http://localhost:8000/
```

Notes:

- The `setup.php` script uses PHP's PDO and `password_hash` to seed users.
- This is a starter scaffold. Add image upload handling, validation, and production hardening before deploying.
