# Download product images
$images = @(
    @{name = 'tomatoes.jpg'; url = 'https://images.unsplash.com/photo-1546470427-e26264be0b2d?w=800' },
    @{name = 'milk.jpg'; url = 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=800' },
    @{name = 'eggs.jpg'; url = 'https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=800' },
    @{name = 'carrots.jpg'; url = 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=800' },
    @{name = 'corn.jpg'; url = 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800' },
    @{name = 'honey.jpg'; url = 'https://images.unsplash.com/photo-1587049352846-4a222e784143?w=800' },
    @{name = 'apples.jpg'; url = 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=800' },
    @{name = 'strawberries.jpg'; url = 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=800' },
    @{name = 'lettuce.jpg'; url = 'https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?w=800' },
    @{name = 'potatoes.jpg'; url = 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800' },
    @{name = 'cucumber.jpg'; url = 'https://images.unsplash.com/photo-1589927986089-35812388d1f4?w=800' },
    @{name = 'peppers.jpg'; url = 'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?w=800' },
    @{name = 'oranges.jpg'; url = 'https://images.unsplash.com/photo-1580052614034-c55d20bfee3b?w=800' },
    @{name = 'cheese.jpg'; url = 'https://images.unsplash.com/photo-1452195100486-9cc805987862?w=800' },
    @{name = 'pumpkin.jpg'; url = 'https://images.unsplash.com/photo-1570586437263-ab629fccc818?w=800' }
)

$dest = "C:\xampp\htdocs\farm_php\uploads\products\"

Write-Host "`nDownloading product images..." -ForegroundColor Cyan

foreach ($img in $images) {
    $file = Join-Path $dest $img.name
    Write-Host "  $($img.name)..." -NoNewline
    try {
        Invoke-WebRequest -Uri $img.url -OutFile $file -UseBasicParsing
        Write-Host " Done" -ForegroundColor Green
    }
    catch {
        Write-Host " Failed" -ForegroundColor Red
    }
}

Write-Host "`nComplete!`n" -ForegroundColor Green
