# 🚀 FarmConnect - Quick Start Guide

## ⚡ Installation in 5 Minutes

### Step 1: Prerequisites ✅

- XAMPP installed
- Apache & MySQL running

### Step 2: Copy Files 📁

```powershell
Copy-Item -Path "D:\Clones\form connect php\*" -Destination "C:\xampp\htdocs\farm_php\" -Recurse -Force
```

### Step 3: Import Database 💾

```powershell
Get-Content "C:\xampp\htdocs\farm_php\database_schema.sql" | C:\xampp\mysql\bin\mysql.exe -u root
```

### Step 4: Open in Browser 🌐

Visit: **http://localhost/farm_php/**

---

## 🎯 Quick Access URLs

| Page          | URL                                       |
| ------------- | ----------------------------------------- |
| 🏠 Homepage   | http://localhost/farm_php/                |
| 🔐 Login      | http://localhost/farm_php/login.php       |
| 📝 Register   | http://localhost/farm_php/register.php    |
| 🛒 Shop       | http://localhost/farm_php/shop.php        |
| 🛡️ Admin      | http://localhost/farm_php/admin/login.php |
| 💾 phpMyAdmin | http://localhost/phpmyadmin               |

---

## 👥 Default Login Credentials

### 🛡️ Admin

```
Email: admin@farm.com
Password: admin123
```

### 🌾 Farmer

```
Email: farmer1@farm.com
Password: farmer123
```

### 🛒 Buyer

```
Email: buyer1@farm.com
Password: buyer123
```

---

## 📁 Project Structure (Complete)

```
farm_php/
├── 📁 admin/                  # Admin panel (5 files)
├── 📁 api/                    # API endpoints (empty, ready for future)
├── 📁 assets/                 # Static files
│   ├── css/                   # Custom CSS
│   ├── js/                    # Custom JavaScript
│   ├── images/                # Site images
│   ├── app.js                 # Cart functions
│   ├── style.css              # Main styles
│   └── placeholder.png        # Default image
├── 📁 cache/                  # Cache storage
├── 📁 includes/               # PHP includes (6 files)
├── 📁 logs/                   # Error logs
├── 📁 sessions/               # Session storage
├── 📁 uploads/
│   └── products/              # Product images
├── 📄 23 PHP files            # Main application files
├── 📄 config.php              # Main configuration
├── 📄 .env                    # Environment variables
├── 📄 .gitignore              # Git ignore rules
├── 📄 database_schema.sql     # Complete DB schema
├── 📄 README.md               # Project readme
└── 📄 WORKFLOW.md             # This workflow guide
```

**Total: 32+ files + 10 directories**

---

## ⚙️ Configuration Files

### 1. Main Config (`config.php`)

- Application settings
- Helper functions
- Security settings
- Upload configuration

### 2. Database Config (`includes/db.php`)

```php
Host: 127.0.0.1
Database: farm_marketplace
User: root
Password: (empty)
```

### 3. Environment File (`.env`)

- Database credentials
- API keys
- SMTP settings
- Payment gateway keys

---

## 🗂️ Database Schema

### Tables Created:

1. ✅ **users** (8 records) - Admin, farmers, buyers
2. ✅ **products** (15 records) - Sample products
3. ✅ **orders** (8 records) - Sample orders
4. ✅ **cart** - For future database-driven cart
5. ✅ **reviews** - For product reviews
6. ✅ **categories** (8 records) - Product categories

### Special Features:

- 🔍 Views for common queries
- ⚙️ Stored procedures
- 🔔 Triggers for automation
- 📊 Indexes for performance

---

## 🎨 Features Implemented

### ✅ User Management

- Registration with role selection
- Login/Logout
- Session management
- Role-based access (admin/farmer/buyer)

### ✅ Product Management

- Add products (farmers)
- Edit products
- Delete products
- Image upload
- Category selection

### ✅ Shopping Experience

- Product listing with search
- Product details page
- Shopping cart (localStorage)
- Checkout process
- Order history

### ✅ Admin Panel

- Beautiful dashboard
- User management
- Product management
- Order status updates
- Statistics cards

### ✅ UI/UX

- Beautiful gradient login
- Visual role selector on register
- Logo navbar with cart badge
- Responsive design
- Bootstrap 5 + Icons
- Hover effects

---

## 🔧 Common Tasks

### Start Servers

```powershell
# Open XAMPP Control Panel
C:\xampp\xampp-control.exe
# Start Apache & MySQL
```

### View Database

```
Visit: http://localhost/phpmyadmin
Database: farm_marketplace
```

### Clear Cache

```powershell
Remove-Item "C:\xampp\htdocs\farm_php\cache\*" -Force
```

### View Error Logs

```powershell
Get-Content "C:\xampp\htdocs\farm_php\logs\error.log"
```

### Backup Database

```powershell
C:\xampp\mysql\bin\mysqldump.exe -u root farm_marketplace > backup.sql
```

---

## 🐛 Troubleshooting

### Problem: Can't connect to database

**Solution:**

1. Check MySQL is running
2. Verify credentials in `includes/db.php`
3. Check database exists: `farm_marketplace`

### Problem: Images not uploading

**Solution:**

1. Check `uploads/products/` folder exists
2. Verify folder has write permissions
3. Check file size (max 10MB)

### Problem: Session errors

**Solution:**

1. Clear browser cache
2. Delete session files
3. Restart Apache

### Problem: 404 errors

**Solution:**

1. Check `BASE_PATH` in config
2. Verify files copied correctly
3. Check `.htaccess` file

---

## 📈 Next Steps

### Immediate

- [ ] Test all features
- [ ] Add more products
- [ ] Create test orders
- [ ] Explore admin panel

### Short Term

- [ ] Implement payment gateway
- [ ] Add email notifications
- [ ] Create product reviews
- [ ] Add search filters

### Long Term

- [ ] Mobile app API
- [ ] Real-time chat
- [ ] Analytics dashboard
- [ ] Multi-language support

---

## 📚 Documentation

- **WORKFLOW.md** - Complete workflow guide (this file)
- **README.md** - Project overview
- **database_schema.sql** - Database structure
- **Comments in code** - Inline documentation

---

## 💡 Tips & Best Practices

1. **Development**

   - Keep `APP_ENV=development` in .env
   - Check error logs regularly
   - Use meaningful commit messages

2. **Security**

   - Never commit .env file
   - Change default passwords
   - Use HTTPS in production

3. **Performance**

   - Optimize images before upload
   - Use database indexes
   - Enable caching

4. **Maintenance**
   - Regular database backups
   - Monitor disk space
   - Update dependencies

---

## 🎉 Success Checklist

- [x] All files copied to XAMPP
- [x] Database imported successfully
- [x] Apache & MySQL running
- [x] Homepage loads correctly
- [x] Login/Register working
- [x] Products displaying
- [x] Cart functionality working
- [x] Admin panel accessible
- [x] Images uploading
- [x] Orders processing

---

## 📞 Need Help?

- Check error logs: `logs/error.log`
- Review configuration: `config.php`, `.env`
- Test database: http://localhost/phpmyadmin
- Review this guide: `WORKFLOW.md`

---

**🌱 Your FarmConnect marketplace is ready! Start farming! 🚜**

---

_Version 1.0.0 | Last Updated: November 12, 2025_
