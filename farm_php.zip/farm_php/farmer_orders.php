<?php require_once __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/db.php';
require_any_role(['farmer']); $u=current_user();
try {
  $stmt = $pdo->prepare('SELECT o.*, p.name as product_name, u.name as buyer_name FROM orders o JOIN products p ON o.product_id=p.id JOIN users u ON o.buyer_id=u.id WHERE p.farmer_id=? ORDER BY o.order_date DESC');
  $stmt->execute([$u['id']]);
  $orders = $stmt->fetchAll();
} catch (PDOException $e) {
  // Fallback if orders.product_id not present
  $stmt = $pdo->prepare('SELECT o.*, u.name as buyer_name FROM orders o JOIN users u ON o.buyer_id=u.id ORDER BY o.order_date DESC');
  $stmt->execute();
  $rows = $stmt->fetchAll();
  $orders = [];
  foreach ($rows as $r) {
    // only include orders for this farmer's products by looking up product and checking farmer_id
    $pname = null; $include = false;
    if (!empty($r['product_id'])) {
      $pstmt = $pdo->prepare('SELECT name, farmer_id FROM products WHERE id=?');
      $pstmt->execute([$r['product_id']]); $p = $pstmt->fetch();
      if ($p) {
        $pname = $p['name'];
        if ($p['farmer_id'] == $u['id']) $include = true;
      }
    }
    if ($include) {
      $r['product_name'] = $pname;
      $orders[] = $r;
    }
  }
}
?>
<h1>Orders for your products</h1>
<table class="table"><thead><tr><th>Product</th><th>Buyer</th><th>Qty</th><th>Total</th><th>Status</th></tr></thead><tbody>
<?php foreach($orders as $o): ?>
  <tr><td><?=htmlspecialchars($o['product_name'])?></td><td><?=htmlspecialchars($o['buyer_name'])?></td><td><?=$o['quantity']?></td><td>₹<?=number_format($o['total_price'],2)?></td><td><?=htmlspecialchars($o['status'])?></td></tr>
<?php endforeach; ?>
</tbody></table>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
