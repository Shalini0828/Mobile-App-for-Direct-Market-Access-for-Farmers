<?php require_once __DIR__ . '/includes/header.php'; ?>
<h1>Your Cart</h1>
<div id="cart-root"><p>Loading cart...</p></div>
<script>
// Debug: Check if app is loaded
console.log('App object:', window.app);

function render(){
  // Check if app object exists
  if (!window.app || !window.app.getCart) {
    console.error('App.js not loaded properly');
    document.getElementById('cart-root').innerHTML = '<div class="alert alert-danger">Error loading cart. Please refresh the page.</div>';
    return;
  }
  
  const cart = window.app.getCart();
  console.log('Cart contents:', cart);
  
  if(!cart.length){ 
    document.getElementById('cart-root').innerHTML = '<div class="alert alert-info">Cart is empty. <a href="<?= BASE_PATH ?>/shop.php">Go shopping</a></div>'; 
    return; 
  }
  
  let html = '<table class="table"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>';
  cart.forEach(i=> {
    const itemTotal = (i.price * i.qty).toFixed(2);
    html += `<tr>
      <td>${i.name}</td>
      <td>${i.qty}</td>
      <td>₹${parseFloat(i.price).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
      <td>₹${parseFloat(itemTotal).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
    </tr>`;
  });
  html += '</tbody></table>';
  html += '<a class="btn btn-primary" href="<?= BASE_PATH ?>/checkout.php">Proceed to Checkout</a>';
  document.getElementById('cart-root').innerHTML = html;
}

// Wait for app.js to load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', render);
} else {
  render();
}
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
