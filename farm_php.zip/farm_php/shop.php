<?php require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/db.php';
$stmt = $pdo->query('SELECT p.*, u.name as farmer_name FROM products p JOIN users u ON p.farmer_id=u.id ORDER BY p.created_at DESC');
$products = $stmt->fetchAll();
?>
<div class="container">
  <div class="text-center mb-4">
    <h1 class="display-4 fw-bold">Our Products</h1>
    <p class="lead text-muted">Fresh from local farms</p>
  </div>

  <!-- Search and Filter Section -->
  <div class="row mb-4">
    <div class="col-md-8 mx-auto">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <div class="row g-3">
            <div class="col-md-7">
              <div class="input-group input-group-lg">
                <span class="input-group-text bg-white border-end-0">
                  <i class="bi bi-search text-muted"></i>
                </span>
                <input type="text" 
                       id="searchInput" 
                       class="form-control border-start-0 ps-0" 
                       placeholder="Search products..." 
                       autocomplete="off">
                <button class="btn btn-outline-secondary" id="clearSearch" style="display:none;">
                  <i class="bi bi-x-lg"></i>
                </button>
              </div>
            </div>
            <div class="col-md-5">
              <select id="categoryFilter" class="form-select form-select-lg">
                <option value="">All Categories</option>
                <option value="vegetables">Vegetables</option>
                <option value="fruits">Fruits</option>
                <option value="dairy">Dairy</option>
                <option value="grains">Grains</option>
                <option value="honey">Honey</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
          <div id="searchStats" class="mt-2 text-muted small" style="display:none;"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Products Grid -->
  <div id="productsContainer" class="row g-4">
  <?php foreach($products as $p): ?>
    <div class="col-md-3 mb-4 product-item" 
         data-name="<?=strtolower(htmlspecialchars($p['name']))?>" 
         data-description="<?=strtolower(htmlspecialchars($p['description']))?>" 
         data-category="<?=strtolower(htmlspecialchars($p['category'] ?? 'other'))?>" 
         data-farmer="<?=strtolower(htmlspecialchars($p['farmer_name']))?>">
      <div class="card product-card h-100 shadow-sm border-0 hover-lift">
        <?php if($p['image'] && file_exists(__DIR__ . '/uploads/products/' . $p['image'])): ?>
          <img src="<?= BASE_PATH ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($p['name']) ?>" style="height: 200px; object-fit: cover;">
        <?php else: ?>
          <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
            <i class="bi bi-image text-secondary" style="font-size: 3rem;"></i>
          </div>
        <?php endif; ?>
        <div class="card-body">
          <h5 class="card-title fw-bold"><?=htmlspecialchars($p['name'])?></h5>
          <p class="text-muted small mb-2">
            <i class="bi bi-person-badge"></i> <?=htmlspecialchars($p['farmer_name'])?>
          </p>
          <p class="card-text text-muted small"><?=htmlspecialchars(substr($p['description'],0,60))?>...</p>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <span class="h5 mb-0 text-success">₹<?=number_format($p['price'],2)?></span>
            <div class="btn-group">
              <a href="<?= BASE_PATH ?>/product.php?id=<?=$p['id']?>" class="btn btn-sm btn-outline-primary">
                <i class="bi bi-eye"></i> View
              </a>
              <button class="btn btn-sm btn-success" onclick='addToCartQuick(<?=$p['id']?>,"<?=addslashes($p['name'])?>",<?=floatval($p['price'])?>)'>
                <i class="bi bi-cart-plus"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
  
  <!-- No Results Message -->
  <div id="noResults" class="text-center py-5" style="display:none;">
    <i class="bi bi-search text-muted" style="font-size: 4rem;"></i>
    <h4 class="mt-3 text-muted">No products found</h4>
    <p class="text-muted">Try adjusting your search or filter</p>
  </div>
</div>

<style>
.hover-lift {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-lift:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(0,0,0,0.15) !important;
}
.product-item {
  transition: opacity 0.3s ease, transform 0.3s ease;
}
.product-item.hidden {
  display: none;
}
.highlight {
  background-color: #fff3cd;
  padding: 2px 4px;
  border-radius: 3px;
}
</style>

<script>
function addToCartQuick(id, name, price) {
  if (!window.app || !window.app.addToCart) {
    if (window.app && window.app.showToast) {
      window.app.showToast('Error: Cart system not loaded. Please refresh the page.', 'error');
    } else {
      alert('Error: Cart system not loaded. Please refresh the page.');
    }
    return;
  }
  
  const product = {
    id: id,
    name: name,
    price: price,
    qty: 1
  };
  
  console.log('Adding to cart:', product);
  window.app.addToCart(product);
}

// Real-time Search and Filter
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const clearBtn = document.getElementById('clearSearch');
const productsContainer = document.getElementById('productsContainer');
const noResults = document.getElementById('noResults');
const searchStats = document.getElementById('searchStats');
const allProducts = document.querySelectorAll('.product-item');

function performSearch() {
  const searchTerm = searchInput.value.toLowerCase().trim();
  const selectedCategory = categoryFilter.value.toLowerCase();
  let visibleCount = 0;
  
  allProducts.forEach(product => {
    const name = product.dataset.name;
    const description = product.dataset.description;
    const category = product.dataset.category;
    const farmer = product.dataset.farmer;
    
    // Check if product matches search term
    const matchesSearch = !searchTerm || 
                          name.includes(searchTerm) || 
                          description.includes(searchTerm) ||
                          farmer.includes(searchTerm);
    
    // Check if product matches category
    const matchesCategory = !selectedCategory || category === selectedCategory;
    
    // Show or hide product
    if (matchesSearch && matchesCategory) {
      product.classList.remove('hidden');
      visibleCount++;
    } else {
      product.classList.add('hidden');
    }
  });
  
  // Show/hide no results message
  if (visibleCount === 0) {
    noResults.style.display = 'block';
    productsContainer.style.display = 'none';
  } else {
    noResults.style.display = 'none';
    productsContainer.style.display = 'flex';
  }
  
  // Update search stats
  if (searchTerm || selectedCategory) {
    searchStats.style.display = 'block';
    searchStats.innerHTML = `Showing <strong>${visibleCount}</strong> of <strong>${allProducts.length}</strong> products`;
  } else {
    searchStats.style.display = 'none';
  }
  
  // Show/hide clear button
  clearBtn.style.display = searchTerm ? 'block' : 'none';
}

// Event listeners
searchInput.addEventListener('input', performSearch);
categoryFilter.addEventListener('change', performSearch);

clearBtn.addEventListener('click', () => {
  searchInput.value = '';
  categoryFilter.value = '';
  performSearch();
  searchInput.focus();
});

// Keyboard shortcut: Ctrl/Cmd + K to focus search
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    searchInput.focus();
  }
});

// Initial search on page load (in case of URL parameters)
window.addEventListener('DOMContentLoaded', performSearch);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
