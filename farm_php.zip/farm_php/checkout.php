<?php 
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

// Handle POST request BEFORE loading header
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  // Expect JSON cart in POST 'cart'
  $cart = json_decode(file_get_contents('php://input'), true);
  
  // Debug logging
  error_log("Checkout POST received");
  error_log("Cart data: " . print_r($cart, true));
  
  if (!$cart || !is_array($cart) || count($cart) === 0) { 
    error_log("Empty or invalid cart");
    http_response_code(400); 
    header('Content-Type: application/json');
    echo json_encode(['error'=>'Empty cart']); 
    exit; 
  }
  
  $buyer = current_user();
  if (!$buyer) {
    error_log("User not logged in");
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['error'=>'Please login to place order']);
    exit;
  }
  
  error_log("Buyer ID: " . $buyer['id']);
  
  $pdo->beginTransaction();
  try {
    foreach($cart as $item){
      // Validate item structure
      if (!isset($item['id']) || !isset($item['qty'])) {
        throw new Exception('Invalid cart item structure');
      }
      
      // Find product
      $stmt = $pdo->prepare('SELECT * FROM products WHERE id=? FOR UPDATE');
      $stmt->execute([$item['id']]);
      $p = $stmt->fetch();
      
      if (!$p) throw new Exception('Product not found: ' . $item['id']);
      if ($p['quantity'] < $item['qty']) throw new Exception('Insufficient stock for '. $p['name']);
      
      $total = $p['price'] * $item['qty'];
      
      error_log("Creating order: buyer={$buyer['id']}, product={$p['id']}, qty={$item['qty']}, total={$total}");
      
      $stmt2 = $pdo->prepare('INSERT INTO orders (buyer_id,product_id,quantity,total_price,status,order_date) VALUES (?,?,?,?,"pending",NOW())');
      $stmt2->execute([$buyer['id'],$p['id'],$item['qty'],$total]);
      
      $stmt3 = $pdo->prepare('UPDATE products SET quantity=quantity-? WHERE id=?');
      $stmt3->execute([$item['qty'],$p['id']]);
    }
    $pdo->commit();
    error_log("Order placed successfully");
    header('Content-Type: application/json');
    echo json_encode(['success'=>true]); 
    exit;
  } catch (Exception $e){ 
    $pdo->rollBack(); 
    error_log("Order error: " . $e->getMessage());
    http_response_code(500); 
    header('Content-Type: application/json');
    echo json_encode(['error'=>$e->getMessage()]); 
    exit; 
  }
}

// Check if user is logged in BEFORE loading header
if (!is_logged_in()) { 
  header('Location: ' . BASE_PATH . '/login.php'); 
  exit; 
}

// Only load header for GET requests (viewing the checkout page)
require_once __DIR__ . '/includes/header.php'; 
?>
<h1>Checkout</h1>
<div id="checkout-root"><p>Loading checkout...</p></div>
<script>
const BASE_PATH = '<?= BASE_PATH ?>';

function renderCheckout() {
  // Check if app is loaded
  if (!window.app || !window.app.getCart) {
    document.getElementById('checkout-root').innerHTML = '<div class="alert alert-danger">Error loading cart. Please <a href="' + BASE_PATH + '/cart.php">go back to cart</a>.</div>';
    return;
  }
  
  const cart = window.app.getCart();
  console.log('Checkout cart:', cart);
  
  if (!cart.length) {
    document.getElementById('checkout-root').innerHTML = '<div class="alert alert-info">Cart is empty. <a href="' + BASE_PATH + '/shop.php">Start shopping</a></div>';
    return;
  }
  
  // Calculate totals
  let subtotal = 0;
  let html = '<div class="card mb-4"><div class="card-body">';
  html += '<h4>Order Summary</h4>';
  html += '<table class="table"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>';
  
  cart.forEach(item => {
    const itemTotal = item.price * item.qty;
    subtotal += itemTotal;
    html += `<tr>
      <td>${item.name}</td>
      <td>${item.qty}</td>
      <td>₹${parseFloat(item.price).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
      <td>₹${itemTotal.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
    </tr>`;
  });
  
  html += '</tbody></table>';
  html += `<div class="text-end"><h5>Total: ₹${subtotal.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</h5></div>`;
  html += '</div></div>';
  
  html += '<div class="d-flex gap-2">';
  html += '<button id="place-order-btn" class="btn btn-success btn-lg">Place Order</button>';
  html += '<a href="' + BASE_PATH + '/cart.php" class="btn btn-secondary btn-lg">Back to Cart</a>';
  html += '</div>';
  
  document.getElementById('checkout-root').innerHTML = html;
  
  // Add event listener for place order button
  document.getElementById('place-order-btn').addEventListener('click', async function() {
    this.disabled = true;
    this.innerHTML = 'Processing...';
    
    console.log('Placing order with cart:', cart);
    
    try {
      const res = await fetch(BASE_PATH + '/checkout.php', {
        method: 'POST',
        body: JSON.stringify(cart),
        headers: {'Content-Type': 'application/json'}
      });
      
      console.log('Response status:', res.status);
      const responseText = await res.text();
      console.log('Response text:', responseText);
      
      let j;
      try {
        j = JSON.parse(responseText);
      } catch (parseError) {
        console.error('JSON parse error:', parseError);
        console.error('Response was:', responseText);
        alert('Server error: Invalid response. Check browser console for details.');
        this.disabled = false;
        this.innerHTML = 'Place Order';
        return;
      }
      
      if (j.success) {
        localStorage.removeItem('farm_cart_v1');
        alert('Order placed successfully!');
        window.location.href = BASE_PATH + '/orders.php';
      } else {
        alert('Error: ' + (j.error || 'Unknown error occurred'));
        this.disabled = false;
        this.innerHTML = 'Place Order';
      }
    } catch (error) {
      console.error('Checkout error:', error);
      alert('Error placing order: ' + error.message + '. Check browser console for details.');
      this.disabled = false;
      this.innerHTML = 'Place Order';
    }
  });
}

// Wait for page to load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', renderCheckout);
} else {
  renderCheckout();
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
