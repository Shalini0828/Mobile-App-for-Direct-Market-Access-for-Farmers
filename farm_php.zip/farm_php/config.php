<?php
/**
 * ============================================
 * FarmConnect - Main Configuration File
 * ============================================
 * This file contains all configuration settings
 * for the Farmer Marketplace application
 */

// ============================================
// APPLICATION SETTINGS
// ============================================
define('APP_NAME', 'FarmConnect');
define('APP_VERSION', '1.0.0');
define('APP_ENV', 'development'); // development, production

// ============================================
// URL CONFIGURATION
// ============================================
define('BASE_PATH', '/farm_php');
define('SITE_NAME', 'Farmer Marketplace');
define('SITE_URL', 'http://localhost' . BASE_PATH);

// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'farm_marketplace');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ============================================
// FILE UPLOAD SETTINGS
// ============================================
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('PRODUCT_UPLOAD_PATH', UPLOAD_PATH . 'products/');
define('MAX_FILE_SIZE', 10485760); // 10MB in bytes
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// ============================================
// PAGINATION SETTINGS
// ============================================
define('PRODUCTS_PER_PAGE', 12);
define('ORDERS_PER_PAGE', 20);
define('USERS_PER_PAGE', 50);

// ============================================
// SESSION SETTINGS
// ============================================
define('SESSION_NAME', 'FARMCONNECT_SESSION');
define('SESSION_LIFETIME', 86400); // 24 hours

// ============================================
// EMAIL SETTINGS (For future use)
// ============================================
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-password');
define('FROM_EMAIL', 'noreply@farmconnect.com');
define('FROM_NAME', 'FarmConnect');

// ============================================
// PAYMENT SETTINGS (For future use)
// ============================================
define('PAYMENT_GATEWAY', 'stripe'); // stripe, paypal, razorpay
define('PAYMENT_CURRENCY', 'INR');
define('TAX_RATE', 0.00); // 0% tax

// ============================================
// SECURITY SETTINGS
// ============================================
define('ENABLE_CSRF_PROTECTION', true);
define('PASSWORD_MIN_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); // 15 minutes

// ============================================
// DISPLAY SETTINGS
// ============================================
define('DEFAULT_TIMEZONE', 'Asia/Kolkata');
define('DATE_FORMAT', 'Y-m-d H:i:s');
define('DISPLAY_DATE_FORMAT', 'd M Y');
define('ITEMS_IN_CART_BADGE', true);

// ============================================
// PRODUCT CATEGORIES
// ============================================
define('PRODUCT_CATEGORIES', [
    'Vegetables',
    'Fruits',
    'Dairy',
    'Grains',
    'Meat',
    'Eggs',
    'Honey',
    'Other'
]);

// ============================================
// ORDER STATUS
// ============================================
define('ORDER_STATUSES', [
    'pending' => 'Pending',
    'confirmed' => 'Confirmed',
    'shipped' => 'Shipped',
    'delivered' => 'Delivered',
    'cancelled' => 'Cancelled'
]);

// ============================================
// USER ROLES
// ============================================
define('USER_ROLES', [
    'admin' => 'Administrator',
    'farmer' => 'Farmer/Seller',
    'buyer' => 'Buyer/Customer'
]);

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Get base URL with optional path
 */
function base_url($path = '') {
    return BASE_PATH . ($path ? '/' . ltrim($path, '/') : '');
}

/**
 * Get full site URL with optional path
 */
function site_url($path = '') {
    return SITE_URL . ($path ? '/' . ltrim($path, '/') : '/');
}

/**
 * Get asset URL
 */
function asset($path) {
    return BASE_PATH . '/assets/' . ltrim($path, '/');
}

/**
 * Get upload URL
 */
function upload_url($path) {
    return BASE_PATH . '/uploads/' . ltrim($path, '/');
}

/**
 * Format price
 */
function format_price($price) {
    return '₹' . number_format($price, 2);
}

/**
 * Format date
 */
function format_date($date) {
    return date(DISPLAY_DATE_FORMAT, strtotime($date));
}

/**
 * Sanitize input
 */
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Redirect to URL
 */
function redirect($path = '') {
    header('Location: ' . base_url($path));
    exit;
}

/**
 * Check if file is image
 */
function is_valid_image($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ALLOWED_IMAGE_TYPES);
}

/**
 * Generate random string
 */
function generate_random_string($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Debug function
 */
function debug($data, $die = false) {
    if (APP_ENV === 'development') {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
        if ($die) die();
    }
}

// ============================================
// TIMEZONE SETTING
// ============================================
date_default_timezone_set(DEFAULT_TIMEZONE);

// ============================================
// ERROR REPORTING
// ============================================
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ============================================
// SESSION START
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

?>
