<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'buyer';
    
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, ?, NOW())');
    
    try {
        $stmt->execute([$name, $email, $hash, $role]);
        $userId = $pdo->lastInsertId();
        
        // Fetch the complete user data and store in session
        $stmt2 = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt2->execute([$userId]);
        $user = $stmt2->fetch();
        
        $_SESSION['user'] = $user; // Store full user object
        header('Location: ' . BASE_PATH . '/');
        exit;
    } catch (Exception $e) {
        $error = 'Could not register. Email may already exist.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - FarmConnect</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        .register-card {
            max-width: 550px;
            width: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .register-header {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .register-header i {
            font-size: 4rem;
            margin-bottom: 15px;
        }
        .register-header h2 {
            font-weight: 700;
            margin-bottom: 5px;
        }
        .register-body {
            padding: 40px;
        }
        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        .input-group {
            margin-bottom: 20px;
        }
        .input-group-text {
            background: #f8f9fa;
            border-right: none;
            padding: 12px 15px;
        }
        .form-control, .form-select {
            border-left: none;
            padding: 12px 15px;
            font-size: 1rem;
        }
        .form-control:focus, .form-select:focus {
            border-color: #11998e;
            box-shadow: 0 0 0 0.2rem rgba(17, 153, 142, 0.25);
        }
        .role-selector {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 25px;
        }
        .role-option {
            position: relative;
        }
        .role-option input[type="radio"] {
            position: absolute;
            opacity: 0;
        }
        .role-option label {
            display: block;
            padding: 20px;
            border: 2px solid #ddd;
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: white;
        }
        .role-option label i {
            font-size: 2.5rem;
            display: block;
            margin-bottom: 10px;
            color: #11998e;
        }
        .role-option label span {
            font-weight: 600;
            color: #333;
        }
        .role-option input[type="radio"]:checked + label {
            border-color: #11998e;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        .role-option input[type="radio"]:checked + label i,
        .role-option input[type="radio"]:checked + label span {
            color: white;
        }
        .btn-register {
            width: 100%;
            padding: 14px;
            font-size: 1.1rem;
            font-weight: 600;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            border: none;
            border-radius: 10px;
            color: white;
            transition: transform 0.2s;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(17, 153, 142, 0.4);
        }
        .divider {
            text-align: center;
            margin: 25px 0;
            position: relative;
        }
        .divider:before {
            content: "";
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #ddd;
        }
        .divider span {
            background: white;
            padding: 0 15px;
            position: relative;
            color: #999;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #11998e;
            font-weight: 600;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .back-home {
            text-align: center;
            margin-top: 15px;
        }
        .back-home a {
            color: #999;
            text-decoration: none;
            font-size: 0.95rem;
        }
        .back-home a:hover {
            color: #11998e;
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="register-header">
            <i class="bi bi-person-plus-fill"></i>
            <h2>Join FarmConnect</h2>
            <p class="mb-0">Create your account today</p>
        </div>
        <div class="register-body">
            <?php if ($error): ?>
                <div class="alert alert-danger d-flex align-items-center">
                    <i class="bi bi-exclamation-circle-fill me-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>
            
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                        <input type="text" class="form-control" name="name" placeholder="Enter your full name" required autofocus>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                        <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" class="form-control" name="password" placeholder="Create a password" required minlength="6">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">I want to:</label>
                    <div class="role-selector">
                        <div class="role-option">
                            <input type="radio" name="role" value="buyer" id="role-buyer" checked>
                            <label for="role-buyer">
                                <i class="bi bi-cart-fill"></i>
                                <span>Buy Products</span>
                            </label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" value="farmer" id="role-farmer">
                            <label for="role-farmer">
                                <i class="bi bi-tree-fill"></i>
                                <span>Sell Products</span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-register">
                    <i class="bi bi-check-circle me-2"></i>Create Account
                </button>
            </form>
            
            <div class="divider">
                <span>OR</span>
            </div>
            
            <div class="login-link">
                <p class="mb-0">Already have an account? <a href="<?= BASE_PATH ?>/login.php">Sign in here</a></p>
            </div>
            
            <div class="back-home">
                <a href="<?= BASE_PATH ?>/"><i class="bi bi-arrow-left me-1"></i>Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
