-- ============================================
-- FarmConnect Database Schema
-- Complete SQL Script for Database Creation
-- ============================================

-- Drop database if exists and create fresh
DROP DATABASE IF EXISTS farm_marketplace;
CREATE DATABASE farm_marketplace CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farm_marketplace;

-- ============================================
-- Table: users
-- Stores all users (admin, farmers, buyers)
-- ============================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'farmer', 'buyer') NOT NULL DEFAULT 'buyer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: products
-- Stores all products listed by farmers
-- ============================================
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    farmer_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    category VARCHAR(100) DEFAULT 'Other',
    status ENUM('active', 'inactive', 'out_of_stock') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_farmer (farmer_id),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: orders
-- Stores all orders placed by buyers
-- ============================================
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'shipped', 'delivered', 'cancelled') NOT NULL DEFAULT 'pending',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    delivery_address TEXT,
    payment_method VARCHAR(50) DEFAULT 'COD',
    notes TEXT,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_buyer (buyer_id),
    INDEX idx_product (product_id),
    INDEX idx_status (status),
    INDEX idx_order_date (order_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: cart (optional - for database-driven cart)
-- Currently using localStorage, but this is for future
-- ============================================
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, product_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: reviews (optional - for product reviews)
-- For future feature implementation
-- ============================================
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_product (product_id),
    INDEX idx_user (user_id),
    INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: categories (optional - for category management)
-- For future feature implementation
-- ============================================
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Insert Sample Data
-- ============================================

-- Insert Admin Users
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Super Admin', 'admin@f.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- Password for both admins: admin123

-- Insert Sample Farmers
INSERT INTO users (name, email, password, role) VALUES
('John Farmer', 'farmer1@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer'),
('Mary Agriculture', 'farmer2@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer'),
('Green Fields Co.', 'farmer3@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer');
-- Password for all farmers: farmer123

-- Insert Sample Buyers
INSERT INTO users (name, email, password, role) VALUES
('Alice Buyer', 'buyer1@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer'),
('Bob Customer', 'buyer2@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer'),
('Charlie Smith', 'buyer3@farm.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer');
-- Password for all buyers: buyer123

-- Insert Sample Products
INSERT INTO products (farmer_id, name, description, price, quantity, category, status) VALUES
(3, 'Organic Tomatoes', 'Fresh organic tomatoes from local farm. Rich in vitamins and minerals.', 3.99, 100, 'Vegetables', 'active'),
(3, 'Fresh Milk', 'Pure farm-fresh milk, collected daily. No hormones or antibiotics.', 2.50, 50, 'Dairy', 'active'),
(3, 'Free Range Eggs', 'Farm fresh eggs from free-range chickens. Pack of 12.', 4.99, 80, 'Dairy', 'active'),
(4, 'Organic Carrots', 'Crunchy organic carrots, perfect for salads and cooking.', 2.99, 120, 'Vegetables', 'active'),
(4, 'Sweet Corn', 'Fresh sweet corn, harvested this morning. Perfect for grilling.', 1.99, 150, 'Vegetables', 'active'),
(4, 'Honey Jar', 'Pure natural honey from local bees. 500g jar.', 8.99, 30, 'Other', 'active'),
(5, 'Apple Basket', 'Fresh crispy apples, perfect for snacking. 2kg basket.', 5.99, 60, 'Fruits', 'active'),
(5, 'Strawberries', 'Sweet and juicy strawberries. 500g punnet.', 4.50, 40, 'Fruits', 'active'),
(5, 'Lettuce Head', 'Fresh green lettuce, perfect for salads. Organic certified.', 1.99, 90, 'Vegetables', 'active'),
(5, 'Potato Bag', 'Farm-fresh potatoes, ideal for all cooking methods. 5kg bag.', 6.99, 70, 'Vegetables', 'active'),
(3, 'Cucumber', 'Crisp and fresh cucumbers, great for salads and pickles.', 1.50, 110, 'Vegetables', 'active'),
(4, 'Bell Peppers', 'Colorful bell peppers, rich in vitamins. Mixed colors.', 3.50, 85, 'Vegetables', 'active'),
(5, 'Orange Bag', 'Sweet and juicy oranges, packed with vitamin C. 2kg bag.', 5.50, 55, 'Fruits', 'active'),
(3, 'Cheese Block', 'Artisan farm cheese, aged to perfection. 500g block.', 9.99, 25, 'Dairy', 'active'),
(4, 'Pumpkin', 'Large organic pumpkin, perfect for soups and pies.', 4.99, 35, 'Vegetables', 'active');

-- Insert Sample Orders
INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, delivery_address) VALUES
(6, 1, 2, 7.98, 'delivered', '123 Main St, City, State 12345'),
(6, 3, 1, 4.99, 'confirmed', '123 Main St, City, State 12345'),
(7, 4, 3, 8.97, 'pending', '456 Oak Ave, Town, State 67890'),
(7, 7, 1, 5.99, 'shipped', '456 Oak Ave, Town, State 67890'),
(8, 2, 2, 5.00, 'delivered', '789 Pine Rd, Village, State 11223'),
(8, 8, 2, 9.00, 'confirmed', '789 Pine Rd, Village, State 11223'),
(6, 5, 5, 9.95, 'pending', '123 Main St, City, State 12345'),
(7, 10, 1, 6.99, 'delivered', '456 Oak Ave, Town, State 67890');

-- Insert Sample Categories
INSERT INTO categories (name, description, icon) VALUES
('Vegetables', 'Fresh vegetables from local farms', 'bi-basket'),
('Fruits', 'Seasonal fresh fruits', 'bi-apple'),
('Dairy', 'Milk, cheese, and dairy products', 'bi-cup-straw'),
('Grains', 'Rice, wheat, and other grains', 'bi-grain'),
('Meat', 'Fresh meat products', 'bi-meat'),
('Eggs', 'Farm fresh eggs', 'bi-egg'),
('Honey', 'Natural honey products', 'bi-droplet'),
('Other', 'Other farm products', 'bi-box');

-- ============================================
-- Create Views for Common Queries
-- ============================================

-- View: Active Products with Farmer Details
CREATE VIEW v_active_products AS
SELECT 
    p.*,
    u.name AS farmer_name,
    u.email AS farmer_email
FROM products p
JOIN users u ON p.farmer_id = u.id
WHERE p.status = 'active' AND p.quantity > 0;

-- View: Order Details with Buyer and Product Info
CREATE VIEW v_order_details AS
SELECT 
    o.*,
    u.name AS buyer_name,
    u.email AS buyer_email,
    p.name AS product_name,
    p.image AS product_image,
    f.name AS farmer_name
FROM orders o
JOIN users u ON o.buyer_id = u.id
JOIN products p ON o.product_id = p.id
JOIN users f ON p.farmer_id = f.id;

-- View: Product Statistics
CREATE VIEW v_product_stats AS
SELECT 
    p.id,
    p.name,
    p.farmer_id,
    u.name AS farmer_name,
    COUNT(o.id) AS total_orders,
    SUM(o.quantity) AS total_sold,
    SUM(o.total_price) AS total_revenue
FROM products p
JOIN users u ON p.farmer_id = u.id
LEFT JOIN orders o ON p.id = o.product_id
GROUP BY p.id, p.name, p.farmer_id, u.name;

-- ============================================
-- Stored Procedures
-- ============================================

DELIMITER $$

-- Procedure: Place Order
CREATE PROCEDURE sp_place_order(
    IN p_buyer_id INT,
    IN p_product_id INT,
    IN p_quantity INT,
    IN p_delivery_address TEXT
)
BEGIN
    DECLARE v_price DECIMAL(10,2);
    DECLARE v_available_qty INT;
    DECLARE v_total DECIMAL(10,2);
    
    -- Get product price and available quantity
    SELECT price, quantity INTO v_price, v_available_qty
    FROM products
    WHERE id = p_product_id;
    
    -- Check if enough quantity available
    IF v_available_qty >= p_quantity THEN
        SET v_total = v_price * p_quantity;
        
        -- Insert order
        INSERT INTO orders (buyer_id, product_id, quantity, total_price, delivery_address)
        VALUES (p_buyer_id, p_product_id, p_quantity, v_total, p_delivery_address);
        
        -- Update product quantity
        UPDATE products
        SET quantity = quantity - p_quantity
        WHERE id = p_product_id;
        
        SELECT 'Order placed successfully' AS message, LAST_INSERT_ID() AS order_id;
    ELSE
        SELECT 'Insufficient quantity available' AS message, 0 AS order_id;
    END IF;
END$$

-- Procedure: Update Order Status
CREATE PROCEDURE sp_update_order_status(
    IN p_order_id INT,
    IN p_status VARCHAR(20)
)
BEGIN
    UPDATE orders
    SET status = p_status,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_order_id;
    
    SELECT 'Order status updated' AS message;
END$$

-- Procedure: Get Farmer Dashboard Stats
CREATE PROCEDURE sp_farmer_dashboard(
    IN p_farmer_id INT
)
BEGIN
    SELECT 
        COUNT(DISTINCT p.id) AS total_products,
        COUNT(DISTINCT o.id) AS total_orders,
        SUM(o.total_price) AS total_revenue,
        COUNT(CASE WHEN o.status = 'pending' THEN 1 END) AS pending_orders
    FROM products p
    LEFT JOIN orders o ON p.id = o.product_id
    WHERE p.farmer_id = p_farmer_id;
END$$

DELIMITER ;

-- ============================================
-- Triggers
-- ============================================

DELIMITER $$

-- Trigger: Update product status when quantity becomes 0
CREATE TRIGGER trg_update_product_status
BEFORE UPDATE ON products
FOR EACH ROW
BEGIN
    IF NEW.quantity <= 0 THEN
        SET NEW.status = 'out_of_stock';
    ELSEIF NEW.quantity > 0 AND OLD.status = 'out_of_stock' THEN
        SET NEW.status = 'active';
    END IF;
END$$

-- Trigger: Prevent order if product out of stock
CREATE TRIGGER trg_check_product_availability
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
    DECLARE v_qty INT;
    SELECT quantity INTO v_qty FROM products WHERE id = NEW.product_id;
    
    IF v_qty < NEW.quantity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Product quantity not available';
    END IF;
END$$

DELIMITER ;

-- ============================================
-- Grant Permissions (if needed)
-- ============================================

-- For development, grant all privileges to root
-- GRANT ALL PRIVILEGES ON farm_marketplace.* TO 'root'@'localhost';
-- FLUSH PRIVILEGES;

-- ============================================
-- Database Statistics
-- ============================================

SELECT 
    'Database created successfully!' AS status,
    (SELECT COUNT(*) FROM users) AS total_users,
    (SELECT COUNT(*) FROM products) AS total_products,
    (SELECT COUNT(*) FROM orders) AS total_orders;

-- ============================================
-- End of Database Schema
-- ============================================
