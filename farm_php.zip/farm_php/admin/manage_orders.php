<?php require_once __DIR__ . '/../includes/header.php'; require_once __DIR__ . '/../includes/db.php'; require_any_role(['admin']);
if(isset($_GET['set_status']) && isset($_GET['id'])){
  $stmt=$pdo->prepare('UPDATE orders SET status=? WHERE id=?'); $stmt->execute([$_GET['set_status'],intval($_GET['id'])]); header('Location: ' . BASE_PATH . '/admin/manage_orders.php'); exit;
}
try {
  $orders = $pdo->query('SELECT o.*, p.name as product_name, u.name as buyer_name FROM orders o JOIN products p ON o.product_id=p.id JOIN users u ON o.buyer_id=u.id ORDER BY o.order_date DESC')->fetchAll();
} catch (PDOException $e) {
  // Fallback: load orders and resolve product and buyer names per-row
  $rows = $pdo->query('SELECT * FROM orders ORDER BY order_date DESC')->fetchAll();
  $orders = [];
  foreach ($rows as $r) {
    $r['product_name'] = null; $r['buyer_name'] = null;
    if (!empty($r['product_id'])) {
      $pstmt = $pdo->prepare('SELECT name FROM products WHERE id=?'); $pstmt->execute([$r['product_id']]); $p = $pstmt->fetch(); if ($p) $r['product_name']=$p['name'];
    }
    if (!empty($r['buyer_id'])) {
      $ustmt = $pdo->prepare('SELECT name FROM users WHERE id=?'); $ustmt->execute([$r['buyer_id']]); $urow = $ustmt->fetch(); if ($urow) $r['buyer_name']=$urow['name'];
    }
    $orders[] = $r;
  }
}
?>
<h1>Manage Orders</h1>
<table class="table"><thead><tr><th>Product</th><th>Buyer</th><th>Qty</th><th>Total</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($orders as $o): ?>
  <tr>
    <td><?=htmlspecialchars($o['product_name'])?></td>
    <td><?=htmlspecialchars($o['buyer_name'])?></td>
    <td><?=$o['quantity']?></td>
    <td>₹<?=number_format($o['total_price'],2)?></td>
    <td><?=htmlspecialchars($o['status'])?></td>
    <td><a href="?id=<?=$o['id']?>&set_status=confirmed">Confirm</a> | <a href="?id=<?=$o['id']?>&set_status=delivered">Delivered</a></td>
  </tr>
<?php endforeach; ?>
</tbody></table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
