<?php require_once __DIR__ . '/../includes/admin_header.php'; require_once __DIR__ . '/../includes/db.php'; require_any_role(['admin']);
$products = $pdo->query('SELECT p.*, u.name as farmer_name FROM products p JOIN users u ON p.farmer_id=u.id')->fetchAll();
?>
<h1>Manage Products</h1>
<table class="table"><thead><tr><th>Name</th><th>Farmer</th><th>Price</th><th>Qty</th></tr></thead><tbody>
<?php foreach($products as $p): ?><tr><td><?=htmlspecialchars($p['name'])?></td><td><?=htmlspecialchars($p['farmer_name'])?></td><td>₹<?=number_format($p['price'],2)?></td><td><?=$p['quantity']?></td></tr><?php endforeach; ?>
</tbody></table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
