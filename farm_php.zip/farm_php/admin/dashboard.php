<?php 
require_once __DIR__ . '/../includes/admin_header.php'; 
require_once __DIR__ . '/../includes/db.php';
require_any_role(['admin']);
$u = current_user();

// Get statistics
$tot = [];
$tot['farmers'] = $pdo->query("SELECT COUNT(*) as c FROM users WHERE role='farmer'")->fetch()['c'];
$tot['buyers'] = $pdo->query("SELECT COUNT(*) as c FROM users WHERE role='buyer'")->fetch()['c'];
$tot['products'] = $pdo->query("SELECT COUNT(*) as c FROM products")->fetch()['c'];
$tot['orders'] = $pdo->query("SELECT COUNT(*) as c FROM orders")->fetch()['c'];
$tot['pending_orders'] = $pdo->query("SELECT COUNT(*) as c FROM orders WHERE status='pending'")->fetch()['c'];
$tot['revenue'] = $pdo->query("SELECT SUM(total_price) as r FROM orders")->fetch()['r'] ?? 0;
$tot['active_products'] = $pdo->query("SELECT COUNT(*) as c FROM products WHERE status='active' AND quantity > 0")->fetch()['c'];

// Get recent activity
$recentOrders = $pdo->query("SELECT o.*, u.name as buyer_name, p.name as product_name FROM orders o 
                            JOIN users u ON o.user_id=u.id 
                            JOIN products p ON o.product_id=p.id 
                            ORDER BY o.created_at DESC LIMIT 5")->fetchAll();

$recentUsers = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>

<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="display-5 fw-bold mb-2">
                        <i class="bi bi-speedometer2 text-primary"></i> Admin Dashboard
                    </h1>
                    <p class="text-muted mb-0">Welcome back, <?= htmlspecialchars($u['name']) ?>! Manage your marketplace</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row 1 -->
    <div class="row g-4 mb-4">
        <!-- Total Farmers -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Farmers</h6>
                            <h2 class="fw-bold mb-0"><?= $tot['farmers'] ?></h2>
                            <small class="text-success">
                                <i class="bi bi-person-plus"></i> Active
                            </small>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-person-badge text-primary" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Buyers -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Buyers</h6>
                            <h2 class="fw-bold mb-0"><?= $tot['buyers'] ?></h2>
                            <small class="text-info">
                                <i class="bi bi-cart"></i> Shopping
                            </small>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-people text-success" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Products -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Products</h6>
                            <h2 class="fw-bold mb-0"><?= $tot['products'] ?></h2>
                            <small class="text-success">
                                <?= $tot['active_products'] ?> active
                            </small>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-box-seam text-warning" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Orders -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 hover-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-2" style="font-size: 0.8rem;">Total Orders</h6>
                            <h2 class="fw-bold mb-0"><?= $tot['orders'] ?></h2>
                            <small class="text-warning">
                                <?= $tot['pending_orders'] ?> pending
                            </small>
                        </div>
                        <div class="bg-info bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-cart-check text-info" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Revenue Card -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <div class="card-body text-white py-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="fw-bold mb-2">
                                <i class="bi bi-currency-rupee"></i> Total Revenue
                            </h3>
                            <h1 class="display-4 fw-bold mb-0"><?= format_price($tot['revenue']) ?></h1>
                            <p class="mb-0 mt-2 opacity-75">From all completed transactions</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <i class="bi bi-graph-up-arrow" style="font-size: 5rem; opacity: 0.3;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title fw-bold mb-3">
                        <i class="bi bi-lightning-charge-fill text-warning"></i> Quick Actions
                    </h5>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="<?= BASE_PATH ?>/admin/manage_users.php" class="btn btn-primary btn-lg">
                            <i class="bi bi-people"></i> Manage Users
                        </a>
                        <a href="<?= BASE_PATH ?>/admin/manage_products.php" class="btn btn-warning btn-lg">
                            <i class="bi bi-box-seam"></i> Manage Products
                        </a>
                        <a href="<?= BASE_PATH ?>/admin/manage_orders.php" class="btn btn-info btn-lg">
                            <i class="bi bi-cart-check"></i> Manage Orders
                        </a>
                        <a href="<?= BASE_PATH ?>/shop.php" class="btn btn-outline-secondary btn-lg">
                            <i class="bi bi-shop"></i> View Shop
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="row">
        <!-- Recent Orders -->
        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-clock-history text-primary"></i> Recent Orders
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php if(empty($recentOrders)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-3 mb-0">No orders yet</p>
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach($recentOrders as $order): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1 fw-semibold"><?= htmlspecialchars($order['product_name']) ?></h6>
                                            <p class="mb-1 small text-muted">
                                                <i class="bi bi-person"></i> <?= htmlspecialchars($order['buyer_name']) ?>
                                            </p>
                                            <small class="text-muted">
                                                <i class="bi bi-clock"></i> <?= date('M d, Y', strtotime($order['created_at'])) ?>
                                            </small>
                                        </div>
                                        <div class="text-end">
                                            <div class="fw-bold text-success"><?= format_price($order['total_price']) ?></div>
                                            <?php 
                                            $statusColors = [
                                                'pending' => 'warning',
                                                'completed' => 'success',
                                                'cancelled' => 'danger'
                                            ];
                                            $color = $statusColors[$order['status']] ?? 'secondary';
                                            ?>
                                            <span class="badge bg-<?= $color ?> mt-1"><?= ucfirst($order['status']) ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(!empty($recentOrders)): ?>
                    <div class="card-footer bg-white text-center">
                        <a href="<?= BASE_PATH ?>/admin/manage_orders.php" class="text-decoration-none">
                            View All Orders <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Users -->
        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-person-plus text-success"></i> Recent Users
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php if(empty($recentUsers)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-3 mb-0">No users yet</p>
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach($recentUsers as $user): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1 fw-semibold"><?= htmlspecialchars($user['name']) ?></h6>
                                            <p class="mb-1 small text-muted">
                                                <i class="bi bi-envelope"></i> <?= htmlspecialchars($user['email']) ?>
                                            </p>
                                            <small class="text-muted">
                                                <i class="bi bi-clock"></i> Joined <?= date('M d, Y', strtotime($user['created_at'])) ?>
                                            </small>
                                        </div>
                                        <div>
                                            <?php 
                                            $roleColors = [
                                                'admin' => 'danger',
                                                'farmer' => 'primary',
                                                'buyer' => 'success'
                                            ];
                                            $color = $roleColors[$user['role']] ?? 'secondary';
                                            ?>
                                            <span class="badge bg-<?= $color ?>"><?= ucfirst($user['role']) ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(!empty($recentUsers)): ?>
                    <div class="card-footer bg-white text-center">
                        <a href="<?= BASE_PATH ?>/admin/manage_users.php" class="text-decoration-none">
                            View All Users <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.hover-card {
    transition: all 0.3s ease;
}
.hover-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
}
.list-group-item {
    transition: all 0.2s ease;
}
.list-group-item:hover {
    background-color: rgba(0,0,0,0.02);
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
