<?php require_once __DIR__ . '/../includes/config.php'; require_once __DIR__ . '/../includes/db.php'; 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SERVER['REQUEST_METHOD']==='POST'){
  $stmt=$pdo->prepare('SELECT * FROM users WHERE email=? AND role="admin"'); 
  $stmt->execute([$_POST['email']]); 
  $u=$stmt->fetch();
  if($u && password_verify($_POST['password'],$u['password'])){ 
    $_SESSION['user']=$u; 
    header('Location: ' . BASE_PATH . '/admin/dashboard.php'); 
    exit; 
  } else { 
    $err='Invalid email or password'; 
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Login - Farmer Marketplace</title>
  <link rel="stylesheet" href="<?= BASE_PATH ?>/assets/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <style>
    body {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-card {
      max-width: 400px;
      width: 100%;
    }
  </style>
</head>
<body>
  <div class="login-card">
    <div class="card shadow-lg">
      <div class="card-body p-5">
        <div class="text-center mb-4">
          <i class="bi bi-shield-lock-fill text-primary" style="font-size: 4rem;"></i>
          <h2 class="mt-3">Admin Login</h2>
          <p class="text-muted">Farmer Marketplace</p>
        </div>
        
        <?php if(!empty($err)): ?>
          <div class="alert alert-danger">
            <i class="bi bi-exclamation-triangle"></i> <?=htmlspecialchars($err)?>
          </div>
        <?php endif; ?>
        
        <form method="post">
          <div class="mb-3">
            <label class="form-label"><i class="bi bi-envelope"></i> Email</label>
            <input type="email" name="email" class="form-control form-control-lg" placeholder="admin@example.com" required>
          </div>
          
          <div class="mb-4">
            <label class="form-label"><i class="bi bi-key"></i> Password</label>
            <input type="password" name="password" class="form-control form-control-lg" placeholder="Enter password" required>
          </div>
          
          <div class="d-grid">
            <button type="submit" class="btn btn-primary btn-lg">
              <i class="bi bi-box-arrow-in-right"></i> Login
            </button>
          </div>
        </form>
        
        <div class="text-center mt-4">
          <a href="<?= BASE_PATH ?>/" class="text-decoration-none">
            <i class="bi bi-arrow-left"></i> Back to Marketplace
          </a>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
