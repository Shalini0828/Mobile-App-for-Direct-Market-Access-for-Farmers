<?php require_once __DIR__ . '/../includes/admin_header.php'; require_once __DIR__ . '/../includes/db.php'; require_any_role(['admin']);
$users = $pdo->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll();
?>
<h1>Manage Users</h1>
<table class="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Since</th></tr></thead><tbody>
<?php foreach($users as $u): ?><tr><td><?=htmlspecialchars($u['name'])?></td><td><?=htmlspecialchars($u['email'])?></td><td><?=htmlspecialchars($u['role'])?></td><td><?=$u['created_at']?></td></tr><?php endforeach; ?>
</tbody></table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
