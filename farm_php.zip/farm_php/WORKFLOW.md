# FarmConnect - Complete Project Workflow

## 📁 Project Structure & Setup Guide

---

## 📂 Complete Folder Structure

```
farm_php/
│
├── 📁 admin/                          # Admin panel files
│   ├── dashboard.php                  # Admin dashboard with statistics
│   ├── login.php                      # Admin login page
│   ├── manage_orders.php              # Order management
│   ├── manage_products.php            # Product management
│   └── manage_users.php               # User management
│
├── 📁 assets/                         # Static assets
│   ├── css/                          # CSS files (create if needed)
│   │   └── custom.css
│   ├── js/                           # JavaScript files (create if needed)
│   │   └── custom.js
│   ├── images/                       # Site images (create if needed)
│   │   └── logo.png
│   ├── app.js                        # Main JavaScript (cart functions)
│   ├── style.css                     # Main stylesheet
│   └── placeholder.png               # Default product image
│
├── 📁 includes/                       # PHP includes
│   ├── admin_header.php              # Admin navigation header
│   ├── auth.php                      # Authentication functions
│   ├── config.php                    # Original configuration
│   ├── db.php                        # Database connection
│   ├── footer.php                    # Site footer
│   └── header.php                    # Main site header/navbar
│
├── 📁 uploads/                        # User uploaded files
│   └── products/                     # Product images
│       └── .gitkeep                  # Keep folder in git
│
├── 📁 logs/                          # Application logs (create)
│   ├── error.log
│   └── access.log
│
├── 📁 cache/                         # Cache files (create)
│   └── .gitkeep
│
├── 📁 sessions/                      # Session files (create)
│   └── .gitkeep
│
├── 📁 api/                           # API endpoints (create for future)
│   ├── products.php
│   ├── orders.php
│   └── users.php
│
├── 📁 vendor/                        # Composer dependencies (create if using)
│   └── autoload.php
│
├── 📄 Root Files
├── add_product.php                   # Add new product (farmer)
├── cart.php                          # Shopping cart page
├── checkout.php                      # Checkout and order placement
├── create_admin.php                  # Create admin user
├── database_schema.sql               # Complete database schema
├── edit_product.php                  # Edit product (farmer)
├── farmer_dashboard.php              # Farmer dashboard
├── farmer_orders.php                 # Farmer's orders view
├── farm_marketplace.sql              # Old database schema
├── index.php                         # Home page
├── login.php                         # User login
├── logout.php                        # Logout handler
├── orders.php                        # User orders history
├── product.php                       # Single product view
├── register.php                      # User registration
├── setup.php                         # Initial setup script
├── shop.php                          # Product listing/shop
│
├── 📄 Configuration Files
├── config.php                        # Main configuration (new)
├── .env                              # Environment variables
├── .env.example                      # Environment template
├── .htaccess                         # Apache configuration
├── .gitignore                        # Git ignore rules
├── composer.json                     # PHP dependencies (create if needed)
├── package.json                      # NPM dependencies (create if needed)
└── README.md                         # Project documentation
```

---

## 🚀 Setup Workflow

### Step 1: Server Requirements

- ✅ Apache 2.4+
- ✅ PHP 8.0+
- ✅ MySQL 5.7+ or MariaDB 10.3+
- ✅ XAMPP (recommended for Windows)

### Step 2: Installation Steps

#### A. Copy Project Files

```bash
# Windows (PowerShell)
Copy-Item -Path "D:\Clones\form connect php\*" -Destination "C:\xampp\htdocs\farm_php\" -Recurse -Force
```

#### B. Create Required Folders

```bash
# Create additional folders
New-Item -Path "C:\xampp\htdocs\farm_php\logs" -ItemType Directory -Force
New-Item -Path "C:\xampp\htdocs\farm_php\cache" -ItemType Directory -Force
New-Item -Path "C:\xampp\htdocs\farm_php\sessions" -ItemType Directory -Force
New-Item -Path "C:\xampp\htdocs\farm_php\api" -ItemType Directory -Force
New-Item -Path "C:\xampp\htdocs\farm_php\assets\css" -ItemType Directory -Force
New-Item -Path "C:\xampp\htdocs\farm_php\assets\js" -ItemType Directory -Force
New-Item -Path "C:\xampp\htdocs\farm_php\assets\images" -ItemType Directory -Force
```

#### C. Set Folder Permissions

```bash
# Windows - Grant write permissions to uploads, logs, cache, sessions
icacls "C:\xampp\htdocs\farm_php\uploads" /grant Everyone:F /T
icacls "C:\xampp\htdocs\farm_php\logs" /grant Everyone:F /T
icacls "C:\xampp\htdocs\farm_php\cache" /grant Everyone:F /T
icacls "C:\xampp\htdocs\farm_php\sessions" /grant Everyone:F /T
```

#### D. Configure Environment

1. Copy `.env.example` to `.env`
2. Update database credentials in `.env`
3. Update `config.php` if needed

#### E. Import Database

```bash
# Using MySQL command line
cd C:\xampp\mysql\bin
Get-Content "C:\xampp\htdocs\farm_php\database_schema.sql" | .\mysql.exe -u root

# Or use phpMyAdmin
# Visit: http://localhost/phpmyadmin
# Import: database_schema.sql
```

#### F. Start Servers

```bash
# Open XAMPP Control Panel
C:\xampp\xampp-control.exe

# Start Apache
# Start MySQL
```

---

## 📋 Development Workflow

### Phase 1: Frontend Development

1. **Design Pages**

   - Home page (`index.php`) ✅
   - Login page (`login.php`) ✅
   - Register page (`register.php`) ✅
   - Shop page (`shop.php`) ✅
   - Product detail (`product.php`) ✅
   - Cart page (`cart.php`) ✅

2. **Create Layouts**

   - Header/Navbar (`includes/header.php`) ✅
   - Footer (`includes/footer.php`) ✅
   - Admin header (`includes/admin_header.php`) ✅

3. **Add Styling**
   - Bootstrap 5.3.2 ✅
   - Custom CSS (`assets/style.css`) ✅
   - Bootstrap Icons ✅

### Phase 2: Backend Development

1. **Authentication System**

   - User registration ✅
   - User login ✅
   - Session management ✅
   - Role-based access ✅

2. **Product Management**

   - Add products ✅
   - Edit products ✅
   - Delete products ✅
   - Image uploads ✅

3. **Shopping Cart**

   - Add to cart (localStorage) ✅
   - Update quantities ✅
   - Remove items ✅
   - Checkout process ✅

4. **Order Management**
   - Place orders ✅
   - View orders ✅
   - Update order status ✅
   - Order history ✅

### Phase 3: Admin Panel

1. **Dashboard**

   - Statistics cards ✅
   - Recent orders ✅
   - Quick actions ✅

2. **Management Pages**
   - User management ✅
   - Product management ✅
   - Order management ✅

### Phase 4: Testing & Optimization

1. **Testing**

   - [ ] Unit tests
   - [ ] Integration tests
   - [ ] User acceptance testing
   - [ ] Security testing

2. **Optimization**
   - [ ] Database indexing
   - [ ] Query optimization
   - [ ] Image optimization
   - [ ] Caching implementation

---

## 🔧 Configuration Guide

### Database Configuration (`includes/db.php`)

```php
$DB_HOST = '127.0.0.1';
$DB_NAME = 'farm_marketplace';
$DB_USER = 'root';
$DB_PASS = '';
```

### Application Configuration (`config.php`)

```php
define('BASE_PATH', '/farm_php');
define('SITE_NAME', 'FarmConnect');
define('MAX_FILE_SIZE', 10485760); // 10MB
```

### URL Configuration

- **Base URL:** `http://localhost/farm_php/`
- **Admin URL:** `http://localhost/farm_php/admin/`
- **API URL:** `http://localhost/farm_php/api/`

---

## 👥 User Accounts (Default)

### Admin Accounts

```
Email: admin@farm.com
Password: admin123
Role: admin

Email: admin@f.com
Password: admin123
Role: admin
```

### Farmer Accounts

```
Email: farmer1@farm.com
Password: farmer123
Role: farmer

Email: farmer2@farm.com
Password: farmer123
Role: farmer
```

### Buyer Accounts

```
Email: buyer1@farm.com
Password: buyer123
Role: buyer

Email: buyer2@farm.com
Password: buyer123
Role: buyer
```

---

## 🎯 Feature Roadmap

### ✅ Completed Features

- User authentication (login/register)
- Role-based access control
- Product listing and search
- Shopping cart (localStorage)
- Order placement and tracking
- Admin dashboard
- Image upload system
- Responsive design

### 🚧 In Progress

- Database-driven cart
- Payment gateway integration
- Email notifications

### 📝 Planned Features

- [ ] Product reviews and ratings
- [ ] Wishlist functionality
- [ ] Advanced search filters
- [ ] Multiple payment methods
- [ ] Order tracking with status
- [ ] Invoice generation (PDF)
- [ ] Email notifications (SMTP)
- [ ] SMS notifications
- [ ] Chat system (farmer-buyer)
- [ ] Analytics dashboard
- [ ] Export reports (CSV/Excel)
- [ ] Multi-language support
- [ ] Mobile app API
- [ ] Social media integration
- [ ] Coupon/discount system
- [ ] Subscription plans
- [ ] Delivery tracking

---

## 🐛 Troubleshooting

### Common Issues

#### 1. Database Connection Error

```
Solution: Check MySQL is running, verify credentials in config.php
```

#### 2. Image Upload Failed

```
Solution: Check uploads/products/ folder exists and has write permissions
```

#### 3. Session Issues

```
Solution: Ensure sessions/ folder exists with write permissions
```

#### 4. 404 Errors

```
Solution: Verify BASE_PATH in config.php matches your folder name
```

#### 5. Port 80 Already in Use

```
Solution: Stop other web servers or change Apache port in httpd.conf
```

---

## 📊 Database Schema

### Tables

1. **users** - User accounts (admin, farmers, buyers)
2. **products** - Product listings
3. **orders** - Order records
4. **cart** - Shopping cart (optional)
5. **reviews** - Product reviews (optional)
6. **categories** - Product categories (optional)

### Relationships

- Users (1) → Products (Many)
- Users (1) → Orders (Many)
- Products (1) → Orders (Many)
- Products (1) → Reviews (Many)

---

## 🔐 Security Checklist

- [x] Password hashing (bcrypt)
- [x] SQL injection prevention (PDO)
- [x] XSS protection (htmlspecialchars)
- [x] CSRF tokens (to implement)
- [x] Session security
- [x] File upload validation
- [ ] Rate limiting
- [ ] SSL/HTTPS
- [ ] Input sanitization
- [ ] Error logging

---

## 📚 Documentation

### Code Comments

- All functions documented
- Complex logic explained
- TODO items marked

### API Documentation

- Endpoint list
- Request/response format
- Authentication method

### User Manual

- Installation guide
- User guide
- Admin guide
- FAQ section

---

## 🚀 Deployment Checklist

### Pre-Deployment

- [ ] Update .env for production
- [ ] Change APP_ENV to 'production'
- [ ] Disable error display
- [ ] Enable error logging
- [ ] Optimize database
- [ ] Minify CSS/JS
- [ ] Compress images
- [ ] Test all features

### Deployment

- [ ] Upload files to server
- [ ] Import database
- [ ] Set file permissions
- [ ] Configure .htaccess
- [ ] Enable HTTPS
- [ ] Test on production

### Post-Deployment

- [ ] Monitor error logs
- [ ] Check performance
- [ ] Test payment gateway
- [ ] Verify email delivery
- [ ] Test user flows
- [ ] Setup backups

---

## 📞 Support & Resources

### Documentation

- PHP Manual: https://www.php.net/manual/
- Bootstrap: https://getbootstrap.com/docs/
- MySQL: https://dev.mysql.com/doc/

### Community

- Stack Overflow
- GitHub Issues
- PHP Forums

### Tools

- phpMyAdmin
- Postman (API testing)
- Chrome DevTools
- Git/GitHub

---

## 📄 License

MIT License - Free to use and modify

---

## 👨‍💻 Contributors

- Project Lead: Your Name
- Version: 1.0.0
- Last Updated: November 12, 2025

---

**🎉 Happy Coding! Your FarmConnect marketplace is ready to grow! 🌱**
