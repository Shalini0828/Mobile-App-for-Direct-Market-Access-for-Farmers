const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['vegetables', 'fruits', 'grains', 'dairy', 'spices', 'pulses', 'herbs']
  },
  subCategory: {
    type: String,
    required: true
  },
  farmerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Farmer',
    required: true
  },
  price: {
    amount: {
      type: Number,
      required: true,
      min: 0
    },
    unit: {
      type: String,
      required: true,
      enum: ['kg', 'gram', 'liter', 'piece', 'dozen', 'bundle']
    }
  },
  images: [{
    url: String,
    alt: String,
    isPrimary: { type: Boolean, default: false }
  }],
  stock: {
    quantity: {
      type: Number,
      required: true,
      min: 0
    },
    unit: {
      type: String,
      required: true,
      enum: ['kg', 'gram', 'liter', 'piece', 'dozen', 'bundle']
    },
    minOrderQuantity: {
      type: Number,
      default: 1
    },
    maxOrderQuantity: {
      type: Number,
      default: 1000
    }
  },
  quality: {
    grade: {
      type: String,
      enum: ['A+', 'A', 'B+', 'B', 'C'],
      default: 'A'
    },
    organic: {
      type: Boolean,
      default: false
    },
    freshness: {
      type: String,
      enum: ['fresh', 'semi-fresh', 'stored'],
      default: 'fresh'
    },
    harvestDate: Date
  },
  availability: {
    isAvailable: {
      type: Boolean,
      default: true
    },
    seasonalAvailability: [{
      month: {
        type: Number,
        min: 1,
        max: 12
      }
    }],
    estimatedAvailability: Date
  },
  shipping: {
    weight: Number, // in kg
    dimensions: {
      length: Number,
      width: Number,
      height: Number
    },
    fragile: {
      type: Boolean,
      default: false
    },
    shelfLife: Number // in days
  },
  tags: [String],
  rating: {
    average: { type: Number, default: 0 },
    count: { type: Number, default: 0 }
  },
  reviews: [{
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    rating: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: String,
    date: {
      type: Date,
      default: Date.now
    },
    isVerified: {
      type: Boolean,
      default: false
    }
  }],
  totalSold: {
    type: Number,
    default: 0
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  discounts: [{
    type: {
      type: String,
      enum: ['percentage', 'fixed']
    },
    value: Number,
    validFrom: Date,
    validUntil: Date,
    minQuantity: Number,
    isActive: {
      type: Boolean,
      default: true
    }
  }]
}, {
  timestamps: true
});

// Indexes for better query performance
productSchema.index({ category: 1, subCategory: 1 });
productSchema.index({ farmerId: 1 });
productSchema.index({ 'availability.isAvailable': 1 });
productSchema.index({ 'rating.average': -1 });
productSchema.index({ createdAt: -1 });
productSchema.index({ name: 'text', description: 'text', tags: 'text' });

module.exports = mongoose.model('Product', productSchema);