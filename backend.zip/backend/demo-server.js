const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 5001;
const JWT_SECRET = 'demo-secret-key-for-testing-only';

// Middleware
app.use(cors({
    origin: ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:5500'],
    credentials: true
}));
app.use(express.json());

// In-memory data store for demo
let users = [
    {
        _id: 'admin1',
        name: 'Admin User',
        email: 'admin@farmconnect.com',
        password: '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeSSVyKZpAq5YzNim', // admin123
        phone: '9999999999',
        role: 'admin',
        createdAt: new Date()
    },
    {
        _id: 'farmer1',
        name: 'Rahul Sharma',
        email: 'rahul@farmconnect.com',
        password: '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeSSVyKZpAq5YzNim', // farmer123
        phone: '9876543210',
        role: 'farmer',
        createdAt: new Date()
    },
    {
        _id: 'user1',
        name: 'John Customer',
        email: 'john@example.com',
        password: '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeSSVyKZpAq5YzNim', // user123
        phone: '9876543210',
        role: 'user',
        createdAt: new Date()
    }
];

let farmers = [
    {
        _id: 'farmer1',
        user: 'farmer1',
        farmName: 'Green Valley Farm',
        farmSize: 50,
        location: {
            state: 'Maharashtra',
            district: 'Pune',
            village: 'Kharadi'
        },
        verified: true,
        rating: { average: 4.5, count: 25 },
        totalSales: 150000,
        createdAt: new Date()
    }
];

let products = [
    {
        _id: 'prod1',
        name: 'Fresh Tomatoes',
        description: 'Organically grown fresh tomatoes, perfect for cooking',
        category: 'vegetables',
        price: { amount: 40, unit: 'kg' },
        images: ['https://images.unsplash.com/photo-1546470427-e8b20b582d1c?w=400'],
        farmer: {
            _id: 'farmer1',
            name: 'Rahul Sharma',
            farmName: 'Green Valley Farm'
        },
        inventory: { quantity: 100, unit: 'kg' },
        organic: true,
        rating: { average: 4.5, count: 12 },
        active: true,
        createdAt: new Date()
    },
    {
        _id: 'prod2',
        name: 'Fresh Potatoes',
        description: 'High-quality potatoes, freshly harvested',
        category: 'vegetables',
        price: { amount: 25, unit: 'kg' },
        images: ['https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400'],
        farmer: {
            _id: 'farmer1',
            name: 'Rahul Sharma',
            farmName: 'Green Valley Farm'
        },
        inventory: { quantity: 200, unit: 'kg' },
        organic: false,
        rating: { average: 4.2, count: 8 },
        active: true,
        createdAt: new Date()
    },
    {
        _id: 'prod3',
        name: 'Green Apples',
        description: 'Crisp and juicy green apples, perfect for snacking',
        category: 'fruits',
        price: { amount: 120, unit: 'kg' },
        images: ['https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400'],
        farmer: {
            _id: 'farmer1',
            name: 'Rahul Sharma',
            farmName: 'Green Valley Farm'
        },
        inventory: { quantity: 50, unit: 'kg' },
        organic: true,
        rating: { average: 4.8, count: 15 },
        active: true,
        createdAt: new Date()
    },
    {
        _id: 'prod4',
        name: 'Organic Rice',
        description: 'Premium quality organic basmati rice',
        category: 'grains',
        price: { amount: 80, unit: 'kg' },
        images: ['https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=400'],
        farmer: {
            _id: 'farmer1',
            name: 'Rahul Sharma',
            farmName: 'Green Valley Farm'
        },
        inventory: { quantity: 150, unit: 'kg' },
        organic: true,
        rating: { average: 4.6, count: 20 },
        active: true,
        createdAt: new Date()
    }
];

let orders = [
    {
        _id: 'order1',
        user: {
            _id: 'user1',
            name: 'John Customer',
            email: 'john@example.com'
        },
        items: [
            {
                product: {
                    _id: 'prod1',
                    name: 'Fresh Tomatoes',
                    images: ['https://images.unsplash.com/photo-1546470427-e8b20b582d1c?w=400']
                },
                quantity: 2,
                price: 40
            }
        ],
        totalAmount: 130, // Including shipping and tax
        status: 'pending',
        paymentMethod: 'cod',
        shippingAddress: {
            name: 'John Customer',
            phone: '9876543210',
            street: '123 Main Street',
            city: 'Mumbai',
            state: 'Maharashtra',
            pincode: '400001',
            country: 'India'
        },
        createdAt: new Date()
    }
];

let carts = {};

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ message: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Invalid token' });
        }
        req.user = user;
        next();
    });
};

// Helper functions
const generateToken = (user) => {
    return jwt.sign({ 
        id: user._id, 
        email: user.email, 
        role: user.role 
    }, JWT_SECRET, { expiresIn: '7d' });
};

const generateId = () => {
    return Math.random().toString(36).substr(2, 9);
};

// Routes

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'Demo server running' });
});

// Auth routes
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password, phone, role, farmName, farmSize } = req.body;

        // Check if user exists
        const existingUser = users.find(u => u.email === email);
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12);

        // Create user
        const newUser = {
            _id: generateId(),
            name,
            email,
            password: hashedPassword,
            phone,
            role: role || 'user',
            createdAt: new Date()
        };

        users.push(newUser);

        // Create farmer profile if role is farmer
        if (role === 'farmer') {
            const newFarmer = {
                _id: newUser._id,
                user: newUser._id,
                farmName: farmName || `${name}'s Farm`,
                farmSize: farmSize || 0,
                location: {
                    state: '',
                    district: '',
                    village: ''
                },
                verified: false,
                rating: { average: 0, count: 0 },
                totalSales: 0,
                createdAt: new Date()
            };
            farmers.push(newFarmer);
        }

        // Generate token
        const token = generateToken(newUser);

        // Return user without password
        const { password: _, ...userResponse } = newUser;
        res.status(201).json({
            message: 'User registered successfully',
            token,
            user: userResponse
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user
        const user = users.find(u => u.email === email);
        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Generate token
        const token = generateToken(user);

        // Return user without password
        const { password: _, ...userResponse } = user;
        res.json({
            message: 'Login successful',
            token,
            user: userResponse
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

app.get('/api/auth/profile', authenticateToken, (req, res) => {
    const user = users.find(u => u._id === req.user.id);
    if (!user) {
        return res.status(404).json({ message: 'User not found' });
    }

    const { password, ...userResponse } = user;
    res.json(userResponse);
});

// Product routes
app.get('/api/products', (req, res) => {
    let filteredProducts = [...products];

    // Apply filters
    if (req.query.category) {
        filteredProducts = filteredProducts.filter(p => p.category === req.query.category);
    }

    if (req.query.organic === 'true') {
        filteredProducts = filteredProducts.filter(p => p.organic);
    }

    if (req.query.minPrice) {
        filteredProducts = filteredProducts.filter(p => p.price.amount >= parseFloat(req.query.minPrice));
    }

    if (req.query.maxPrice) {
        filteredProducts = filteredProducts.filter(p => p.price.amount <= parseFloat(req.query.maxPrice));
    }

    // Apply sorting
    if (req.query.sort) {
        const [field, order] = req.query.sort.split('_');
        filteredProducts.sort((a, b) => {
            let aValue = a;
            let bValue = b;
            
            // Handle nested properties
            if (field.includes('.')) {
                const fields = field.split('.');
                aValue = fields.reduce((obj, f) => obj[f], a);
                bValue = fields.reduce((obj, f) => obj[f], b);
            } else {
                aValue = a[field];
                bValue = b[field];
            }

            if (order === 'desc') {
                return bValue > aValue ? 1 : -1;
            }
            return aValue > bValue ? 1 : -1;
        });
    }

    // Pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;

    const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

    res.json({
        products: paginatedProducts,
        pagination: {
            page,
            limit,
            total: filteredProducts.length,
            pages: Math.ceil(filteredProducts.length / limit)
        }
    });
});

app.get('/api/products/:id', (req, res) => {
    const product = products.find(p => p._id === req.params.id);
    if (!product) {
        return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
});

app.post('/api/products', authenticateToken, (req, res) => {
    if (req.user.role !== 'farmer') {
        return res.status(403).json({ message: 'Only farmers can create products' });
    }

    const farmer = farmers.find(f => f.user === req.user.id);
    if (!farmer) {
        return res.status(404).json({ message: 'Farmer profile not found' });
    }

    const newProduct = {
        _id: generateId(),
        ...req.body,
        farmer: {
            _id: farmer._id,
            name: users.find(u => u._id === req.user.id).name,
            farmName: farmer.farmName
        },
        rating: { average: 0, count: 0 },
        active: true,
        createdAt: new Date()
    };

    products.push(newProduct);
    res.status(201).json(newProduct);
});

// Cart routes
app.get('/api/cart', authenticateToken, (req, res) => {
    const userCart = carts[req.user.id] || { items: [], total: 0 };
    res.json(userCart);
});

app.post('/api/cart/add', authenticateToken, (req, res) => {
    const { productId, quantity } = req.body;
    const product = products.find(p => p._id === productId);
    
    if (!product) {
        return res.status(404).json({ message: 'Product not found' });
    }

    if (!carts[req.user.id]) {
        carts[req.user.id] = { items: [], total: 0 };
    }

    const existingItem = carts[req.user.id].items.find(item => item.product._id === productId);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        carts[req.user.id].items.push({
            product,
            quantity,
            price: product.price.amount
        });
    }

    // Calculate total
    carts[req.user.id].total = carts[req.user.id].items.reduce((sum, item) => 
        sum + (item.price * item.quantity), 0
    );

    res.json(carts[req.user.id]);
});

app.put('/api/cart/update', authenticateToken, (req, res) => {
    const { productId, quantity } = req.body;

    if (!carts[req.user.id]) {
        return res.status(404).json({ message: 'Cart not found' });
    }

    const item = carts[req.user.id].items.find(item => item.product._id === productId);
    if (!item) {
        return res.status(404).json({ message: 'Item not found in cart' });
    }

    if (quantity <= 0) {
        carts[req.user.id].items = carts[req.user.id].items.filter(item => item.product._id !== productId);
    } else {
        item.quantity = quantity;
    }

    // Recalculate total
    carts[req.user.id].total = carts[req.user.id].items.reduce((sum, item) => 
        sum + (item.price * item.quantity), 0
    );

    res.json(carts[req.user.id]);
});

app.delete('/api/cart/remove', authenticateToken, (req, res) => {
    const { productId } = req.body;

    if (!carts[req.user.id]) {
        return res.status(404).json({ message: 'Cart not found' });
    }

    carts[req.user.id].items = carts[req.user.id].items.filter(item => item.product._id !== productId);

    // Recalculate total
    carts[req.user.id].total = carts[req.user.id].items.reduce((sum, item) => 
        sum + (item.price * item.quantity), 0
    );

    res.json(carts[req.user.id]);
});

// Order routes
app.get('/api/orders', authenticateToken, (req, res) => {
    let userOrders = orders;

    if (req.user.role === 'user') {
        userOrders = orders.filter(order => order.user._id === req.user.id);
    } else if (req.user.role === 'farmer') {
        // Filter orders that contain products from this farmer
        userOrders = orders.filter(order => 
            order.items.some(item => 
                products.find(p => p._id === item.product._id && p.farmer._id === req.user.id)
            )
        );
    }

    res.json({ orders: userOrders });
});

app.post('/api/orders', authenticateToken, (req, res) => {
    const user = users.find(u => u._id === req.user.id);
    if (!user) {
        return res.status(404).json({ message: 'User not found' });
    }

    const newOrder = {
        _id: generateId(),
        user: {
            _id: user._id,
            name: user.name,
            email: user.email
        },
        ...req.body,
        status: 'pending',
        createdAt: new Date()
    };

    orders.push(newOrder);

    // Clear user's cart
    if (carts[req.user.id]) {
        carts[req.user.id] = { items: [], total: 0 };
    }

    res.status(201).json({ order: newOrder });
});

app.put('/api/orders/:id/status', authenticateToken, (req, res) => {
    const { status } = req.body;
    const order = orders.find(o => o._id === req.params.id);

    if (!order) {
        return res.status(404).json({ message: 'Order not found' });
    }

    // Check if user has permission to update this order
    if (req.user.role !== 'admin' && req.user.role !== 'farmer') {
        return res.status(403).json({ message: 'Not authorized to update orders' });
    }

    order.status = status;
    res.json(order);
});

// Farmer routes
app.get('/api/farmers', (req, res) => {
    const farmersWithDetails = farmers.map(farmer => {
        const user = users.find(u => u._id === farmer.user);
        return {
            ...farmer,
            user: {
                name: user.name,
                email: user.email
            }
        };
    });

    res.json({ farmers: farmersWithDetails });
});

app.get('/api/farmers/stats', authenticateToken, (req, res) => {
    if (req.user.role !== 'farmer') {
        return res.status(403).json({ message: 'Access denied' });
    }

    const farmer = farmers.find(f => f.user === req.user.id);
    if (!farmer) {
        return res.status(404).json({ message: 'Farmer profile not found' });
    }

    const farmerProducts = products.filter(p => p.farmer._id === farmer._id);
    const farmerOrders = orders.filter(order => 
        order.items.some(item => 
            products.find(p => p._id === item.product._id && p.farmer._id === farmer._id)
        )
    );

    const monthlyRevenue = farmerOrders
        .filter(order => {
            const orderMonth = new Date(order.createdAt).getMonth();
            const currentMonth = new Date().getMonth();
            return orderMonth === currentMonth;
        })
        .reduce((sum, order) => sum + order.totalAmount, 0);

    res.json({
        totalProducts: farmerProducts.length,
        totalOrders: farmerOrders.length,
        monthlyRevenue,
        averageRating: farmer.rating.average
    });
});

app.get('/api/farmers/orders', authenticateToken, (req, res) => {
    if (req.user.role !== 'farmer') {
        return res.status(403).json({ message: 'Access denied' });
    }

    const farmer = farmers.find(f => f.user === req.user.id);
    if (!farmer) {
        return res.status(404).json({ message: 'Farmer profile not found' });
    }

    const farmerOrders = orders.filter(order => 
        order.items.some(item => 
            products.find(p => p._id === item.product._id && p.farmer._id === farmer._id)
        )
    );

    res.json({ orders: farmerOrders });
});

// Admin routes
app.get('/api/admin/stats', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Access denied' });
    }

    const totalUsers = users.filter(u => u.role === 'user').length;
    const totalFarmers = users.filter(u => u.role === 'farmer').length;
    const totalProducts = products.length;
    
    const monthlyRevenue = orders
        .filter(order => {
            const orderMonth = new Date(order.createdAt).getMonth();
            const currentMonth = new Date().getMonth();
            return orderMonth === currentMonth;
        })
        .reduce((sum, order) => sum + order.totalAmount, 0);

    res.json({
        totalUsers,
        totalFarmers,
        totalProducts,
        monthlyRevenue
    });
});

app.get('/api/admin/users', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Access denied' });
    }

    const safeUsers = users.map(({ password, ...user }) => user);
    res.json({ users: safeUsers });
});

// Payment routes
app.post('/api/payments/process', authenticateToken, (req, res) => {
    const { orderId, amount, method } = req.body;

    // Simulate payment processing
    setTimeout(() => {
        res.json({
            success: true,
            transactionId: generateId(),
            message: `Payment of ₹${amount} processed successfully via ${method}`
        });
    }, 1000);
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error(error);
    res.status(500).json({ message: 'Something went wrong!' });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({ message: 'Route not found' });
});

app.listen(PORT, () => {
    console.log(`🚀 Demo server running on http://localhost:${PORT}`);
    console.log(`📖 API Documentation: http://localhost:${PORT}/api/health`);
    console.log(`\n🧪 Test Accounts:`);
    console.log(`   Admin: admin@farmconnect.com / admin123`);
    console.log(`   Farmer: rahul@farmconnect.com / farmer123`);
    console.log(`   User: john@example.com / user123`);
    console.log(`\n💡 This is a demo server with in-memory data storage.`);
    console.log(`   Data will be lost when the server restarts.`);
});