const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Farmer = require('./models/Farmer');
const Product = require('./models/Product');
const Order = require('./models/Order');
require('dotenv').config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/farmconnect';

// Sample data
const users = [
  {
    name: 'Admin User',
    email: 'admin@farmconnect.com',
    password: 'admin123',
    phone: '+91 9999999999',
    role: 'admin',
    address: {
      street: 'Admin Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Anand Mahindra',
    email: 'anand@mahindrafarms.com',
    password: 'farmer123',
    phone: '+91 9876543210',
    role: 'farmer',
    address: {
      street: 'Farm Road',
      city: 'Nashik',
      state: 'Maharashtra',
      pincode: '422001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Sukhpreet Singh',
    email: 'sukh@singhproduce.com',
    password: 'farmer123',
    phone: '+91 9876543211',
    role: 'farmer',
    address: {
      street: 'Village Road',
      city: 'Amritsar',
      state: 'Punjab',
      pincode: '143001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Krishna Dairy',
    email: 'info@krishnadairy.com',
    password: 'farmer123',
    phone: '+91 9876543212',
    role: 'farmer',
    address: {
      street: 'Dairy Lane',
      city: 'Anand',
      state: 'Gujarat',
      pincode: '388001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Raj Patel',
    email: 'raj@example.com',
    password: 'user123',
    phone: '+91 9876543213',
    role: 'user',
    address: {
      street: '123 Main Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400069',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Priya Sharma',
    email: 'priya@example.com',
    password: 'user123',
    phone: '+91 9876543214',
    role: 'user',
    address: {
      street: '456 Park Avenue',
      city: 'Delhi',
      state: 'Delhi',
      pincode: '110001',
      country: 'India'
    },
    isVerified: true
  }
];

const farmers = [
  {
    farmName: 'Anand Mahindra Farms',
    farmSize: 50,
    location: {
      coordinates: {
        latitude: 19.9975,
        longitude: 73.7898
      },
      address: {
        street: 'Farm Road',
        city: 'Nashik',
        state: 'Maharashtra',
        pincode: '422001',
        country: 'India'
      }
    },
    specialization: ['vegetables', 'fruits', 'organic'],
    isVerified: true,
    rating: { average: 4.8, count: 120 },
    totalSales: 125000,
    totalOrders: 85
  },
  {
    farmName: 'Singh Produce',
    farmSize: 75,
    location: {
      coordinates: {
        latitude: 31.6340,
        longitude: 74.8723
      },
      address: {
        street: 'Village Road',
        city: 'Amritsar',
        state: 'Punjab',
        pincode: '143001',
        country: 'India'
      }
    },
    specialization: ['grains', 'spices'],
    isVerified: true,
    rating: { average: 4.7, count: 95 },
    totalSales: 98000,
    totalOrders: 65
  },
  {
    farmName: 'Krishna Dairy',
    farmSize: 25,
    location: {
      coordinates: {
        latitude: 22.5645,
        longitude: 72.9289
      },
      address: {
        street: 'Dairy Lane',
        city: 'Anand',
        state: 'Gujarat',
        pincode: '388001',
        country: 'India'
      }
    },
    specialization: ['dairy', 'organic'],
    isVerified: true,
    rating: { average: 4.9, count: 210 },
    totalSales: 156000,
    totalOrders: 145
  }
];

const products = [
  {
    name: 'Organic Tomatoes',
    description: 'Fresh, juicy organic tomatoes grown without pesticides. Perfect for cooking and salads.',
    category: 'vegetables',
    subCategory: 'tomatoes',
    price: { amount: 40, unit: 'kg' },
    images: [{ url: '/images/tomatoes.jpg', alt: 'Fresh Organic Tomatoes', isPrimary: true }],
    stock: { quantity: 500, unit: 'kg', minOrderQuantity: 1, maxOrderQuantity: 50 },
    quality: { grade: 'A+', organic: true, freshness: 'fresh' },
    availability: { isAvailable: true },
    shipping: { weight: 1, shelfLife: 7 },
    tags: ['organic', 'fresh', 'local', 'pesticide-free'],
    rating: { average: 4.8, count: 45 },
    totalSold: 1250,
    isActive: true,
    isFeatured: true
  },
  {
    name: 'Fresh Onions',
    description: 'High quality fresh onions, perfect for daily cooking needs.',
    category: 'vegetables',
    subCategory: 'onions',
    price: { amount: 35, unit: 'kg' },
    images: [{ url: '/images/onions.jpg', alt: 'Fresh Onions', isPrimary: true }],
    stock: { quantity: 300, unit: 'kg', minOrderQuantity: 2, maxOrderQuantity: 100 },
    quality: { grade: 'A', organic: false, freshness: 'fresh' },
    availability: { isAvailable: true },
    shipping: { weight: 1, shelfLife: 30 },
    tags: ['fresh', 'local', 'cooking'],
    rating: { average: 4.6, count: 32 },
    totalSold: 890,
    isActive: true,
    isFeatured: false
  },
  {
    name: 'Basmati Rice',
    description: 'Premium quality aged basmati rice with long grains and aromatic fragrance.',
    category: 'grains',
    subCategory: 'rice',
    price: { amount: 120, unit: 'kg' },
    images: [{ url: '/images/basmati-rice.jpg', alt: 'Premium Basmati Rice', isPrimary: true }],
    stock: { quantity: 1000, unit: 'kg', minOrderQuantity: 5, maxOrderQuantity: 500 },
    quality: { grade: 'A+', organic: false, freshness: 'stored' },
    availability: { isAvailable: true },
    shipping: { weight: 1, shelfLife: 365 },
    tags: ['premium', 'aromatic', 'aged', 'export-quality'],
    rating: { average: 4.7, count: 28 },
    totalSold: 2100,
    isActive: true,
    isFeatured: true
  },
  {
    name: 'Alphonso Mangoes',
    description: 'King of mangoes! Sweet and delicious Alphonso mangoes from Maharashtra.',
    category: 'fruits',
    subCategory: 'mangoes',
    price: { amount: 150, unit: 'kg' },
    images: [{ url: '/images/alphonso-mango.jpg', alt: 'Alphonso Mangoes', isPrimary: true }],
    stock: { quantity: 200, unit: 'kg', minOrderQuantity: 1, maxOrderQuantity: 20 },
    quality: { grade: 'A+', organic: true, freshness: 'fresh' },
    availability: { isAvailable: true },
    shipping: { weight: 1, shelfLife: 5, fragile: true },
    tags: ['premium', 'sweet', 'alphonso', 'maharashtra'],
    rating: { average: 4.9, count: 67 },
    totalSold: 450,
    isActive: true,
    isFeatured: true
  },
  {
    name: 'Fresh Milk',
    description: 'Pure, fresh cow milk from grass-fed cows. Rich in nutrients and taste.',
    category: 'dairy',
    subCategory: 'milk',
    price: { amount: 60, unit: 'liter' },
    images: [{ url: '/images/fresh-milk.jpg', alt: 'Fresh Cow Milk', isPrimary: true }],
    stock: { quantity: 100, unit: 'liter', minOrderQuantity: 1, maxOrderQuantity: 20 },
    quality: { grade: 'A+', organic: true, freshness: 'fresh' },
    availability: { isAvailable: true },
    shipping: { weight: 1, shelfLife: 3, fragile: true },
    tags: ['fresh', 'organic', 'grass-fed', 'nutritious'],
    rating: { average: 4.9, count: 89 },
    totalSold: 780,
    isActive: true,
    isFeatured: true
  },
  {
    name: 'Red Chilli Powder',
    description: 'Authentic red chilli powder with perfect spice level for Indian cooking.',
    category: 'spices',
    subCategory: 'chilli',
    price: { amount: 180, unit: 'kg' },
    images: [{ url: '/images/chilli-powder.jpg', alt: 'Red Chilli Powder', isPrimary: true }],
    stock: { quantity: 150, unit: 'kg', minOrderQuantity: 0.5, maxOrderQuantity: 10 },
    quality: { grade: 'A', organic: false, freshness: 'stored' },
    availability: { isAvailable: true },
    shipping: { weight: 1, shelfLife: 180 },
    tags: ['spicy', 'authentic', 'indian-spice', 'cooking'],
    rating: { average: 4.6, count: 23 },
    totalSold: 320,
    isActive: true,
    isFeatured: false
  }
];

const orders = [
  {
    items: [
      {
        name: 'Organic Tomatoes',
        quantity: 5,
        price: 40,
        unit: 'kg'
      },
      {
        name: 'Fresh Onions',
        quantity: 3,
        price: 35,
        unit: 'kg'
      }
    ],
    totalAmount: 275,
    status: 'delivered',
    paymentStatus: 'paid',
    paymentMethod: 'card',
    shippingAddress: {
      street: '123 Main Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400069',
      country: 'India'
    },
    statusHistory: [
      { status: 'pending', timestamp: new Date('2024-01-15T10:00:00Z'), note: 'Order placed' },
      { status: 'confirmed', timestamp: new Date('2024-01-15T10:30:00Z'), note: 'Order confirmed by farmer' },
      { status: 'processing', timestamp: new Date('2024-01-15T14:00:00Z'), note: 'Order being prepared' },
      { status: 'shipped', timestamp: new Date('2024-01-16T09:00:00Z'), note: 'Order shipped' },
      { status: 'delivered', timestamp: new Date('2024-01-17T11:00:00Z'), note: 'Order delivered successfully' }
    ],
    deliveryDate: new Date('2024-01-17T11:00:00Z'),
    rating: { rating: 5, review: 'Excellent quality vegetables, fresh and organic!' }
  },
  {
    items: [
      {
        name: 'Basmati Rice',
        quantity: 10,
        price: 120,
        unit: 'kg'
      },
      {
        name: 'Fresh Milk',
        quantity: 2,
        price: 60,
        unit: 'liter'
      }
    ],
    totalAmount: 1320,
    status: 'shipped',
    paymentStatus: 'paid',
    paymentMethod: 'upi',
    shippingAddress: {
      street: '456 Park Avenue',
      city: 'Delhi',
      state: 'Delhi',
      pincode: '110001',
      country: 'India'
    },
    statusHistory: [
      { status: 'pending', timestamp: new Date('2024-01-20T08:00:00Z'), note: 'Order placed' },
      { status: 'confirmed', timestamp: new Date('2024-01-20T08:15:00Z'), note: 'Order confirmed by farmer' },
      { status: 'processing', timestamp: new Date('2024-01-20T12:00:00Z'), note: 'Order being prepared' },
      { status: 'shipped', timestamp: new Date('2024-01-21T10:00:00Z'), note: 'Order shipped' }
    ],
    deliveryDate: new Date('2024-01-23T14:00:00Z')
  },
  {
    items: [
      {
        name: 'Alphonso Mangoes',
        quantity: 2,
        price: 150,
        unit: 'kg'
      }
    ],
    totalAmount: 300,
    status: 'processing',
    paymentStatus: 'paid',
    paymentMethod: 'wallet',
    shippingAddress: {
      street: '123 Main Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400069',
      country: 'India'
    },
    statusHistory: [
      { status: 'pending', timestamp: new Date('2024-01-22T16:00:00Z'), note: 'Order placed' },
      { status: 'confirmed', timestamp: new Date('2024-01-22T16:30:00Z'), note: 'Order confirmed by farmer' },
      { status: 'processing', timestamp: new Date('2024-01-23T09:00:00Z'), note: 'Order being prepared' }
    ]
  }
];

async function seedDatabase() {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    // Clear existing data and indexes
    await User.deleteMany({});
    await Farmer.deleteMany({});
    await Product.deleteMany({});
    await Order.deleteMany({});
    
    // Drop all indexes to avoid conflicts from old schema versions
    try {
      await mongoose.connection.db.collection('users').dropIndexes();
      await mongoose.connection.db.collection('farmers').dropIndexes();
      await mongoose.connection.db.collection('products').dropIndexes();
      await mongoose.connection.db.collection('orders').dropIndexes();
      console.log('Dropped existing indexes');
    } catch (error) {
      // Indexes might not exist, continue
      console.log('No existing indexes to drop or already dropped');
    }
    
    console.log('Cleared existing data');

    // Create users
    const createdUsers = [];
    for (let userData of users) {
      const user = new User(userData);
      await user.save();
      createdUsers.push(user);
      console.log(`Created user: ${user.name}`);
    }

    // Create farmers
    const farmerUsers = createdUsers.filter(user => user.role === 'farmer');
    for (let i = 0; i < farmers.length; i++) {
      const farmerData = { ...farmers[i], userId: farmerUsers[i]._id };
      const farmer = new Farmer(farmerData);
      await farmer.save();
      console.log(`Created farmer: ${farmer.farmName}`);

      // Create products for this farmer
      const farmerProducts = products.slice(i * 2, (i * 2) + 2); // 2 products per farmer
      for (let productData of farmerProducts) {
        const product = new Product({ ...productData, farmerId: farmer._id });
        await product.save();
        console.log(`Created product: ${product.name} for ${farmer.farmName}`);
      }
    }

    // Get created products and farmers for order creation
    const createdProducts = await Product.find({});
    const createdFarmers = await Farmer.find({});
    const customerUsers = createdUsers.filter(user => user.role === 'user');

    // Create orders
    // Order 1: Raj Patel (customer) orders from Anand Mahindra Farms
    const order1 = new Order({
      orderNumber: 'FC25001',
      userId: customerUsers[0]._id, // Raj Patel
      items: [
        {
          productId: createdProducts.find(p => p.name === 'Organic Tomatoes')._id,
          farmerId: createdFarmers[0]._id, // Anand Mahindra Farms
          name: 'Organic Tomatoes',
          quantity: 5,
          unit: 'kg',
          pricePerUnit: 40,
          totalPrice: 200
        },
        {
          productId: createdProducts.find(p => p.name === 'Fresh Onions')._id,
          farmerId: createdFarmers[0]._id, // Anand Mahindra Farms
          name: 'Fresh Onions',
          quantity: 3,
          unit: 'kg',
          pricePerUnit: 35,
          totalPrice: 105
        }
      ],
      orderSummary: {
        subtotal: 305,
        shipping: 0,
        tax: 0,
        total: 305
      },
      shippingAddress: {
        name: 'Raj Patel',
        phone: '+91 9876543213',
        street: '123 Main Street',
        city: 'Mumbai',
        state: 'Maharashtra',
        pincode: '400069',
        country: 'India'
      },
      paymentInfo: {
        method: 'online',
        status: 'completed'
      },
      orderStatus: 'delivered',
      statusHistory: [
        { status: 'pending', timestamp: new Date('2024-01-15T10:00:00Z'), note: 'Order placed' },
        { status: 'confirmed', timestamp: new Date('2024-01-15T10:30:00Z'), note: 'Order confirmed by farmer' },
        { status: 'processing', timestamp: new Date('2024-01-15T14:00:00Z'), note: 'Order being prepared' },
        { status: 'shipped', timestamp: new Date('2024-01-16T09:00:00Z'), note: 'Order shipped' },
        { status: 'delivered', timestamp: new Date('2024-01-17T11:00:00Z'), note: 'Order delivered successfully' }
      ],
      actualDeliveryDate: new Date('2024-01-17T11:00:00Z'),
      rating: { overall: 5, delivery: 5, quality: 5, packaging: 5, comment: 'Excellent quality vegetables, fresh and organic!', ratedAt: new Date() }
    });
    await order1.save();
    console.log(`Created order: ${order1.orderNumber}`);

    // Order 2: Priya Sharma (customer) orders from Singh Produce and Krishna Dairy
    const order2 = new Order({
      orderNumber: 'FC25002',
      userId: customerUsers[1]._id, // Priya Sharma
      items: [
        {
          productId: createdProducts.find(p => p.name === 'Basmati Rice')._id,
          farmerId: createdFarmers[1]._id, // Singh Produce
          name: 'Basmati Rice',
          quantity: 10,
          unit: 'kg',
          pricePerUnit: 120,
          totalPrice: 1200
        },
        {
          productId: createdProducts.find(p => p.name === 'Fresh Milk')._id,
          farmerId: createdFarmers[2]._id, // Krishna Dairy
          name: 'Fresh Milk',
          quantity: 2,
          unit: 'liter',
          pricePerUnit: 60,
          totalPrice: 120
        }
      ],
      orderSummary: {
        subtotal: 1320,
        shipping: 0,
        tax: 0,
        total: 1320
      },
      shippingAddress: {
        name: 'Priya Sharma',
        phone: '+91 9876543214',
        street: '456 Park Avenue',
        city: 'Delhi',
        state: 'Delhi',
        pincode: '110001',
        country: 'India'
      },
      paymentInfo: {
        method: 'online',
        status: 'completed'
      },
      orderStatus: 'shipped',
      statusHistory: [
        { status: 'pending', timestamp: new Date('2024-01-20T08:00:00Z'), note: 'Order placed' },
        { status: 'confirmed', timestamp: new Date('2024-01-20T08:15:00Z'), note: 'Order confirmed by farmer' },
        { status: 'processing', timestamp: new Date('2024-01-20T12:00:00Z'), note: 'Order being prepared' },
        { status: 'shipped', timestamp: new Date('2024-01-21T10:00:00Z'), note: 'Order shipped' }
      ],
      tracking: {
        trackingNumber: 'FC25002TRK',
        estimatedDelivery: new Date('2024-01-23T14:00:00Z')
      }
    });
    await order2.save();
    console.log(`Created order: ${order2.orderNumber}`);

    // Order 3: Raj Patel orders from Anand Mahindra Farms
    const order3 = new Order({
      orderNumber: 'FC25003',
      userId: customerUsers[0]._id, // Raj Patel
      items: [
        {
          productId: createdProducts.find(p => p.name === 'Alphonso Mangoes')._id,
          farmerId: createdFarmers[0]._id, // Anand Mahindra Farms
          name: 'Alphonso Mangoes',
          quantity: 2,
          unit: 'kg',
          pricePerUnit: 150,
          totalPrice: 300
        }
      ],
      orderSummary: {
        subtotal: 300,
        shipping: 0,
        tax: 0,
        total: 300
      },
      shippingAddress: {
        name: 'Raj Patel',
        phone: '+91 9876543213',
        street: '123 Main Street',
        city: 'Mumbai',
        state: 'Maharashtra',
        pincode: '400069',
        country: 'India'
      },
      paymentInfo: {
        method: 'wallet',
        status: 'completed'
      },
      orderStatus: 'processing',
      statusHistory: [
        { status: 'pending', timestamp: new Date('2024-01-22T16:00:00Z'), note: 'Order placed' },
        { status: 'confirmed', timestamp: new Date('2024-01-22T16:30:00Z'), note: 'Order confirmed by farmer' },
        { status: 'processing', timestamp: new Date('2024-01-23T09:00:00Z'), note: 'Order being prepared' }
      ]
    });
    await order3.save();
    console.log(`Created order: ${order3.orderNumber}`);

    console.log('Database seeded successfully!');
    console.log('\nLogin credentials:');
    console.log('Admin: admin@farmconnect.com / admin123');
    console.log('Farmer: anand@mahindrafarms.com / farmer123');
    console.log('User: raj@example.com / user123');

  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

// Run the seeder
seedDatabase();