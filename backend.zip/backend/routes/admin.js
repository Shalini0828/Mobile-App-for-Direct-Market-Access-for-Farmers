const express = require('express');
const User = require('../models/User');
const Farmer = require('../models/Farmer');
const Product = require('../models/Product');
const Order = require('../models/Order');
const { auth, adminOnly } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/admin/dashboard
// @desc    Get admin dashboard statistics
// @access  Private/Admin
router.get('/dashboard', auth, adminOnly, async (req, res) => {
  try {
    // Get current date and date ranges
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Get basic counts
    const totalUsers = await User.countDocuments({ isActive: true });
    const totalFarmers = await Farmer.countDocuments({ isActive: true });
    const totalProducts = await Product.countDocuments({ isActive: true });
    const totalOrders = await Order.countDocuments();

    // Get monthly statistics
    const monthlyOrders = await Order.countDocuments({
      createdAt: { $gte: startOfMonth }
    });

    const monthlyRevenue = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startOfMonth },
          orderStatus: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$orderSummary.total' }
        }
      }
    ]);

    // Get daily statistics
    const dailyOrders = await Order.countDocuments({
      createdAt: { $gte: startOfDay }
    });

    const dailyRevenue = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startOfDay },
          orderStatus: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$orderSummary.total' }
        }
      }
    ]);

    // Get pending verifications
    const pendingFarmers = await Farmer.countDocuments({ isVerified: false });
    const pendingOrders = await Order.countDocuments({
      orderStatus: { $in: ['pending', 'confirmed'] }
    });

    // Get top selling products
    const topProducts = await Order.aggregate([
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.productId',
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: '$items.totalPrice' },
          name: { $first: '$items.name' }
        }
      },
      { $sort: { totalQuantity: -1 } },
      { $limit: 5 }
    ]);

    // Get top farmers by revenue
    const topFarmers = await Order.aggregate([
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.farmerId',
          totalRevenue: { $sum: '$items.totalPrice' },
          totalOrders: { $sum: 1 }
        }
      },
      { $sort: { totalRevenue: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'farmers',
          localField: '_id',
          foreignField: '_id',
          as: 'farmer'
        }
      },
      { $unwind: '$farmer' }
    ]);

    res.json({
      overview: {
        totalUsers,
        totalFarmers,
        totalProducts,
        totalOrders,
        pendingFarmers,
        pendingOrders
      },
      monthly: {
        orders: monthlyOrders,
        revenue: monthlyRevenue[0]?.total || 0
      },
      daily: {
        orders: dailyOrders,
        revenue: dailyRevenue[0]?.total || 0
      },
      topProducts,
      topFarmers
    });
  } catch (error) {
    console.error('Get admin dashboard error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/admin/users
// @desc    Get all users with pagination
// @access  Private/Admin
router.get('/users', auth, adminOnly, async (req, res) => {
  try {
    const { page = 1, limit = 20, role, status, search } = req.query;

    const filter = {};
    if (role) filter.role = role;
    if (status) filter.isActive = status === 'active';
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(filter)
      .select('-password')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await User.countDocuments(filter);

    res.json({
      users,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalUsers: total
      }
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/admin/users/:id/status
// @desc    Update user status
// @access  Private/Admin
router.put('/users/:id/status', auth, adminOnly, async (req, res) => {
  try {
    const { isActive } = req.body;

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      user
    });
  } catch (error) {
    console.error('Update user status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/admin/farmers
// @desc    Get all farmers with verification status
// @access  Private/Admin
router.get('/farmers', auth, adminOnly, async (req, res) => {
  try {
    const { page = 1, limit = 20, verified, status } = req.query;

    const filter = {};
    if (verified) filter.isVerified = verified === 'true';
    if (status) filter.isActive = status === 'active';

    const farmers = await Farmer.find(filter)
      .populate('userId', 'name email phone isActive')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Farmer.countDocuments(filter);

    res.json({
      farmers,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalFarmers: total
      }
    });
  } catch (error) {
    console.error('Get farmers error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/admin/farmers/:id/verify
// @desc    Verify farmer
// @access  Private/Admin
router.put('/farmers/:id/verify', auth, adminOnly, async (req, res) => {
  try {
    const { isVerified } = req.body;

    const farmer = await Farmer.findByIdAndUpdate(
      req.params.id,
      { isVerified },
      { new: true }
    ).populate('userId', 'name email phone');

    if (!farmer) {
      return res.status(404).json({ message: 'Farmer not found' });
    }

    res.json({
      message: `Farmer ${isVerified ? 'verified' : 'unverified'} successfully`,
      farmer
    });
  } catch (error) {
    console.error('Verify farmer error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/admin/products
// @desc    Get all products
// @access  Private/Admin
router.get('/products', auth, adminOnly, async (req, res) => {
  try {
    const { page = 1, limit = 20, category, status } = req.query;

    const filter = {};
    if (category) filter.category = category;
    if (status) filter.isActive = status === 'active';

    const products = await Product.find(filter)
      .populate('farmerId', 'farmName userId')
      .populate('farmerId.userId', 'name email')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Product.countDocuments(filter);

    res.json({
      products,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalProducts: total
      }
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/admin/products/:id/featured
// @desc    Toggle product featured status
// @access  Private/Admin
router.put('/products/:id/featured', auth, adminOnly, async (req, res) => {
  try {
    const { isFeatured } = req.body;

    const product = await Product.findByIdAndUpdate(
      req.params.id,
      { isFeatured },
      { new: true }
    ).populate('farmerId', 'farmName');

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json({
      message: `Product ${isFeatured ? 'marked as featured' : 'removed from featured'}`,
      product
    });
  } catch (error) {
    console.error('Update product featured error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/admin/orders
// @desc    Get all orders
// @access  Private/Admin
router.get('/orders', auth, adminOnly, async (req, res) => {
  try {
    const { page = 1, limit = 20, status, payment } = req.query;

    const filter = {};
    if (status) filter.orderStatus = status;
    if (payment) filter['paymentInfo.status'] = payment;

    const orders = await Order.find(filter)
      .populate('userId', 'name email phone')
      .populate('items.farmerId', 'farmName')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Order.countDocuments(filter);

    res.json({
      orders,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalOrders: total
      }
    });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/admin/analytics
// @desc    Get detailed analytics
// @access  Private/Admin
router.get('/analytics', auth, adminOnly, async (req, res) => {
  try {
    const { period = '30' } = req.query; // days
    const days = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Revenue analytics
    const revenueData = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate },
          orderStatus: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          },
          revenue: { $sum: '$orderSummary.total' },
          orders: { $sum: 1 }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 } }
    ]);

    // Category wise sales
    const categoryData = await Order.aggregate([
      { $match: { createdAt: { $gte: startDate } } },
      { $unwind: '$items' },
      {
        $lookup: {
          from: 'products',
          localField: 'items.productId',
          foreignField: '_id',
          as: 'product'
        }
      },
      { $unwind: '$product' },
      {
        $group: {
          _id: '$product.category',
          revenue: { $sum: '$items.totalPrice' },
          quantity: { $sum: '$items.quantity' }
        }
      },
      { $sort: { revenue: -1 } }
    ]);

    // User growth
    const userGrowth = await User.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          },
          newUsers: { $sum: 1 }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 } }
    ]);

    res.json({
      period: days,
      revenue: revenueData,
      categories: categoryData,
      userGrowth
    });
  } catch (error) {
    console.error('Get analytics error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;