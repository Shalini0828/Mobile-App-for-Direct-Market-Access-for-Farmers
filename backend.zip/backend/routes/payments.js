const express = require('express');
const Order = require('../models/Order');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   POST /api/payments/process
// @desc    Process payment
// @access  Private
router.post('/process', auth, async (req, res) => {
  try {
    const { orderId, paymentMethod, paymentDetails } = req.body;

    const order = await Order.findOne({
      _id: orderId,
      userId: req.user._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.paymentInfo.status === 'completed') {
      return res.status(400).json({ message: 'Payment already completed' });
    }

    // Simulate payment processing
    let paymentResult = {};
    
    if (paymentMethod === 'cod') {
      // Cash on Delivery - Mark as pending
      paymentResult = {
        success: true,
        transactionId: `COD_${Date.now()}`,
        status: 'pending'
      };
    } else if (paymentMethod === 'online') {
      // Simulate online payment processing
      // In production, integrate with Razorpay, Stripe, etc.
      const isPaymentSuccessful = Math.random() > 0.1; // 90% success rate for simulation
      
      if (isPaymentSuccessful) {
        paymentResult = {
          success: true,
          transactionId: `TXN_${Date.now()}`,
          status: 'completed',
          gateway: 'razorpay' // or other gateway
        };
      } else {
        paymentResult = {
          success: false,
          error: 'Payment failed',
          status: 'failed'
        };
      }
    }

    // Update order payment info
    order.paymentInfo.status = paymentResult.status;
    order.paymentInfo.transactionId = paymentResult.transactionId;
    order.paymentInfo.paymentGateway = paymentResult.gateway;

    if (paymentResult.success) {
      if (paymentResult.status === 'completed') {
        order.paymentInfo.paidAt = new Date();
        order.orderStatus = 'confirmed';
      }
      
      // Add to status history
      order.statusHistory.push({
        status: order.orderStatus,
        note: `Payment ${paymentResult.status} via ${paymentMethod}`,
        updatedBy: req.user._id
      });
    }

    await order.save();

    res.json({
      success: paymentResult.success,
      message: paymentResult.success ? 'Payment processed successfully' : paymentResult.error,
      payment: {
        status: order.paymentInfo.status,
        transactionId: order.paymentInfo.transactionId,
        method: paymentMethod
      },
      order: {
        id: order._id,
        status: order.orderStatus,
        total: order.orderSummary.total
      }
    });
  } catch (error) {
    console.error('Process payment error:', error);
    res.status(500).json({ message: 'Payment processing failed' });
  }
});

// @route   GET /api/payments/methods
// @desc    Get available payment methods
// @access  Public
router.get('/methods', (req, res) => {
  try {
    const paymentMethods = [
      {
        id: 'cod',
        name: 'Cash on Delivery',
        description: 'Pay when your order is delivered',
        icon: 'cash',
        enabled: true,
        fees: 0
      },
      {
        id: 'online',
        name: 'Online Payment',
        description: 'Pay securely with UPI, Cards, Net Banking',
        icon: 'credit-card',
        enabled: true,
        fees: 0
      },
      {
        id: 'wallet',
        name: 'Digital Wallet',
        description: 'Pay with Paytm, PhonePe, Google Pay',
        icon: 'wallet',
        enabled: false, // Not implemented yet
        fees: 0
      }
    ];

    res.json({ paymentMethods });
  } catch (error) {
    console.error('Get payment methods error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/payments/verify
// @desc    Verify payment
// @access  Private
router.post('/verify', auth, async (req, res) => {
  try {
    const { orderId, paymentId, signature } = req.body;

    const order = await Order.findOne({
      _id: orderId,
      userId: req.user._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // In production, verify payment signature with payment gateway
    // For now, we'll simulate verification
    const isVerified = true; // Simulated verification

    if (isVerified) {
      order.paymentInfo.status = 'completed';
      order.paymentInfo.paidAt = new Date();
      order.orderStatus = 'confirmed';
      
      order.statusHistory.push({
        status: 'confirmed',
        note: 'Payment verified and confirmed',
        updatedBy: req.user._id
      });

      await order.save();

      res.json({
        success: true,
        message: 'Payment verified successfully',
        order: {
          id: order._id,
          status: order.orderStatus,
          paymentStatus: order.paymentInfo.status
        }
      });
    } else {
      res.status(400).json({
        success: false,
        message: 'Payment verification failed'
      });
    }
  } catch (error) {
    console.error('Verify payment error:', error);
    res.status(500).json({ message: 'Payment verification failed' });
  }
});

// @route   POST /api/payments/refund
// @desc    Process refund
// @access  Private
router.post('/refund', auth, async (req, res) => {
  try {
    const { orderId, reason } = req.body;

    const order = await Order.findOne({
      _id: orderId,
      userId: req.user._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.paymentInfo.status !== 'completed') {
      return res.status(400).json({ message: 'No payment to refund' });
    }

    if (!['cancelled', 'returned'].includes(order.orderStatus)) {
      return res.status(400).json({ message: 'Order is not eligible for refund' });
    }

    // Simulate refund processing
    const refundAmount = order.orderSummary.total;
    
    // In production, process actual refund through payment gateway
    const refundResult = {
      success: true,
      refundId: `REF_${Date.now()}`,
      amount: refundAmount
    };

    // Update order
    order.paymentInfo.status = 'refunded';
    order.refundAmount = refundAmount;
    
    order.statusHistory.push({
      status: 'refunded',
      note: `Refund processed: ₹${refundAmount}. Reason: ${reason}`,
      updatedBy: req.user._id
    });

    await order.save();

    res.json({
      success: true,
      message: 'Refund processed successfully',
      refund: {
        id: refundResult.refundId,
        amount: refundAmount,
        status: 'processed'
      }
    });
  } catch (error) {
    console.error('Process refund error:', error);
    res.status(500).json({ message: 'Refund processing failed' });
  }
});

module.exports = router;