const express = require('express');
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const Farmer = require('../models/Farmer');
const { auth, farmerOnly } = require('../middleware/auth');

const router = express.Router();

// @route   POST /api/orders
// @desc    Create new order
// @access  Private
router.post('/', auth, async (req, res) => {
  try {
    const { shippingAddress, billingAddress, paymentMethod, customerNote } = req.body;

    // Get user's cart
    const cart = await Cart.findOne({ userId: req.user._id })
      .populate('items.productId');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Validate stock availability and calculate totals
    let subtotal = 0;
    const orderItems = [];

    for (const item of cart.items) {
      const product = item.productId;
      
      if (!product.availability.isAvailable) {
        return res.status(400).json({ 
          message: `Product "${product.name}" is no longer available` 
        });
      }

      if (item.quantity > product.stock.quantity) {
        return res.status(400).json({ 
          message: `Insufficient stock for "${product.name}". Available: ${product.stock.quantity}` 
        });
      }

      const itemTotal = item.quantity * item.priceAtTime;
      subtotal += itemTotal;

      orderItems.push({
        productId: product._id,
        farmerId: product.farmerId,
        name: product.name,
        quantity: item.quantity,
        unit: item.unit,
        pricePerUnit: item.priceAtTime,
        totalPrice: itemTotal
      });
    }

    // Calculate shipping and tax
    const shipping = subtotal > 500 ? 0 : 50; // Free shipping above ₹500
    const tax = 0; // No tax for now
    const total = subtotal + shipping + tax;

    // Create order
    const order = new Order({
      userId: req.user._id,
      items: orderItems,
      orderSummary: {
        subtotal,
        shipping,
        tax,
        total
      },
      shippingAddress,
      billingAddress: billingAddress || shippingAddress,
      paymentInfo: {
        method: paymentMethod,
        status: paymentMethod === 'cod' ? 'pending' : 'pending'
      },
      notes: {
        customerNote
      }
    });

    await order.save();

    // Update product stock
    for (const item of cart.items) {
      await Product.findByIdAndUpdate(
        item.productId._id,
        { $inc: { stock: { quantity: -item.quantity }, totalSold: item.quantity } }
      );
    }

    // Update farmer total orders and sales
    for (const item of orderItems) {
      await Farmer.findByIdAndUpdate(
        item.farmerId,
        { 
          $inc: { 
            totalOrders: 1,
            totalSales: item.totalPrice
          }
        }
      );
    }

    // Clear cart
    cart.items = [];
    await cart.save();

    // Populate order for response
    await order.populate('items.productId', 'name images');
    await order.populate('items.farmerId', 'farmName');

    res.status(201).json({
      message: 'Order created successfully',
      order
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/orders
// @desc    Get user's orders
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;

    const filter = { userId: req.user._id };
    if (status) filter.orderStatus = status;

    const orders = await Order.find(filter)
      .populate('items.productId', 'name images')
      .populate('items.farmerId', 'farmName')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Order.countDocuments(filter);

    res.json({
      orders,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalOrders: total
      }
    });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/orders/:id
// @desc    Get single order
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findOne({
      _id: req.params.id,
      userId: req.user._id
    })
    .populate('items.productId', 'name images category')
    .populate('items.farmerId', 'farmName location')
    .populate('statusHistory.updatedBy', 'name');

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.json({ order });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/orders/:id/cancel
// @desc    Cancel order
// @access  Private
router.put('/:id/cancel', auth, async (req, res) => {
  try {
    const { reason } = req.body;

    const order = await Order.findOne({
      _id: req.params.id,
      userId: req.user._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (['shipped', 'delivered', 'cancelled'].includes(order.orderStatus)) {
      return res.status(400).json({ message: 'Order cannot be cancelled' });
    }

    // Update order status
    order.orderStatus = 'cancelled';
    order.cancelReason = reason;
    
    // Add to status history
    order.statusHistory.push({
      status: 'cancelled',
      note: reason,
      updatedBy: req.user._id
    });

    // Restore product stock
    for (const item of order.items) {
      await Product.findByIdAndUpdate(
        item.productId,
        { $inc: { 'stock.quantity': item.quantity, totalSold: -item.quantity } }
      );
    }

    // Update farmer statistics
    for (const item of order.items) {
      await Farmer.findByIdAndUpdate(
        item.farmerId,
        { 
          $inc: { 
            totalOrders: -1,
            totalSales: -item.totalPrice
          }
        }
      );
    }

    await order.save();

    res.json({
      message: 'Order cancelled successfully',
      order
    });
  } catch (error) {
    console.error('Cancel order error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/orders/farmer/orders
// @desc    Get farmer's orders
// @access  Private/Farmer
router.get('/farmer/orders', auth, farmerOnly, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;

    const farmer = await Farmer.findOne({ userId: req.user._id });
    if (!farmer) {
      return res.status(404).json({ message: 'Farmer profile not found' });
    }

    const filter = { 'items.farmerId': farmer._id };
    if (status) filter.orderStatus = status;

    const orders = await Order.find(filter)
      .populate('userId', 'name phone email')
      .populate('items.productId', 'name images')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Order.countDocuments(filter);

    res.json({
      orders,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalOrders: total
      }
    });
  } catch (error) {
    console.error('Get farmer orders error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/orders/:id/status
// @desc    Update order status (Farmer only)
// @access  Private/Farmer
router.put('/:id/status', auth, farmerOnly, async (req, res) => {
  try {
    const { status, note, trackingNumber, estimatedDelivery } = req.body;

    const farmer = await Farmer.findOne({ userId: req.user._id });
    const order = await Order.findOne({
      _id: req.params.id,
      'items.farmerId': farmer._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found or unauthorized' });
    }

    // Update order status
    order.orderStatus = status;
    
    // Add to status history
    order.statusHistory.push({
      status,
      note,
      updatedBy: req.user._id
    });

    // Update tracking info if provided
    if (trackingNumber) {
      order.tracking.trackingNumber = trackingNumber;
    }
    if (estimatedDelivery) {
      order.tracking.estimatedDelivery = estimatedDelivery;
    }

    // Update delivery date if delivered
    if (status === 'delivered') {
      order.actualDeliveryDate = new Date();
      order.tracking.actualDelivery = new Date();
    }

    await order.save();

    res.json({
      message: 'Order status updated successfully',
      order
    });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/orders/:id/rating
// @desc    Rate completed order
// @access  Private
router.post('/:id/rating', auth, async (req, res) => {
  try {
    const { overall, delivery, quality, packaging, comment } = req.body;

    const order = await Order.findOne({
      _id: req.params.id,
      userId: req.user._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.orderStatus !== 'delivered') {
      return res.status(400).json({ message: 'Order must be delivered to rate' });
    }

    if (order.rating.ratedAt) {
      return res.status(400).json({ message: 'Order already rated' });
    }

    // Update order rating
    order.rating = {
      overall,
      delivery,
      quality,
      packaging,
      comment,
      ratedAt: new Date()
    };

    await order.save();

    // Update farmer rating
    for (const item of order.items) {
      const farmer = await Farmer.findById(item.farmerId);
      const newRatingCount = farmer.rating.count + 1;
      const newAverage = ((farmer.rating.average * farmer.rating.count) + overall) / newRatingCount;
      
      farmer.rating.average = newAverage;
      farmer.rating.count = newRatingCount;
      await farmer.save();
    }

    res.json({
      message: 'Rating submitted successfully',
      rating: order.rating
    });
  } catch (error) {
    console.error('Rate order error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;