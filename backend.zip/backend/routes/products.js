const express = require('express');
const Product = require('../models/Product');
const Farmer = require('../models/Farmer');
const { auth, farmerOnly } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/products
// @desc    Get all products with filtering and pagination
// @access  Public
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 12,
      category,
      search,
      minPrice,
      maxPrice,
      organic,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      farmerId
    } = req.query;

    // Build filter object
    const filter = { isActive: true, 'availability.isAvailable': true };

    if (category) filter.category = category;
    if (farmerId) filter.farmerId = farmerId;
    if (organic === 'true') filter['quality.organic'] = true;
    
    if (minPrice || maxPrice) {
      filter['price.amount'] = {};
      if (minPrice) filter['price.amount'].$gte = Number(minPrice);
      if (maxPrice) filter['price.amount'].$lte = Number(maxPrice);
    }

    if (search) {
      filter.$text = { $search: search };
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Execute query with pagination
    const products = await Product.find(filter)
      .populate('farmerId', 'farmName location rating')
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    // Get total count for pagination
    const total = await Product.countDocuments(filter);

    res.json({
      products,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalProducts: total,
        hasNext: page * limit < total,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/products/featured
// @desc    Get featured products
// @access  Public
router.get('/featured', async (req, res) => {
  try {
    const products = await Product.find({
      isActive: true,
      isFeatured: true,
      'availability.isAvailable': true
    })
    .populate('farmerId', 'farmName location rating')
    .sort({ 'rating.average': -1 })
    .limit(8);

    res.json({ products });
  } catch (error) {
    console.error('Get featured products error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/products/categories
// @desc    Get all product categories
// @access  Public
router.get('/categories', async (req, res) => {
  try {
    const categories = await Product.distinct('category', { isActive: true });
    
    const categoriesWithCount = await Promise.all(
      categories.map(async (category) => {
        const count = await Product.countDocuments({
          category,
          isActive: true,
          'availability.isAvailable': true
        });
        return { name: category, count };
      })
    );

    res.json({ categories: categoriesWithCount });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/products/:id
// @desc    Get single product
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('farmerId', 'farmName location rating totalSales isVerified')
      .populate('reviews.userId', 'name avatar');

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Get related products
    const relatedProducts = await Product.find({
      category: product.category,
      _id: { $ne: product._id },
      isActive: true,
      'availability.isAvailable': true
    })
    .populate('farmerId', 'farmName rating')
    .limit(6);

    res.json({
      product,
      relatedProducts
    });
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/products
// @desc    Create new product (Farmer only)
// @access  Private/Farmer
router.post('/', auth, farmerOnly, async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id });
    if (!farmer) {
      return res.status(404).json({ message: 'Farmer profile not found' });
    }

    const productData = {
      ...req.body,
      farmerId: farmer._id
    };

    const product = new Product(productData);
    await product.save();

    await product.populate('farmerId', 'farmName location rating');

    res.status(201).json({
      message: 'Product created successfully',
      product
    });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/products/:id
// @desc    Update product (Farmer only)
// @access  Private/Farmer
router.put('/:id', auth, farmerOnly, async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id });
    const product = await Product.findOne({
      _id: req.params.id,
      farmerId: farmer._id
    });

    if (!product) {
      return res.status(404).json({ message: 'Product not found or unauthorized' });
    }

    Object.assign(product, req.body);
    await product.save();

    await product.populate('farmerId', 'farmName location rating');

    res.json({
      message: 'Product updated successfully',
      product
    });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/products/:id
// @desc    Delete product (Farmer only)
// @access  Private/Farmer
router.delete('/:id', auth, farmerOnly, async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id });
    const product = await Product.findOne({
      _id: req.params.id,
      farmerId: farmer._id
    });

    if (!product) {
      return res.status(404).json({ message: 'Product not found or unauthorized' });
    }

    product.isActive = false;
    await product.save();

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/products/farmer/my-products
// @desc    Get farmer's products
// @access  Private/Farmer
router.get('/farmer/my-products', auth, farmerOnly, async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id });
    
    const products = await Product.find({ farmerId: farmer._id })
      .sort({ createdAt: -1 });

    res.json({ products });
  } catch (error) {
    console.error('Get farmer products error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/products/:id/review
// @desc    Add product review
// @access  Private
router.post('/:id/review', auth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check if user already reviewed this product
    const existingReview = product.reviews.find(
      review => review.userId.toString() === req.user._id.toString()
    );

    if (existingReview) {
      return res.status(400).json({ message: 'You have already reviewed this product' });
    }

    // Add review
    const review = {
      userId: req.user._id,
      rating,
      comment,
      date: new Date()
    };

    product.reviews.push(review);

    // Update product rating
    const totalRating = product.reviews.reduce((sum, review) => sum + review.rating, 0);
    product.rating.average = totalRating / product.reviews.length;
    product.rating.count = product.reviews.length;

    await product.save();

    res.json({
      message: 'Review added successfully',
      review
    });
  } catch (error) {
    console.error('Add review error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/products/:id/stock
// @desc    Update product stock
// @access  Private/Farmer
router.put('/:id/stock', auth, farmerOnly, async (req, res) => {
  try {
    const { quantity } = req.body;
    
    const farmer = await Farmer.findOne({ userId: req.user._id });
    const product = await Product.findOne({
      _id: req.params.id,
      farmerId: farmer._id
    });

    if (!product) {
      return res.status(404).json({ message: 'Product not found or unauthorized' });
    }

    product.stock.quantity = quantity;
    product.availability.isAvailable = quantity > 0;
    
    await product.save();

    res.json({
      message: 'Stock updated successfully',
      stock: product.stock
    });
  } catch (error) {
    console.error('Update stock error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;