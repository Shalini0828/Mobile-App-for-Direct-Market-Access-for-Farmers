const express = require('express');
const Farmer = require('../models/Farmer');
const Product = require('../models/Product');
const Order = require('../models/Order');
const { auth, farmerOnly } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/farmers
// @desc    Get all farmers
// @access  Public
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 12, specialization, city, state, verified } = req.query;

    const filter = { isActive: true };
    
    if (specialization) {
      filter.specialization = { $in: [specialization] };
    }
    
    if (city) {
      filter['location.address.city'] = new RegExp(city, 'i');
    }
    
    if (state) {
      filter['location.address.state'] = new RegExp(state, 'i');
    }
    
    if (verified === 'true') {
      filter.isVerified = true;
    }

    const farmers = await Farmer.find(filter)
      .populate('userId', 'name email phone avatar')
      .sort({ 'rating.average': -1, createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Farmer.countDocuments(filter);

    res.json({
      farmers,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalFarmers: total
      }
    });
  } catch (error) {
    console.error('Get farmers error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/farmers/:id
// @desc    Get single farmer
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const farmer = await Farmer.findById(req.params.id)
      .populate('userId', 'name email phone avatar');

    if (!farmer) {
      return res.status(404).json({ message: 'Farmer not found' });
    }

    // Get farmer's products
    const products = await Product.find({
      farmerId: farmer._id,
      isActive: true,
      'availability.isAvailable': true
    }).limit(12);

    // Get farmer's recent reviews from orders
    const recentOrders = await Order.find({
      'items.farmerId': farmer._id,
      'rating.ratedAt': { $exists: true }
    })
    .populate('userId', 'name avatar')
    .sort({ 'rating.ratedAt': -1 })
    .limit(5);

    const reviews = recentOrders.map(order => ({
      userId: order.userId,
      rating: order.rating.overall,
      comment: order.rating.comment,
      date: order.rating.ratedAt
    }));

    res.json({
      farmer,
      products,
      reviews
    });
  } catch (error) {
    console.error('Get farmer error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/farmers/profile/dashboard
// @desc    Get farmer dashboard data
// @access  Private/Farmer
router.get('/profile/dashboard', auth, farmerOnly, async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id })
      .populate('userId', 'name email phone');

    if (!farmer) {
      return res.status(404).json({ message: 'Farmer profile not found' });
    }

    // Get dashboard statistics
    const totalProducts = await Product.countDocuments({ farmerId: farmer._id, isActive: true });
    const activeProducts = await Product.countDocuments({ 
      farmerId: farmer._id, 
      isActive: true, 
      'availability.isAvailable': true 
    });

    const totalOrders = await Order.countDocuments({ 'items.farmerId': farmer._id });
    const pendingOrders = await Order.countDocuments({ 
      'items.farmerId': farmer._id, 
      orderStatus: { $in: ['pending', 'confirmed', 'processing'] }
    });

    // Calculate monthly revenue
    const currentMonth = new Date();
    currentMonth.setDate(1);
    currentMonth.setHours(0, 0, 0, 0);

    const monthlyOrders = await Order.find({
      'items.farmerId': farmer._id,
      createdAt: { $gte: currentMonth },
      orderStatus: { $ne: 'cancelled' }
    });

    const monthlyRevenue = monthlyOrders.reduce((total, order) => {
      const farmerItems = order.items.filter(item => 
        item.farmerId.toString() === farmer._id.toString()
      );
      return total + farmerItems.reduce((sum, item) => sum + item.totalPrice, 0);
    }, 0);

    // Get recent orders
    const recentOrders = await Order.find({ 'items.farmerId': farmer._id })
      .populate('userId', 'name phone')
      .sort({ createdAt: -1 })
      .limit(5);

    // Get low stock products
    const lowStockProducts = await Product.find({
      farmerId: farmer._id,
      isActive: true,
      'stock.quantity': { $lt: 10 }
    }).limit(5);

    res.json({
      farmer,
      statistics: {
        totalProducts,
        activeProducts,
        totalOrders,
        pendingOrders,
        monthlyRevenue,
        rating: farmer.rating
      },
      recentOrders,
      lowStockProducts
    });
  } catch (error) {
    console.error('Get farmer dashboard error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/farmers/profile
// @desc    Update farmer profile
// @access  Private/Farmer
router.put('/profile', auth, farmerOnly, async (req, res) => {
  try {
    const {
      farmName,
      farmSize,
      location,
      specialization,
      certifications,
      bankDetails
    } = req.body;

    const farmer = await Farmer.findOne({ userId: req.user._id });
    if (!farmer) {
      return res.status(404).json({ message: 'Farmer profile not found' });
    }

    // Update farmer profile
    if (farmName) farmer.farmName = farmName;
    if (farmSize) farmer.farmSize = farmSize;
    if (location) farmer.location = { ...farmer.location, ...location };
    if (specialization) farmer.specialization = specialization;
    if (certifications) farmer.certifications = certifications;
    if (bankDetails) farmer.bankDetails = { ...farmer.bankDetails, ...bankDetails };

    await farmer.save();

    res.json({
      message: 'Profile updated successfully',
      farmer
    });
  } catch (error) {
    console.error('Update farmer profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/farmers/analytics/sales
// @desc    Get farmer sales analytics
// @access  Private/Farmer
router.get('/analytics/sales', auth, farmerOnly, async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ userId: req.user._id });
    if (!farmer) {
      return res.status(404).json({ message: 'Farmer profile not found' });
    }

    const { period = '30' } = req.query; // days
    const days = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Get orders in the period
    const orders = await Order.find({
      'items.farmerId': farmer._id,
      createdAt: { $gte: startDate },
      orderStatus: { $ne: 'cancelled' }
    }).populate('items.productId', 'name category');

    // Calculate daily sales
    const dailySales = {};
    const productSales = {};
    const categorySales = {};

    orders.forEach(order => {
      const date = order.createdAt.toISOString().split('T')[0];
      
      order.items.forEach(item => {
        if (item.farmerId.toString() === farmer._id.toString()) {
          // Daily sales
          if (!dailySales[date]) {
            dailySales[date] = { revenue: 0, orders: 0 };
          }
          dailySales[date].revenue += item.totalPrice;
          dailySales[date].orders += 1;

          // Product sales
          const productName = item.name;
          if (!productSales[productName]) {
            productSales[productName] = { quantity: 0, revenue: 0 };
          }
          productSales[productName].quantity += item.quantity;
          productSales[productName].revenue += item.totalPrice;

          // Category sales
          if (item.productId && item.productId.category) {
            const category = item.productId.category;
            if (!categorySales[category]) {
              categorySales[category] = { quantity: 0, revenue: 0 };
            }
            categorySales[category].quantity += item.quantity;
            categorySales[category].revenue += item.totalPrice;
          }
        }
      });
    });

    // Convert to arrays for charts
    const dailyData = Object.entries(dailySales).map(([date, data]) => ({
      date,
      ...data
    })).sort((a, b) => new Date(a.date) - new Date(b.date));

    const topProducts = Object.entries(productSales)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    const categoryData = Object.entries(categorySales)
      .map(([category, data]) => ({ category, ...data }))
      .sort((a, b) => b.revenue - a.revenue);

    res.json({
      period: days,
      summary: {
        totalRevenue: Object.values(productSales).reduce((sum, item) => sum + item.revenue, 0),
        totalOrders: orders.length,
        totalQuantity: Object.values(productSales).reduce((sum, item) => sum + item.quantity, 0)
      },
      dailySales: dailyData,
      topProducts,
      categoryBreakdown: categoryData
    });
  } catch (error) {
    console.error('Get sales analytics error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;