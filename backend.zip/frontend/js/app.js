// FarmConnect - Frontend JavaScript Application
// This file handles all client-side functionality for the e-commerce platform

// Global configuration
const CONFIG = {
    API_BASE_URL: 'http://localhost:5000/api',
    TOKEN_KEY: 'farmconnect_token',
    USER_KEY: 'farmconnect_user',
    CART_KEY: 'farmconnect_cart'
};

// Global state management
class AppState {
    constructor() {
        this.user = this.loadUser();
        this.cart = this.loadCart();
        this.products = [];
        this.farmers = [];
        this.orders = [];
        this.currentPage = 'home';
        this.filters = {
            category: '',
            minPrice: '',
            maxPrice: '',
            organic: false,
            sort: 'createdAt_desc'
        };
    }

    // User management
    loadUser() {
        const userData = localStorage.getItem(CONFIG.USER_KEY);
        return userData ? JSON.parse(userData) : null;
    }

    saveUser(user) {
        this.user = user;
        localStorage.setItem(CONFIG.USER_KEY, JSON.stringify(user));
    }

    clearUser() {
        this.user = null;
        localStorage.removeItem(CONFIG.USER_KEY);
        localStorage.removeItem(CONFIG.TOKEN_KEY);
    }

    // Cart management
    loadCart() {
        const cartData = localStorage.getItem(CONFIG.CART_KEY);
        return cartData ? JSON.parse(cartData) : { items: [], total: 0 };
    }

    saveCart() {
        localStorage.setItem(CONFIG.CART_KEY, JSON.stringify(this.cart));
        this.updateCartUI();
    }

    addToCart(product, quantity = 1) {
        const existingItem = this.cart.items.find(item => item.product._id === product._id);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.cart.items.push({
                product: product,
                quantity: quantity,
                price: product.price.amount
            });
        }
        
        this.calculateCartTotal();
        this.saveCart();
        showNotification('Product added to cart!', 'success');
    }

    removeFromCart(productId) {
        this.cart.items = this.cart.items.filter(item => item.product._id !== productId);
        this.calculateCartTotal();
        this.saveCart();
    }

    updateCartQuantity(productId, quantity) {
        const item = this.cart.items.find(item => item.product._id === productId);
        if (item) {
            if (quantity <= 0) {
                this.removeFromCart(productId);
            } else {
                item.quantity = quantity;
                this.calculateCartTotal();
                this.saveCart();
            }
        }
    }

    calculateCartTotal() {
        this.cart.subtotal = this.cart.items.reduce((total, item) => 
            total + (item.price * item.quantity), 0
        );
        this.cart.shipping = this.cart.subtotal > 500 ? 0 : 50; // Free shipping above ₹500
        this.cart.tax = Math.round(this.cart.subtotal * 0.05); // 5% tax
        this.cart.total = this.cart.subtotal + this.cart.shipping + this.cart.tax;
    }

    updateCartUI() {
        const cartCount = document.getElementById('cart-count');
        const cartIcon = document.getElementById('cart-icon');
        
        if (cartCount && cartIcon) {
            const totalItems = this.cart.items.reduce((sum, item) => sum + item.quantity, 0);
            cartCount.textContent = totalItems;
            cartIcon.style.display = totalItems > 0 ? 'block' : 'none';
        }
    }

    clearCart() {
        this.cart = { items: [], total: 0 };
        this.saveCart();
    }
}

// Initialize global state
const appState = new AppState();

// API utility functions
class ApiService {
    static async request(endpoint, options = {}) {
        const token = localStorage.getItem(CONFIG.TOKEN_KEY);
        const url = `${CONFIG.API_BASE_URL}${endpoint}`;
        
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': `Bearer ${token}` })
            },
            ...options
        };

        if (config.body && typeof config.body === 'object') {
            config.body = JSON.stringify(config.body);
        }

        try {
            showLoading(true);
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'An error occurred');
            }
            
            return data;
        } catch (error) {
            console.error('API Error:', error);
            showNotification(error.message, 'error');
            throw error;
        } finally {
            showLoading(false);
        }
    }

    // Authentication APIs
    static async login(email, password) {
        return this.request('/auth/login', {
            method: 'POST',
            body: { email, password }
        });
    }

    static async register(userData) {
        return this.request('/auth/register', {
            method: 'POST',
            body: userData
        });
    }

    static async getProfile() {
        return this.request('/auth/profile');
    }

    // Product APIs
    static async getProducts(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/products${queryString ? `?${queryString}` : ''}`);
    }

    static async getProduct(id) {
        return this.request(`/products/${id}`);
    }

    static async createProduct(productData) {
        return this.request('/products', {
            method: 'POST',
            body: productData
        });
    }

    static async updateProduct(id, productData) {
        return this.request(`/products/${id}`, {
            method: 'PUT',
            body: productData
        });
    }

    static async deleteProduct(id) {
        return this.request(`/products/${id}`, {
            method: 'DELETE'
        });
    }

    // Cart APIs
    static async getCart() {
        return this.request('/cart');
    }

    static async addToCart(productId, quantity) {
        return this.request('/cart/add', {
            method: 'POST',
            body: { productId, quantity }
        });
    }

    static async updateCartItem(productId, quantity) {
        return this.request('/cart/update', {
            method: 'PUT',
            body: { productId, quantity }
        });
    }

    static async removeFromCart(productId) {
        return this.request('/cart/remove', {
            method: 'DELETE',
            body: { productId }
        });
    }

    // Order APIs
    static async createOrder(orderData) {
        return this.request('/orders', {
            method: 'POST',
            body: orderData
        });
    }

    static async getOrders(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return this.request(`/orders${queryString ? `?${queryString}` : ''}`);
    }

    static async updateOrderStatus(orderId, status) {
        return this.request(`/orders/${orderId}/status`, {
            method: 'PUT',
            body: { status }
        });
    }

    // Farmer APIs
    static async getFarmers() {
        return this.request('/farmers');
    }

    static async getFarmerStats() {
        return this.request('/farmers/stats');
    }

    static async getFarmerOrders() {
        return this.request('/farmers/orders');
    }

    // Admin APIs
    static async getAdminStats() {
        return this.request('/admin/stats');
    }

    static async getAdminOrders() {
        return this.request('/admin/orders');
    }

    static async getAllUsers() {
        return this.request('/admin/users');
    }

    static async toggleUserStatus(userId, status) {
        return this.request(`/admin/users/${userId}/status`, {
            method: 'PUT',
            body: { status }
        });
    }

    // Payment APIs
    static async processPayment(paymentData) {
        return this.request('/payments/process', {
            method: 'POST',
            body: paymentData
        });
    }
}

// UI Utility functions
function showLoading(show = true) {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.display = show ? 'flex' : 'none';
    }
}

function showNotification(message, type = 'info', duration = 3000) {
    const container = document.getElementById('notification-container');
    if (!container) return;

    const notification = document.createElement('div');
    notification.className = `notification ${type} fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg text-white max-w-md transform translate-x-full transition-transform duration-300`;
    
    const bgColor = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        warning: 'bg-yellow-500',
        info: 'bg-blue-500'
    }[type] || 'bg-blue-500';
    
    notification.classList.add(bgColor);
    notification.innerHTML = `
        <div class="flex items-center justify-between">
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `;

    container.appendChild(notification);

    // Animate in
    setTimeout(() => notification.classList.remove('translate-x-full'), 10);

    // Auto remove
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => notification.remove(), 300);
    }, duration);
}

// Authentication functions
function openAuthModal(defaultRole = 'user') {
    const modal = document.getElementById('auth-modal');
    const registerRole = document.getElementById('register-role');
    
    if (registerRole) {
        registerRole.value = defaultRole;
        toggleFarmerDetails();
    }
    
    modal.style.display = 'flex';
}

function closeAuthModal() {
    const modal = document.getElementById('auth-modal');
    modal.style.display = 'none';
}

function switchAuthMode() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const authTitle = document.getElementById('auth-title');
    const switchText = document.getElementById('switch-text');
    
    if (loginForm.classList.contains('hidden')) {
        // Switch to login
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
        authTitle.textContent = 'Welcome Back';
        switchText.textContent = "Don't have an account? Register";
    } else {
        // Switch to register
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
        authTitle.textContent = 'Join FarmConnect';
        switchText.textContent = 'Already have an account? Login';
    }
}

function toggleFarmerDetails() {
    const role = document.getElementById('register-role').value;
    const farmerDetails = document.getElementById('farmer-details');
    
    if (role === 'farmer') {
        farmerDetails.classList.remove('hidden');
    } else {
        farmerDetails.classList.add('hidden');
    }
}

async function login(event) {
    event.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const loginBtn = document.getElementById('login-btn-text');
    const loginLoading = document.getElementById('login-loading');
    
    try {
        loginBtn.style.display = 'none';
        loginLoading.style.display = 'block';
        
        const response = await ApiService.login(email, password);
        
        // Store token and user data
        localStorage.setItem(CONFIG.TOKEN_KEY, response.token);
        appState.saveUser(response.user);
        
        closeAuthModal();
        updateAuthUI();
        showNotification('Login successful!', 'success');
        
        // Redirect based on user role
        if (response.user.role === 'farmer') {
            showPage('farmer-dashboard');
        } else if (response.user.role === 'admin') {
            showPage('admin-dashboard');
        } else {
            showPage('home');
        }
        
    } catch (error) {
        console.error('Login error:', error);
    } finally {
        loginBtn.style.display = 'block';
        loginLoading.style.display = 'none';
    }
}

async function register(event) {
    event.preventDefault();
    
    const formData = {
        name: document.getElementById('register-name').value,
        email: document.getElementById('register-email').value,
        password: document.getElementById('register-password').value,
        phone: document.getElementById('register-phone').value,
        role: document.getElementById('register-role').value
    };
    
    // Add farmer-specific data if role is farmer
    if (formData.role === 'farmer') {
        formData.farmName = document.getElementById('farm-name').value;
        formData.farmSize = document.getElementById('farm-size').value;
    }
    
    const registerBtn = document.getElementById('register-btn-text');
    const registerLoading = document.getElementById('register-loading');
    
    try {
        registerBtn.style.display = 'none';
        registerLoading.style.display = 'block';
        
        const response = await ApiService.register(formData);
        
        // Store token and user data
        localStorage.setItem(CONFIG.TOKEN_KEY, response.token);
        appState.saveUser(response.user);
        
        closeAuthModal();
        updateAuthUI();
        showNotification('Registration successful!', 'success');
        
        // Redirect based on user role
        if (response.user.role === 'farmer') {
            showPage('farmer-dashboard');
        } else {
            showPage('home');
        }
        
    } catch (error) {
        console.error('Registration error:', error);
    } finally {
        registerBtn.style.display = 'block';
        registerLoading.style.display = 'none';
    }
}

function logout() {
    appState.clearUser();
    appState.clearCart();
    updateAuthUI();
    showPage('home');
    showNotification('Logged out successfully!', 'success');
}

function updateAuthUI() {
    const loginBtn = document.getElementById('login-btn');
    const userProfile = document.getElementById('user-profile');
    const userAvatar = document.getElementById('user-avatar');
    const userName = document.getElementById('user-name');
    const dashboardLink = document.getElementById('dashboard-link');
    const cartIcon = document.getElementById('cart-icon');
    
    if (appState.user) {
        // User is logged in
        loginBtn.style.display = 'none';
        userProfile.style.display = 'flex';
        
        if (userAvatar) {
            userAvatar.textContent = appState.user.name.charAt(0).toUpperCase();
        }
        if (userName) {
            userName.textContent = appState.user.name;
        }
        
        // Show dashboard link based on role
        if (dashboardLink) {
            dashboardLink.style.display = 'block';
            dashboardLink.textContent = appState.user.role === 'farmer' ? 'Dashboard' : 
                                       appState.user.role === 'admin' ? 'Admin' : 'Dashboard';
            dashboardLink.onclick = () => showPage(appState.user.role === 'farmer' ? 'farmer-dashboard' : 
                                                 appState.user.role === 'admin' ? 'admin-dashboard' : 'orders');
        }
        
        // Show cart for users
        if (cartIcon && appState.user.role === 'user') {
            cartIcon.style.display = 'block';
        }
        
    } else {
        // User is not logged in
        loginBtn.style.display = 'block';
        userProfile.style.display = 'none';
        
        if (dashboardLink) {
            dashboardLink.style.display = 'none';
        }
        if (cartIcon) {
            cartIcon.style.display = 'none';
        }
    }
}

// Page navigation functions
function showPage(pageName) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.remove('active');
        page.style.display = 'none';
    });
    
    // Show selected page
    const targetPage = document.getElementById(`${pageName}-page`) || document.getElementById(pageName);
    if (targetPage) {
        targetPage.classList.add('active');
        targetPage.style.display = 'block';
        appState.currentPage = pageName;
        
        // Load page-specific data
        loadPageData(pageName);
    }
}

async function loadPageData(pageName) {
    try {
        switch (pageName) {
            case 'home':
                await loadFeaturedProducts();
                break;
            case 'products':
                await loadProducts();
                break;
            case 'farmers':
                await loadFarmers();
                break;
            case 'cart':
                await loadCart();
                break;
            case 'orders':
                await loadOrders();
                break;
            case 'farmer-dashboard':
                await loadFarmerDashboard();
                break;
            case 'admin-dashboard':
                await loadAdminDashboard();
                break;
        }
    } catch (error) {
        console.error('Error loading page data:', error);
    }
}

// Product functions
async function loadFeaturedProducts() {
    try {
        const response = await ApiService.getProducts({ limit: 4, featured: true });
        renderFeaturedProducts(response.products || []);
    } catch (error) {
        console.error('Error loading featured products:', error);
    }
}

async function loadProducts() {
    try {
        const params = { ...appState.filters };
        const response = await ApiService.getProducts(params);
        renderProducts(response.products || []);
        renderPagination(response.pagination || {});
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

function renderFeaturedProducts(products) {
    const container = document.getElementById('featured-products');
    if (!container) return;
    
    container.innerHTML = products.map(product => createProductCard(product)).join('');
}

function renderProducts(products) {
    const container = document.getElementById('products-grid');
    if (!container) return;
    
    if (products.length === 0) {
        container.innerHTML = `
            <div class="col-span-full text-center py-12">
                <div class="text-gray-400 text-6xl mb-4">🔍</div>
                <h3 class="text-xl font-medium text-gray-600 mb-2">No products found</h3>
                <p class="text-gray-500">Try adjusting your filters or search terms</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = products.map(product => createProductCard(product)).join('');
}

function createProductCard(product) {
    const isInCart = appState.cart.items.some(item => item.product._id === product._id);
    const isOutOfStock = product.inventory.quantity <= 0;
    
    return `
        <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
            <div class="relative">
                <img src="${product.images[0] || '/api/placeholder/300/200'}" 
                     alt="${product.name}" 
                     class="w-full h-48 object-cover">
                ${product.organic ? '<span class="absolute top-2 left-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Organic</span>' : ''}
                ${isOutOfStock ? '<span class="absolute top-2 right-2 bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">Out of Stock</span>' : ''}
            </div>
            <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">${product.name}</h3>
                <p class="text-gray-600 text-sm mb-2">${product.description}</p>
                <div class="flex items-center justify-between mb-3">
                    <span class="text-2xl font-bold text-green-600">₹${product.price.amount}</span>
                    <span class="text-sm text-gray-500">per ${product.price.unit}</span>
                </div>
                <div class="flex items-center justify-between mb-3">
                    <span class="text-sm text-gray-600">By: ${product.farmer.name}</span>
                    <div class="flex items-center">
                        <span class="text-yellow-400">⭐</span>
                        <span class="text-sm text-gray-600 ml-1">${product.rating.average.toFixed(1)}</span>
                    </div>
                </div>
                <button onclick="addToCart('${product._id}')" 
                        class="w-full btn-primary ${isOutOfStock ? 'opacity-50 cursor-not-allowed' : ''}" 
                        ${isOutOfStock ? 'disabled' : ''}>
                    ${isOutOfStock ? 'Out of Stock' : isInCart ? 'In Cart' : 'Add to Cart'}
                </button>
            </div>
        </div>
    `;
}

function applyFilters() {
    appState.filters = {
        category: document.getElementById('category-filter').value,
        sort: document.getElementById('sort-filter').value,
        minPrice: document.getElementById('min-price').value,
        maxPrice: document.getElementById('max-price').value,
        organic: document.getElementById('organic-filter').checked
    };
    
    loadProducts();
}

async function addToCart(productId) {
    if (!appState.user) {
        openAuthModal();
        return;
    }
    
    if (appState.user.role !== 'user') {
        showNotification('Only customers can add items to cart', 'warning');
        return;
    }
    
    try {
        // Find product in current products list
        const product = appState.products.find(p => p._id === productId);
        if (product) {
            appState.addToCart(product);
            
            // Also update server cart if user is logged in
            await ApiService.addToCart(productId, 1);
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
    }
}

// Cart functions
async function loadCart() {
    const container = document.getElementById('cart-items');
    const checkoutBtn = document.getElementById('checkout-btn');
    
    if (!container) return;
    
    if (appState.cart.items.length === 0) {
        container.innerHTML = `
            <div class="text-center py-12">
                <div class="text-gray-400 text-6xl mb-4">🛒</div>
                <h3 class="text-xl font-medium text-gray-600 mb-2">Your cart is empty</h3>
                <p class="text-gray-500 mb-4">Add some fresh products from our farmers</p>
                <button onclick="showPage('products')" class="btn-primary">Start Shopping</button>
            </div>
        `;
        if (checkoutBtn) checkoutBtn.disabled = true;
        return;
    }
    
    container.innerHTML = appState.cart.items.map(item => createCartItemCard(item)).join('');
    updateCartSummary();
    if (checkoutBtn) checkoutBtn.disabled = false;
}

function createCartItemCard(item) {
    return `
        <div class="bg-white rounded-lg shadow-md p-4 flex items-center space-x-4">
            <img src="${item.product.images[0] || '/api/placeholder/100/100'}" 
                 alt="${item.product.name}" 
                 class="w-16 h-16 object-cover rounded-lg">
            <div class="flex-grow">
                <h3 class="font-semibold">${item.product.name}</h3>
                <p class="text-gray-600 text-sm">₹${item.price} per ${item.product.price.unit}</p>
                <p class="text-gray-500 text-sm">By: ${item.product.farmer.name}</p>
            </div>
            <div class="flex items-center space-x-3">
                <button onclick="updateCartQuantity('${item.product._id}', ${item.quantity - 1})" 
                        class="w-8 h-8 rounded-full bg-gray-200 hover:bg-gray-300 flex items-center justify-center">
                    -
                </button>
                <span class="w-8 text-center">${item.quantity}</span>
                <button onclick="updateCartQuantity('${item.product._id}', ${item.quantity + 1})" 
                        class="w-8 h-8 rounded-full bg-gray-200 hover:bg-gray-300 flex items-center justify-center">
                    +
                </button>
            </div>
            <div class="text-right">
                <p class="font-semibold">₹${(item.price * item.quantity).toFixed(2)}</p>
                <button onclick="removeFromCart('${item.product._id}')" 
                        class="text-red-500 hover:text-red-700 text-sm">
                    Remove
                </button>
            </div>
        </div>
    `;
}

function updateCartSummary() {
    appState.calculateCartTotal();
    
    const subtotal = document.getElementById('cart-subtotal');
    const shipping = document.getElementById('cart-shipping');
    const total = document.getElementById('cart-total');
    
    if (subtotal) subtotal.textContent = `₹${appState.cart.subtotal.toFixed(2)}`;
    if (shipping) shipping.textContent = `₹${appState.cart.shipping.toFixed(2)}`;
    if (total) total.textContent = `₹${appState.cart.total.toFixed(2)}`;
}

function updateCartQuantity(productId, quantity) {
    appState.updateCartQuantity(productId, quantity);
    loadCart();
}

function removeFromCart(productId) {
    appState.removeFromCart(productId);
    loadCart();
}

function proceedToCheckout() {
    if (!appState.user) {
        openAuthModal();
        return;
    }
    
    if (appState.cart.items.length === 0) {
        showNotification('Your cart is empty', 'warning');
        return;
    }
    
    showPage('checkout');
    loadCheckout();
}

// Checkout functions
function loadCheckout() {
    updateCheckoutSummary();
    
    // Pre-fill user data if available
    if (appState.user) {
        document.getElementById('shipping-name').value = appState.user.name || '';
        document.getElementById('shipping-phone').value = appState.user.phone || '';
    }
}

function updateCheckoutSummary() {
    const container = document.getElementById('checkout-items');
    const subtotal = document.getElementById('checkout-subtotal');
    const shipping = document.getElementById('checkout-shipping');
    const tax = document.getElementById('checkout-tax');
    const total = document.getElementById('checkout-total');
    
    if (container) {
        container.innerHTML = appState.cart.items.map(item => `
            <div class="flex justify-between items-center">
                <div>
                    <span class="font-medium">${item.product.name}</span>
                    <span class="text-gray-500"> × ${item.quantity}</span>
                </div>
                <span>₹${(item.price * item.quantity).toFixed(2)}</span>
            </div>
        `).join('');
    }
    
    appState.calculateCartTotal();
    
    if (subtotal) subtotal.textContent = `₹${appState.cart.subtotal.toFixed(2)}`;
    if (shipping) shipping.textContent = `₹${appState.cart.shipping.toFixed(2)}`;
    if (tax) tax.textContent = `₹${appState.cart.tax.toFixed(2)}`;
    if (total) total.textContent = `₹${appState.cart.total.toFixed(2)}`;
}

async function placeOrder() {
    if (!appState.user) {
        openAuthModal();
        return;
    }
    
    const form = document.getElementById('checkout-form');
    const formData = new FormData(form);
    
    const orderData = {
        items: appState.cart.items.map(item => ({
            product: item.product._id,
            quantity: item.quantity,
            price: item.price
        })),
        shippingAddress: {
            name: document.getElementById('shipping-name').value,
            phone: document.getElementById('shipping-phone').value,
            street: document.getElementById('shipping-street').value,
            city: document.getElementById('shipping-city').value,
            state: document.getElementById('shipping-state').value,
            pincode: document.getElementById('shipping-pincode').value,
            country: document.getElementById('shipping-country').value
        },
        paymentMethod: document.querySelector('input[name="payment-method"]:checked').value,
        totalAmount: appState.cart.total
    };
    
    const placeOrderBtn = document.getElementById('place-order-text');
    const placeOrderLoading = document.getElementById('place-order-loading');
    
    try {
        placeOrderBtn.style.display = 'none';
        placeOrderLoading.style.display = 'block';
        
        const response = await ApiService.createOrder(orderData);
        
        if (orderData.paymentMethod === 'online') {
            // Process online payment
            await ApiService.processPayment({
                orderId: response.order._id,
                amount: orderData.totalAmount,
                method: 'online'
            });
        }
        
        appState.clearCart();
        showNotification('Order placed successfully!', 'success');
        showPage('orders');
        
    } catch (error) {
        console.error('Error placing order:', error);
    } finally {
        placeOrderBtn.style.display = 'block';
        placeOrderLoading.style.display = 'none';
    }
}

// Orders functions
async function loadOrders() {
    if (!appState.user) {
        showPage('home');
        return;
    }

    try {
        let response;
        
        switch (appState.user.role) {
            case 'user':
                response = await ApiService.getOrders();
                renderUserOrders(response.orders || []);
                break;
            case 'farmer':
                response = await ApiService.getFarmerOrders();
                renderFarmerOrders(response.orders || []);
                break;
            case 'admin':
                response = await ApiService.getAdminOrders();
                renderAdminOrders(response.orders || []);
                break;
            default:
                showNotification('Invalid user role', 'error');
                return;
        }
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

async function loadUserOrders() {
    try {
        const response = await ApiService.getOrders();
        renderUserOrders(response.orders || []);
    } catch (error) {
        console.error('Error loading user orders:', error);
    }
}

async function loadFarmerOrders() {
    try {
        const response = await ApiService.getFarmerOrders();
        renderFarmerOrders(response.orders || []);
    } catch (error) {
        console.error('Error loading farmer orders:', error);
    }
}

async function loadAdminOrders() {
    try {
        const response = await ApiService.getAdminOrders();
        renderAdminOrders(response.orders || []);
    } catch (error) {
        console.error('Error loading admin orders:', error);
    }
}

function renderUserOrders(orders) {
    const container = document.getElementById('orders-list');
    if (!container) return;
    
    if (orders.length === 0) {
        container.innerHTML = `
            <div class="text-center py-12">
                <div class="text-gray-400 text-6xl mb-4">📦</div>
                <h3 class="text-xl font-medium text-gray-600 mb-2">No orders yet</h3>
                <p class="text-gray-500 mb-4">Start shopping to see your orders here</p>
                <button onclick="showPage('products')" class="btn-primary">Start Shopping</button>
            </div>
        `;
        return;
    }
    
    container.innerHTML = orders.map(order => createUserOrderCard(order)).join('');
}

function renderFarmerOrders(orders) {
    const container = document.getElementById('orders-list');
    if (!container) return;
    
    if (orders.length === 0) {
        container.innerHTML = `
            <div class="text-center py-12">
                <div class="text-gray-400 text-6xl mb-4">📦</div>
                <h3 class="text-xl font-medium text-gray-600 mb-2">No orders yet</h3>
                <p class="text-gray-500 mb-4">Orders for your products will appear here</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = orders.map(order => createFarmerOrderCard(order)).join('');
}

function renderAdminOrders(orders) {
    const container = document.getElementById('orders-list');
    if (!container) return;
    
    if (orders.length === 0) {
        container.innerHTML = `
            <div class="text-center py-12">
                <div class="text-gray-400 text-6xl mb-4">📦</div>
                <h3 class="text-xl font-medium text-gray-600 mb-2">No orders in the system</h3>
                <p class="text-gray-500 mb-4">All orders will be displayed here for tracking</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = orders.map(order => createAdminOrderCard(order)).join('');
}

function createUserOrderCard(order) {
    const statusColors = {
        pending: 'bg-yellow-100 text-yellow-800',
        confirmed: 'bg-blue-100 text-blue-800',
        processing: 'bg-blue-100 text-blue-800',
        shipped: 'bg-purple-100 text-purple-800',
        delivered: 'bg-green-100 text-green-800',
        cancelled: 'bg-red-100 text-red-800'
    };
    
    return `
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h3 class="font-semibold text-lg">Order #${order.orderNumber || order._id.slice(-8)}</h3>
                    <p class="text-gray-600">Placed on ${new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <span class="px-3 py-1 rounded-full text-sm ${statusColors[order.orderStatus] || 'bg-gray-100 text-gray-800'}">
                    ${order.orderStatus.charAt(0).toUpperCase() + order.orderStatus.slice(1)}
                </span>
            </div>
            
            <div class="space-y-2 mb-4">
                ${order.items.map(item => `
                    <div class="flex justify-between items-center">
                        <span>${item.name || item.product?.name} × ${item.quantity}</span>
                        <span>₹${item.totalPrice.toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="border-t pt-4 flex justify-between items-center">
                <div>
                    <span class="font-semibold">Total: ₹${order.orderSummary?.total?.toFixed(2) || order.totalAmount?.toFixed(2)}</span>
                    <span class="text-gray-600 ml-2">(${order.paymentInfo?.method || order.paymentMethod})</span>
                </div>
                <button onclick="viewOrderDetails('${order._id}')" class="text-blue-600 hover:text-blue-800">
                    View Details
                </button>
            </div>
        </div>
    `;
}

function createFarmerOrderCard(order) {
    const statusColors = {
        pending: 'bg-yellow-100 text-yellow-800',
        confirmed: 'bg-blue-100 text-blue-800',
        processing: 'bg-blue-100 text-blue-800',
        shipped: 'bg-purple-100 text-purple-800',
        delivered: 'bg-green-100 text-green-800',
        cancelled: 'bg-red-100 text-red-800'
    };
    
    return `
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h3 class="font-semibold text-lg">Order #${order.orderNumber || order._id.slice(-8)}</h3>
                    <p class="text-gray-600">Customer: ${order.userId?.name || 'Unknown'}</p>
                    <p class="text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <span class="px-3 py-1 rounded-full text-sm ${statusColors[order.orderStatus] || 'bg-gray-100 text-gray-800'}">
                    ${order.orderStatus.charAt(0).toUpperCase() + order.orderStatus.slice(1)}
                </span>
            </div>
            
            <div class="space-y-2 mb-4">
                ${order.items.map(item => `
                    <div class="flex justify-between items-center">
                        <span>${item.name || item.product?.name} × ${item.quantity}</span>
                        <span>₹${item.totalPrice.toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="border-t pt-4 flex justify-between items-center">
                <div>
                    <span class="font-semibold">Total: ₹${order.orderSummary?.total?.toFixed(2) || order.totalAmount?.toFixed(2)}</span>
                </div>
                <div class="flex space-x-2">
                    <select onchange="updateOrderStatus('${order._id}', this.value)" 
                            class="text-sm border border-gray-300 rounded px-2 py-1">
                        <option value="pending" ${order.orderStatus === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="confirmed" ${order.orderStatus === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                        <option value="processing" ${order.orderStatus === 'processing' ? 'selected' : ''}>Processing</option>
                        <option value="shipped" ${order.orderStatus === 'shipped' ? 'selected' : ''}>Shipped</option>
                        <option value="delivered" ${order.orderStatus === 'delivered' ? 'selected' : ''}>Delivered</option>
                    </select>
                    <button onclick="viewOrderDetails('${order._id}')" class="text-blue-600 hover:text-blue-800">
                        View Details
                    </button>
                </div>
            </div>
        </div>
    `;
}

function createAdminOrderCard(order) {
    const statusColors = {
        pending: 'bg-yellow-100 text-yellow-800',
        confirmed: 'bg-blue-100 text-blue-800',
        processing: 'bg-blue-100 text-blue-800',
        shipped: 'bg-purple-100 text-purple-800',
        delivered: 'bg-green-100 text-green-800',
        cancelled: 'bg-red-100 text-red-800'
    };
    
    return `
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h3 class="font-semibold text-lg">Order #${order.orderNumber || order._id.slice(-8)}</h3>
                    <p class="text-gray-600">Customer: ${order.userId?.name || 'Unknown'}</p>
                    <p class="text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <span class="px-3 py-1 rounded-full text-sm ${statusColors[order.orderStatus] || 'bg-gray-100 text-gray-800'}">
                    ${order.orderStatus.charAt(0).toUpperCase() + order.orderStatus.slice(1)}
                </span>
            </div>
            
            <div class="space-y-2 mb-4">
                ${order.items.map(item => `
                    <div class="flex justify-between items-center">
                        <span>${item.name || item.product?.name} × ${item.quantity}</span>
                        <span>₹${item.totalPrice.toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="border-t pt-4 flex justify-between items-center">
                <div>
                    <span class="font-semibold">Total: ₹${order.orderSummary?.total?.toFixed(2) || order.totalAmount?.toFixed(2)}</span>
                    <span class="text-gray-600 ml-2">(${order.paymentInfo?.method || order.paymentMethod})</span>
                </div>
                <button onclick="viewOrderDetails('${order._id}')" class="text-blue-600 hover:text-blue-800">
                    View Details
                </button>
            </div>
        </div>
    `;
}

// Farmer Dashboard functions
async function loadFarmerDashboard() {
    if (appState.user?.role !== 'farmer') {
        showPage('home');
        return;
    }
    
    try {
        const stats = await ApiService.getFarmerStats();
        updateFarmerStats(stats);
        showFarmerTab('products'); // Default to products tab
    } catch (error) {
        console.error('Error loading farmer dashboard:', error);
    }
}

function updateFarmerStats(stats) {
    document.getElementById('farmer-total-products').textContent = stats.totalProducts || 0;
    document.getElementById('farmer-total-orders').textContent = stats.totalOrders || 0;
    document.getElementById('farmer-monthly-revenue').textContent = `₹${(stats.monthlyRevenue || 0).toFixed(2)}`;
    document.getElementById('farmer-rating').textContent = (stats.averageRating || 0).toFixed(1);
}

function showFarmerTab(tabName) {
    // Update tab buttons
    const tabs = document.querySelectorAll('.farmer-tab-btn');
    tabs.forEach(tab => tab.classList.remove('tab-active'));
    document.querySelector(`[onclick="showFarmerTab('${tabName}')"]`).classList.add('tab-active');
    
    // Show/hide tab content
    const tabContents = document.querySelectorAll('.farmer-tab');
    tabContents.forEach(content => content.classList.add('hidden'));
    document.getElementById(`farmer-${tabName}-tab`).classList.remove('hidden');
    
    // Load tab-specific data
    switch (tabName) {
        case 'products':
            loadFarmerProducts();
            break;
        case 'orders':
            loadFarmerOrders();
            break;
        case 'analytics':
            loadFarmerAnalytics();
            break;
    }
}

async function loadFarmerProducts() {
    try {
        const response = await ApiService.getProducts({ farmer: appState.user._id });
        renderFarmerProducts(response.products || []);
    } catch (error) {
        console.error('Error loading farmer products:', error);
    }
}

function renderFarmerProducts(products) {
    const container = document.getElementById('farmer-products-list');
    if (!container) return;
    
    if (products.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8">
                <p class="text-gray-500 mb-4">You haven't added any products yet</p>
                <button onclick="showAddProductForm()" class="btn-primary">Add Your First Product</button>
            </div>
        `;
        return;
    }
    
    container.innerHTML = products.map(product => createFarmerProductCard(product)).join('');
}

function createFarmerProductCard(product) {
    return `
        <div class="bg-gray-50 rounded-lg p-4 flex items-center justify-between">
            <div class="flex items-center space-x-4">
                <img src="${product.images[0] || '/api/placeholder/60/60'}" 
                     alt="${product.name}" 
                     class="w-15 h-15 object-cover rounded-lg">
                <div>
                    <h4 class="font-semibold">${product.name}</h4>
                    <p class="text-gray-600">₹${product.price.amount} per ${product.price.unit}</p>
                    <p class="text-sm text-gray-500">Stock: ${product.inventory.quantity}</p>
                </div>
            </div>
            <div class="flex items-center space-x-2">
                <button onclick="editProduct('${product._id}')" class="text-blue-600 hover:text-blue-800">
                    Edit
                </button>
                <button onclick="toggleProductStatus('${product._id}', ${!product.active})" 
                        class="text-${product.active ? 'red' : 'green'}-600 hover:text-${product.active ? 'red' : 'green'}-800">
                    ${product.active ? 'Deactivate' : 'Activate'}
                </button>
            </div>
        </div>
    `;
}

async function loadFarmerOrders() {
    try {
        const response = await ApiService.getFarmerOrders();
        renderFarmerOrders(response.orders || []);
    } catch (error) {
        console.error('Error loading farmer orders:', error);
    }
}

function renderFarmerOrders(orders) {
    const container = document.getElementById('farmer-orders-list');
    if (!container) return;
    
    if (orders.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-8">No orders yet</p>';
        return;
    }
    
    container.innerHTML = orders.map(order => createFarmerOrderCard(order)).join('');
}

function createFarmerOrderCard(order) {
    return `
        <div class="bg-gray-50 rounded-lg p-4">
            <div class="flex justify-between items-start mb-3">
                <div>
                    <h4 class="font-semibold">Order #${order._id.slice(-8)}</h4>
                    <p class="text-gray-600">Customer: ${order.user.name}</p>
                    <p class="text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <span class="text-lg font-bold text-green-600">₹${order.totalAmount.toFixed(2)}</span>
            </div>
            
            <div class="mb-3">
                ${order.items.map(item => `
                    <p class="text-sm">${item.product.name} × ${item.quantity}</p>
                `).join('')}
            </div>
            
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-600">Status: ${order.status}</span>
                <select onchange="updateOrderStatus('${order._id}', this.value)" 
                        class="text-sm border border-gray-300 rounded px-2 py-1">
                    <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pending</option>
                    <option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                    <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>Shipped</option>
                    <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>Delivered</option>
                </select>
            </div>
        </div>
    `;
}

async function updateOrderStatus(orderId, status) {
    try {
        await ApiService.updateOrderStatus(orderId, status);
        showNotification('Order status updated successfully!', 'success');
        
        // Reload orders based on user role
        if (appState.user?.role === 'farmer') {
            loadFarmerOrders();
        } else {
            loadOrders(); // For admin or other roles
        }
    } catch (error) {
        console.error('Error updating order status:', error);
    }
}

// Admin Dashboard functions
async function loadAdminDashboard() {
    if (appState.user?.role !== 'admin') {
        showPage('home');
        return;
    }
    
    try {
        const stats = await ApiService.getAdminStats();
        updateAdminStats(stats);
        showAdminTab('overview'); // Default to overview tab
    } catch (error) {
        console.error('Error loading admin dashboard:', error);
    }
}

function updateAdminStats(stats) {
    document.getElementById('admin-total-users').textContent = stats.totalUsers || 0;
    document.getElementById('admin-total-farmers').textContent = stats.totalFarmers || 0;
    document.getElementById('admin-total-products').textContent = stats.totalProducts || 0;
    document.getElementById('admin-monthly-revenue').textContent = `₹${(stats.monthlyRevenue || 0).toFixed(2)}`;
}

function showAdminTab(tabName) {
    // Update tab buttons
    const tabs = document.querySelectorAll('.admin-tab-btn');
    tabs.forEach(tab => tab.classList.remove('tab-active'));
    document.querySelector(`[onclick="showAdminTab('${tabName}')"]`).classList.add('tab-active');
    
    // Show/hide tab content
    const tabContents = document.querySelectorAll('.admin-tab');
    tabContents.forEach(content => content.classList.add('hidden'));
    document.getElementById(`admin-${tabName}-tab`).classList.remove('hidden');
    
    // Load tab-specific data
    switch (tabName) {
        case 'overview':
            loadAdminOverview();
            break;
        case 'users':
            loadAdminUsers();
            break;
        case 'farmers':
            loadAdminFarmers();
            break;
        case 'products':
            loadAdminProducts();
            break;
        case 'orders':
            loadAdminOrders();
            break;
    }
}

async function loadAdminOverview() {
    // Load recent activity and system stats
    const container = document.getElementById('admin-recent-activity');
    const statsContainer = document.getElementById('admin-system-stats');
    
    if (container) {
        container.innerHTML = `
            <div class="space-y-2">
                <p class="text-sm">Recent user registrations: 5</p>
                <p class="text-sm">New products added: 12</p>
                <p class="text-sm">Orders today: 8</p>
                <p class="text-sm">Revenue today: ₹2,450</p>
            </div>
        `;
    }
    
    if (statsContainer) {
        statsContainer.innerHTML = `
            <div class="space-y-2">
                <p class="text-sm">Server uptime: 99.9%</p>
                <p class="text-sm">Database size: 45MB</p>
                <p class="text-sm">Active sessions: 23</p>
                <p class="text-sm">API calls today: 1,234</p>
            </div>
        `;
    }
}

// Utility functions for farmers and admin
function showAddProductForm() {
    // This would open a modal or navigate to a product creation form
    showNotification('Product creation form would open here', 'info');
}

function editProduct(productId) {
    // This would open a modal or navigate to a product edit form
    showNotification('Product edit form would open here', 'info');
}

function toggleProductStatus(productId, activate) {
    // This would toggle the product's active status
    showNotification(`Product ${activate ? 'activated' : 'deactivated'} successfully`, 'success');
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the app
    updateAuthUI();
    appState.updateCartUI();
    
    // Set up form event listeners
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', login);
    }
    
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', register);
    }
    
    const registerRole = document.getElementById('register-role');
    if (registerRole) {
        registerRole.addEventListener('change', toggleFarmerDetails);
    }
    
    const switchAuth = document.getElementById('switch-auth');
    if (switchAuth) {
        switchAuth.addEventListener('click', switchAuthMode);
    }
    
    const closeAuth = document.getElementById('close-auth');
    if (closeAuth) {
        closeAuth.addEventListener('click', closeAuthModal);
    }
    
    // Filter event listeners
    const categoryFilter = document.getElementById('category-filter');
    const sortFilter = document.getElementById('sort-filter');
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', applyFilters);
    }
    
    if (sortFilter) {
        sortFilter.addEventListener('change', applyFilters);
    }
    
    // User menu dropdown
    const userProfile = document.getElementById('user-profile');
    const userDropdown = document.getElementById('user-dropdown');
    
    if (userProfile && userDropdown) {
        userProfile.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('hidden');
        });
        
        document.addEventListener('click', function() {
            userDropdown.classList.add('hidden');
        });
    }
    
    // Load initial page
    showPage('home');
});

// Error handling for unhandled promise rejections
window.addEventListener('unhandledrejection', function(event) {
    console.error('Unhandled promise rejection:', event.reason);
    showNotification('An unexpected error occurred. Please try again.', 'error');
});

// Export for global access
window.appState = appState;
window.ApiService = ApiService;
window.showPage = showPage;
window.openAuthModal = openAuthModal;
window.closeAuthModal = closeAuthModal;
window.logout = logout;
window.addToCart = addToCart;
window.updateCartQuantity = updateCartQuantity;
window.removeFromCart = removeFromCart;
window.proceedToCheckout = proceedToCheckout;
window.placeOrder = placeOrder;
window.showFarmerTab = showFarmerTab;
window.showAdminTab = showAdminTab;
window.applyFilters = applyFilters;
window.updateOrderStatus = updateOrderStatus;